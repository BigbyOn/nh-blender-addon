bl_info = {
    "name": "NH Plugin for Blender",
    "author": "Daryl and Enisam",
    "version": (0, 4, 9, 1),
    "blender": (5, 1, 0),
    "location": "3D Viewport > N-panel > NH Plugin",
    "description": "Scatter Arma3 Proxy objects using DayZ clutter config + Texture Replace (.paa/.rvmat) + Replace from DB via A3OB",
    "doc_url": "https://github.com/BigbyOn/nh-blender-addon",
    "tracker_url": "https://github.com/BigbyOn/nh-blender-addon/issues",
    "mclink": "https://github.com/BigbyOn/nh-blender-addon",
    "category": "Object",
}

import bpy
import bmesh
from bpy.app.handlers import persistent
from bpy.types import Operator, Panel, PropertyGroup, UIList, OperatorFileListElement
from bpy.props import PointerProperty, StringProperty, FloatProperty, IntProperty, BoolProperty, EnumProperty, CollectionProperty
from mathutils import Vector, Matrix
import math
import random
import os
import re
import shutil
import importlib
import json
import sys
from contextlib import contextmanager
import uuid

# ------------------------------------------------------------------------
#  Global config storage
# ------------------------------------------------------------------------

CONFIG_PATH = ""
CONFIG_SURFACES = {}
CONFIG_CLUTTER = {}
_PROXY_MESH_NAME = "DayZ_ClutterProxyMesh"
_SCATTER_PROXY_TAG_PROP = "cray_scatter_proxy"
_ASSET_CATALOG_NAME = "Asset"
_ASSET_CATALOG_FALLBACK_ID = "7d6f3b1d-4d5f-4b1e-9f77-5d1e8dd5c001"
_ADDON_KEYMAP_ITEMS = []
_PLAIN_AXIS_HELPER_PROP = "cray_plain_axis_helper"
_PLAIN_AXIS_ROOT_PROP = "cray_plain_axis_root"
_PLAIN_AXIS_SOURCE_OBJECT_PROP = "cray_plain_axis_source_object"
_PLAIN_AXIS_CONSTRAINT_NAME = "NH Plain Axis"
_PLAIN_AXIS_HOTKEY_REGISTERED = False
_MESH_KEYMAP_NAME = "Mesh"
_LINKED_PICK_CONFLICT_KEYMAPS = {
    "Mesh",
    "3D View",
    "3D View Generic",
}
_PERSISTED_UI_STATE_FILENAME = "nh_blender_ui_state.json"
_PERSISTED_UI_STATE_TIMER_INTERVAL = 1.0
_PERSISTED_UI_STATE_CACHE = None
_TRASH_TINY_ISLAND_MAX_VERTS = 5
_TRASH_TINY_ISLAND_MAX_FACES = 5
_TRASH_TINY_ISLAND_MAX_EDGES = 8
_PERSISTED_UI_SETTINGS = {
    "cray_settings": (
        "vertex_group",
        "config_path",
        "selected_surface",
        "grid_size",
        "density_scale",
        "slope_falloff",
        "max_height_offset",
        "max_distance",
        "random_jitter",
        "spawn_probability",
        "max_proxies",
        "seed",
        "only_hit_source",
    ),
    "cray_snap_settings": (
        "snap_group",
        "snap_p3d_name",
        "snap_pair_code",
        "snap_side",
        "show_auto_edge_fallback",
        "edge_axis",
        "edge_side",
        "edge_span_axis",
        "edge_tolerance",
        "replace_existing",
        "batch_cleanup_imported",
        "batch_overwrite_bak",
    ),
    "cray_model_split_settings": (
        "part_number",
        "named_model_name",
        "named_export_mode",
        "named_export_directory",
    ),
    "cray_collider_settings": (
        "target_lod",
        "box_thickness",
        "bounds_padding",
        "merge_distance",
        "recalc_normals",
        "show_hotkey_button_fallbacks",
        "show_advanced_build_buttons",
        "show_fire_geometry_tools",
        "show_roadway_tools",
        "roadway_weld_distance",
    ),
    "cray_texreplace_settings": (
        "folder",
        "fix_mesh_join_batch",
        "fix_mesh_center_to_origin",
        "fix_list_path",
        "export_warn_loose_vertices",
        "split_planar_ngon_vertex_count",
        "split_planar_ngon_angle_tolerance",
        "split_planar_ngon_plane_tolerance",
    ),
    "cray_ie_settings": (
        "quick_add_p3d_name",
        "quick_add_search_root",
        "import_show_materials",
        "import_keep_converted_textures",
        "disable_collections_after_import",
        "disable_mode",
        "export_mode",
        "export_directory",
        "export_create_bak",
        "export_only_p3d_named",
        "export_only_split_parts",
        "export_force_all_lods",
    ),
    "cray_asset_proxy_settings": (
        "delete_originals",
    ),
    "cray_asset_library_settings": (
        "folder",
        "import_first_lod_only",
        "clear_previous_temp_library",
    ),
}


def _persisted_ui_state_path() -> str:
    base_dir = ""
    try:
        base_dir = bpy.utils.user_resource("CONFIG") or ""
    except Exception:
        base_dir = ""
    if not base_dir:
        base_dir = bpy.app.tempdir or os.path.expanduser("~")
    return os.path.join(base_dir, _PERSISTED_UI_STATE_FILENAME)


def _read_persisted_ui_state():
    path = _persisted_ui_state_path()
    if not path or not os.path.isfile(path):
        return {}

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("=== NH Plugin: failed to read persisted UI state ===")
        print(f"{path} -> {_fmt_exc(e)}")
        return {}

    return data if isinstance(data, dict) else {}


def _write_persisted_ui_state(data):
    global _PERSISTED_UI_STATE_CACHE

    path = _persisted_ui_state_path()
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)

    _PERSISTED_UI_STATE_CACHE = data


def _collect_persisted_ui_state(scene):
    state = {}
    if scene is None:
        return state

    for settings_name, prop_names in _PERSISTED_UI_SETTINGS.items():
        settings = getattr(scene, settings_name, None)
        if settings is None:
            continue

        block = {}
        for prop_name in prop_names:
            try:
                value = getattr(settings, prop_name)
            except Exception:
                continue

            if isinstance(value, bool):
                block[prop_name] = bool(value)
            elif isinstance(value, int):
                block[prop_name] = int(value)
            elif isinstance(value, float):
                block[prop_name] = float(value)
            elif isinstance(value, str):
                block[prop_name] = value

        if block:
            state[settings_name] = block

    return state


def _property_has_default_value(settings, prop_name: str) -> bool:
    if settings is None or not prop_name:
        return True

    try:
        prop = settings.bl_rna.properties.get(prop_name)
    except Exception:
        prop = None
    if prop is None:
        return False

    try:
        current = getattr(settings, prop_name)
    except Exception:
        return False

    try:
        default = prop.default
    except Exception:
        return False

    if isinstance(current, float) or isinstance(default, float):
        try:
            return abs(float(current) - float(default)) <= 1e-9
        except Exception:
            return False

    return current == default


def _apply_persisted_ui_state_to_scene(scene, only_if_default: bool = True):
    raw = _read_persisted_ui_state()
    if scene is None or not raw:
        return 0

    applied = 0
    for settings_name, prop_names in _PERSISTED_UI_SETTINGS.items():
        settings = getattr(scene, settings_name, None)
        saved_block = raw.get(settings_name)
        if settings is None or not isinstance(saved_block, dict):
            continue

        for prop_name in prop_names:
            if prop_name not in saved_block:
                continue
            if only_if_default and not _property_has_default_value(settings, prop_name):
                continue

            try:
                setattr(settings, prop_name, saved_block[prop_name])
                applied += 1
            except Exception:
                pass

    return applied


def _iter_safe_scenes():
    scenes = getattr(bpy.data, "scenes", None)
    if scenes is None:
        return []
    try:
        return list(scenes)
    except Exception:
        return []


def _apply_persisted_ui_state_to_all_scenes(only_if_default: bool = True):
    applied = 0
    for scene in _iter_safe_scenes():
        applied += _apply_persisted_ui_state_to_scene(scene, only_if_default=only_if_default)
    return applied


def _save_current_persisted_ui_state(scene=None):
    global _PERSISTED_UI_STATE_CACHE

    if scene is None:
        scene = getattr(bpy.context, "scene", None)
    if scene is None:
        return False

    data = _collect_persisted_ui_state(scene)
    if data == (_PERSISTED_UI_STATE_CACHE or {}):
        return False

    try:
        _write_persisted_ui_state(data)
    except Exception as e:
        print("=== NH Plugin: failed to write persisted UI state ===")
        print(f"{_persisted_ui_state_path()} -> {_fmt_exc(e)}")
        return False

    return True


@persistent
def _restore_persisted_ui_state_on_load(_dummy):
    global _PERSISTED_UI_STATE_CACHE
    _apply_persisted_ui_state_to_all_scenes(only_if_default=True)
    _PERSISTED_UI_STATE_CACHE = _collect_persisted_ui_state(getattr(bpy.context, "scene", None))


def _persisted_ui_state_timer():
    _save_current_persisted_ui_state(getattr(bpy.context, "scene", None))
    return _PERSISTED_UI_STATE_TIMER_INTERVAL


def _fmt_exc(e: Exception) -> str:
    msg = str(e).strip()
    return f"{type(e).__name__}: {msg}" if msg else type(e).__name__


def _iter_unique_keyconfigs(window_manager):
    keyconfigs = getattr(window_manager, "keyconfigs", None)
    if keyconfigs is None:
        return

    seen = set()
    for attr in ("active", "user", "addon", "default"):
        keyconfig = getattr(keyconfigs, attr, None)
        if keyconfig is None:
            continue
        marker = id(keyconfig)
        if marker in seen:
            continue
        seen.add(marker)
        yield keyconfig


def _keymap_item_matches_event(
    kmi,
    *,
    event_type,
    value="PRESS",
    shift=False,
    ctrl=False,
    alt=False,
    oskey=False,
):
    if not getattr(kmi, "active", True):
        return False
    if getattr(kmi, "type", None) != event_type:
        return False
    if getattr(kmi, "value", None) != value:
        return False
    if getattr(kmi, "any", False):
        return True
    if bool(getattr(kmi, "shift", False)) != bool(shift):
        return False
    if bool(getattr(kmi, "ctrl", False)) != bool(ctrl):
        return False
    if bool(getattr(kmi, "alt", False)) != bool(alt):
        return False
    if bool(getattr(kmi, "oskey", False)) != bool(oskey):
        return False

    key_modifier = getattr(kmi, "key_modifier", "NONE")
    if key_modifier not in {"NONE", "", None}:
        return False

    return True


def _mesh_shortcut_is_free(
    window_manager,
    *,
    event_type,
    value="PRESS",
    shift=False,
    ctrl=False,
    alt=False,
    oskey=False,
):
    for keyconfig in _iter_unique_keyconfigs(window_manager):
        for keymap in keyconfig.keymaps:
            if keymap.name not in _LINKED_PICK_CONFLICT_KEYMAPS:
                continue
            for kmi in keymap.keymap_items:
                if _keymap_item_matches_event(
                    kmi,
                    event_type=event_type,
                    value=value,
                    shift=shift,
                    ctrl=ctrl,
                    alt=alt,
                    oskey=oskey,
                ):
                    return False
    return True


def _register_addon_keymap_item(keymap, operator_idname, *, event_type, value="PRESS", properties=None, **mods):
    for existing in list(keymap.keymap_items):
        if getattr(existing, "idname", "") != operator_idname:
            continue
        try:
            keymap.keymap_items.remove(existing)
        except Exception:
            pass

    kmi = keymap.keymap_items.new(operator_idname, type=event_type, value=value, **mods)
    if properties:
        for prop_name, prop_value in properties.items():
            setattr(kmi.properties, prop_name, prop_value)
    _ADDON_KEYMAP_ITEMS.append((keymap, kmi))
    return kmi


def _register_collider_keymaps():
    global _PLAIN_AXIS_HOTKEY_REGISTERED
    _unregister_collider_keymaps()
    _PLAIN_AXIS_HOTKEY_REGISTERED = False

    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return

    addon_keyconfig = getattr(window_manager.keyconfigs, "addon", None)
    if addon_keyconfig is None:
        return

    keymap = addon_keyconfig.keymaps.get(_MESH_KEYMAP_NAME)
    if keymap is None:
        keymap = addon_keyconfig.keymaps.new(name=_MESH_KEYMAP_NAME, space_type="EMPTY", region_type="WINDOW")

    _register_addon_keymap_item(
        keymap,
        "cray.copy_selected_verts_to_geometry",
        event_type="C",
        value="PRESS",
        ctrl=True,
        shift=True,
    )
    _register_addon_keymap_item(
        keymap,
        "cray.select_isolated_vertices",
        event_type="BUTTON5MOUSE",
        value="PRESS",
    )
    if _mesh_shortcut_is_free(window_manager, event_type="BUTTON4MOUSE", value="PRESS"):
        _register_addon_keymap_item(
            keymap,
            "cray.build_collider",
            event_type="BUTTON4MOUSE",
            value="PRESS",
            properties={"build_mode": "SELECTION_HULL"},
        )
    else:
        print("[NH Plugin] Mouse4 is already in use, skipping Selection -> Hull shortcut.")

    if _mesh_shortcut_is_free(window_manager, event_type="P", value="PRESS", ctrl=True, shift=True):
        _register_addon_keymap_item(
            keymap,
            "cray.create_plain_axis_pivot",
            event_type="P",
            value="PRESS",
            ctrl=True,
            shift=True,
        )
        _PLAIN_AXIS_HOTKEY_REGISTERED = True
    else:
        print("[NH Plugin] Ctrl+Shift+P is already in use, skipping Plain Axis Pivot shortcut.")


def _unregister_collider_keymaps():
    global _PLAIN_AXIS_HOTKEY_REGISTERED
    while _ADDON_KEYMAP_ITEMS:
        keymap, kmi = _ADDON_KEYMAP_ITEMS.pop()
        try:
            keymap.keymap_items.remove(kmi)
        except Exception:
            pass
    _PLAIN_AXIS_HOTKEY_REGISTERED = False

# ------------------------------------------------------------------------
#  Brace helpers
# ------------------------------------------------------------------------

def _extract_block(src: str, brace_index: int):
    depth = 1
    i = brace_index + 1
    n = len(src)
    while i < n and depth > 0:
        c = src[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        i += 1
    if depth != 0:
        raise RuntimeError("Unbalanced braces while parsing config")
    return src[brace_index + 1 : i - 1], i


def _find_class_block(src: str, class_name: str):
    m = re.search(r"class\s+" + re.escape(class_name) + r"\b[^{]*{", src)
    if not m:
        return None
    brace_index = src.find("{", m.start())
    if brace_index == -1:
        return None
    body, _ = _extract_block(src, brace_index)
    return body


def _iter_inner_classes(block: str):
    pos = 0
    n = len(block)
    while pos < n:
        m = re.search(r"class\s+(\w+)[^{]*{", block[pos:])
        if not m:
            break
        name = m.group(1)
        brace_index = pos + m.end() - 1
        body, new_pos = _extract_block(block, brace_index)
        yield name, body
        pos = new_pos


# ------------------------------------------------------------------------
#  Parsing DayZ .cpp
# ------------------------------------------------------------------------

def parse_dayz_config(path: str):
    global CONFIG_PATH, CONFIG_SURFACES, CONFIG_CLUTTER

    if not os.path.isfile(path):
        raise RuntimeError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    text = re.sub(r"//.*?$", "", text, flags=re.MULTILINE)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)

    surfaces = {}
    clutter = {}

    cfgworlds_block = _find_class_block(text, "CfgWorlds")
    if cfgworlds_block:
        caworld_block = _find_class_block(cfgworlds_block, "CAWorld")
        if caworld_block:
            clutter_block = _find_class_block(caworld_block, "Clutter")
            if clutter_block:
                for c_name, c_body in _iter_inner_classes(clutter_block):
                    m_model = re.search(r'model\s*=\s*"([^"]+)"', c_body)
                    if not m_model:
                        continue
                    model_path = m_model.group(1)
                    m_smin = re.search(r"scaleMin\s*=\s*([0-9.eE+-]+)", c_body)
                    m_smax = re.search(r"scaleMax\s*=\s*([0-9.eE+-]+)", c_body)
                    smin = float(m_smin.group(1)) if m_smin else 1.0
                    smax = float(m_smax.group(1)) if m_smax else 1.0
                    clutter[c_name] = {"model": model_path, "scaleMin": smin, "scaleMax": smax}

    cfgsurf_block = _find_class_block(text, "CfgSurfaceCharacters")
    if cfgsurf_block:
        for s_name, s_body in _iter_inner_classes(cfgsurf_block):
            m_prob = re.search(r"probability\s*\[\]\s*=\s*{([^}]*)}", s_body)
            m_names = re.search(r"names\s*\[\]\s*=\s*{([^}]*)}", s_body, re.S)
            if not (m_prob and m_names):
                continue

            probs_str = m_prob.group(1)
            names_str = m_names.group(1)

            probs = [p.strip() for p in probs_str.split(",") if p.strip()]
            names = [n.strip().strip('"') for n in names_str.split(",") if n.strip()]

            if len(probs) != len(names):
                continue

            probs_f = [float(p) for p in probs]
            surfaces[s_name] = {"names": names, "probs": probs_f}

    CONFIG_PATH = path
    CONFIG_SURFACES = surfaces
    CONFIG_CLUTTER = clutter


def build_clutter_distribution(surface_name: str):
    if surface_name not in CONFIG_SURFACES:
        raise RuntimeError(f"Surface '{surface_name}' not found in CfgSurfaceCharacters")

    s_def = CONFIG_SURFACES[surface_name]
    names = s_def["names"]
    probs = s_def["probs"]

    used_names, used_probs, used_defs = [], [], {}
    clutter_map_lc = {k.lower(): k for k in CONFIG_CLUTTER.keys()}

    for n, p in zip(names, probs):
        if p <= 0.0:
            continue
        key = clutter_map_lc.get(n.lower())
        if key is None:
            raise RuntimeError(
                f"Clutter class '{n}' is referenced by surface '{surface_name}' "
                f"but not found in CfgWorlds->CAWorld->Clutter"
            )
        c_def = CONFIG_CLUTTER[key]
        model_path = (c_def.get("model") or "").strip()
        if not model_path:
            raise RuntimeError(f"Clutter class '{key}' has no 'model' defined")
        used_names.append(n)
        used_probs.append(p)
        used_defs[n] = c_def

    if not used_names:
        raise RuntimeError(f"Surface '{surface_name}' has no clutter with non-zero probability")

    total = sum(used_probs)
    if total <= 0.0:
        raise RuntimeError(f"Surface '{surface_name}' probabilities sum to zero")

    norm_probs = [p / total for p in used_probs]
    return used_names, norm_probs, used_defs


def pick_weighted_random(names, probs, rng=None):
    rng = rng or random
    r = rng.random()
    acc = 0.0
    for n, p in zip(names, probs):
        acc += p
        if r <= acc:
            return n
    return names[-1]

def _resolve_scatter_edit_mesh_object(context):
    obj = getattr(context, "edit_object", None)
    if obj is None:
        obj = context.view_layer.objects.active
    if obj is None or obj.type != "MESH":
        raise RuntimeError("Active object must be a mesh")
    if obj.mode != "EDIT":
        raise RuntimeError("Enter Edit Mode and select polygons on the mesh")
    return obj

def _collect_selected_face_triangles_world(obj):
    if obj is None or obj.type != "MESH" or obj.mode != "EDIT":
        return []

    bm = bmesh.from_edit_mesh(obj.data)
    world = obj.matrix_world
    normal_matrix = world.to_3x3().inverted().transposed()
    triangles = []

    for face in bm.faces:
        if not face.select or len(face.verts) < 3:
            continue

        verts_world = [world @ vert.co for vert in face.verts]
        try:
            face_normal = (normal_matrix @ face.normal).normalized()
        except Exception:
            face_normal = Vector((0.0, 0.0, 1.0))

        v0 = verts_world[0]
        for idx in range(1, len(verts_world) - 1):
            v1 = verts_world[idx]
            v2 = verts_world[idx + 1]
            area = ((v1 - v0).cross(v2 - v0)).length * 0.5
            if area <= 1e-10:
                continue
            triangles.append((v0.copy(), v1.copy(), v2.copy(), face_normal.copy(), area))

    return triangles

def _sample_point_on_triangle(v0: Vector, v1: Vector, v2: Vector, rng) -> Vector:
    r1 = math.sqrt(rng.random())
    r2 = rng.random()
    return ((1.0 - r1) * v0) + (r1 * (1.0 - r2) * v1) + (r1 * r2 * v2)

def _scatter_slope_density_factor(normal: Vector, falloff: float) -> float:
    try:
        up_factor = max(0.0, min(1.0, normal.normalized().z))
    except Exception:
        up_factor = 0.0

    if falloff <= 0.0:
        return 1.0
    return up_factor ** float(falloff)

def _sanitize_snap_p3d_name_value(value: str) -> str:
    name = (value or "").strip()
    if name.lower().endswith(".p3d"):
        name = name[:-4]
    return re.sub(r"[^A-Za-z0-9]+", "", name)

def _on_snap_p3d_name_changed(self, context):
    del context
    current = getattr(self, "snap_p3d_name", "")
    sanitized = _sanitize_snap_p3d_name_value(current)
    if sanitized != current:
        self.snap_p3d_name = sanitized


# ------------------------------------------------------------------------
#  Proxy mesh & A3OB properties
# ------------------------------------------------------------------------

def get_proxy_mesh():
    mesh = bpy.data.meshes.get(_PROXY_MESH_NAME)
    if mesh is None:
        mesh = bpy.data.meshes.new(_PROXY_MESH_NAME)
        mesh.from_pydata([(0.0, 0.0, 0.0), (0.0, 0.0, 2.0), (0.0, 1.0, 0.0)], [], [(0, 1, 2)])
        mesh.update(calc_edges=True)
    return mesh


def make_pdrive_path(model_path: str) -> str:
    if not model_path:
        return model_path
    p = model_path.strip().replace("/", "\\")
    if p.lower().startswith("p:\\"):
        return p
    while p.startswith("\\"):
        p = p[1:]
    return "p:\\" + p


def set_a3ob_proxy_properties(proxy_obj, model_path: str, proxy_index: int):
    if not hasattr(proxy_obj, "a3ob_properties_object_proxy"):
        raise RuntimeError(
            "Object has no 'a3ob_properties_object_proxy'. "
            "Ensure addon 'Arma 3 Object Builder' is installed and enabled."
        )

    pg = proxy_obj.a3ob_properties_object_proxy

    name_to_id = {}
    for prop in pg.bl_rna.properties:
        if prop.identifier == "rna_type":
            continue
        name_to_id[prop.name] = prop.identifier

    is_id = name_to_id.get("Is P3D Proxy")
    if is_id and hasattr(pg, is_id):
        setattr(pg, is_id, True)
    elif hasattr(pg, "is_a3_proxy"):
        pg.is_a3_proxy = True

    arma_path = make_pdrive_path(model_path)

    path_id = name_to_id.get("Path")
    if path_id and hasattr(pg, path_id):
        setattr(pg, path_id, arma_path)
    elif hasattr(pg, "path"):
        pg.path = arma_path

    index_id = name_to_id.get("Index")
    if index_id and hasattr(pg, index_id):
        setattr(pg, index_id, proxy_index)
    elif hasattr(pg, "index"):
        pg.index = proxy_index


def create_proxy_object(context, collection, parent_obj, location: Vector, normal: Vector,
                        model_path: str, proxy_index: int, scale_min: float = 1.0, scale_max: float = 1.0,
                        rng=None):
    proxy_mesh = get_proxy_mesh()
    proxy_obj = bpy.data.objects.new(f"clutter_proxy_{proxy_index}", proxy_mesh)

    n = normal.normalized()
    up = Vector((0.0, 0.0, 1.0))
    if abs(n.dot(up)) > 0.999:
        up = Vector((0.0, 1.0, 0.0))

    x_axis = up.cross(n).normalized()
    y_axis = n.cross(x_axis).normalized()

    rot_mat = Matrix(((x_axis.x, y_axis.x, n.x),
                      (x_axis.y, y_axis.y, n.y),
                      (x_axis.z, y_axis.z, n.z)))

    proxy_obj.matrix_world = Matrix.Translation(location) @ rot_mat.to_4x4()
    rng = rng or random
    s = rng.uniform(scale_min, scale_max)
    proxy_obj.scale = (s, s, s)

    collection.objects.link(proxy_obj)
    proxy_obj.parent = parent_obj
    try:
        proxy_obj[_SCATTER_PROXY_TAG_PROP] = True
    except Exception:
        pass
    set_a3ob_proxy_properties(proxy_obj, model_path, proxy_index)
    return proxy_obj

def _is_generated_scatter_proxy(obj, parent_obj=None) -> bool:
    if obj is None:
        return False
    if parent_obj is not None and obj.parent != parent_obj:
        return False
    if obj.get(_SCATTER_PROXY_TAG_PROP, False):
        return True

    try:
        proxy_mesh = get_proxy_mesh()
    except Exception:
        proxy_mesh = None

    if proxy_mesh is not None and getattr(obj, "data", None) == proxy_mesh:
        if (obj.name or "").startswith("clutter_proxy_"):
            return True
    return False

def _clear_generated_scatter_proxies(parent_obj) -> int:
    if parent_obj is None:
        return 0

    to_remove = [obj for obj in bpy.data.objects if _is_generated_scatter_proxy(obj, parent_obj=parent_obj)]
    to_remove.sort(key=lambda item: _obj_depth(item), reverse=True)

    removed = 0
    for obj in to_remove:
        if bpy.data.objects.get(obj.name) is None:
            continue
        bpy.data.objects.remove(obj, do_unlink=True)
        removed += 1
    return removed


# ------------------------------------------------------------------------
#  UI helpers
# ------------------------------------------------------------------------

def get_surface_enum_items(self, context):
    items = [("NONE", "<no surface>", "Surface is not selected")]
    if not CONFIG_SURFACES:
        return items
    for name in sorted(CONFIG_SURFACES.keys()):
        items.append((name, name, "Surface from CfgSurfaceCharacters"))
    return items


# ------------------------------------------------------------------------
#  Settings
# ------------------------------------------------------------------------

class CRAY_PG_Settings(PropertyGroup):
    source_object: PointerProperty(name="Source Object", type=bpy.types.Object)
    vertex_group: StringProperty(name="Vertex Group", default="")
    target_collection: PointerProperty(name="Target Collection", type=bpy.types.Collection)
    config_path: StringProperty(name="Config .cpp", default="", subtype="FILE_PATH")
    selected_surface: EnumProperty(name="Surface", items=get_surface_enum_items)
    grid_size: FloatProperty(name="Grid Size", default=1.0, min=0.01)
    density_scale: FloatProperty(name="Density Scale", default=1.0, min=0.01, soft_max=8.0)
    slope_falloff: FloatProperty(
        name="Slope Falloff",
        description="Reduce clutter density on steeper faces; 0 disables the reduction",
        default=2.0,
        min=0.0,
        soft_max=4.0,
    )
    max_height_offset: FloatProperty(name="Height Offset", default=2.0, min=0.0)
    max_distance: FloatProperty(name="Max Distance", default=100.0, min=0.1)
    random_jitter: FloatProperty(name="Random Jitter", default=0.5, min=0.0, max=1.0)
    spawn_probability: FloatProperty(name="Spawn Probability", default=1.0, min=0.0, max=1.0)
    max_proxies: IntProperty(name="Max Proxies (0=unlimited)", default=0, min=0)
    seed: IntProperty(name="Random Seed", default=0)
    only_hit_source: BoolProperty(name="Only Hit Source", default=True)

class CRAY_PG_SnapSettings(PropertyGroup):
    source_object: PointerProperty(
        name="Resolution LOD (A)",
        description="Resolution/source LOD for the first A target",
        type=bpy.types.Object,
    )
    memory_object: PointerProperty(
        name="Memory LOD (A)",
        description="Memory LOD object for the first A target",
        type=bpy.types.Object,
    )
    paired_object: PointerProperty(
        name="Resolution LOD (V)",
        description="Resolution/source LOD for the second V target",
        type=bpy.types.Object,
    )
    paired_memory_object: PointerProperty(
        name="Memory LOD (V)",
        description="Memory LOD object for the second V target",
        type=bpy.types.Object,
    )
    snap_group: StringProperty(name="Snap Group", default="SampleName")
    snap_p3d_name: StringProperty(
        name="P3D Name",
        description="Only letters and digits are kept; spaces, underscores, .p3d and other symbols are removed automatically",
        default="SampleName",
        update=_on_snap_p3d_name_changed,
    )
    snap_pair_code: StringProperty(name="ID", default="01", maxlen=3)
    snap_side: EnumProperty(
        name="Side",
        items=(
            ("a", "A", "Create A-side snap points"),
            ("v", "V", "Create V-side snap points"),
        ),
        default="a",
    )
    edge_axis: EnumProperty(
        name="Snap Axis",
        items=(
            ("X", "X", "Use X in the snap point name pattern and as the preferred 0/1 sort axis"),
            ("Y", "Y", "Use Y in the snap point name pattern and as the preferred 0/1 sort axis"),
            ("Z", "Z", "Use Z in the snap point name pattern and as the preferred 0/1 sort axis"),
        ),
        default="X",
    )
    edge_side: EnumProperty(
        name="Edge Side",
        items=(
            ("NEG", "Min", "Use minimum edge value"),
            ("POS", "Max", "Use maximum edge value"),
        ),
        default="POS",
    )
    edge_span_axis: EnumProperty(
        name="Span Axis",
        items=(
            ("AUTO", "Auto", "Auto-pick span axis from Edge Axis"),
            ("X", "X", "Use X as span axis"),
            ("Y", "Y", "Use Y as span axis"),
            ("Z", "Z", "Use Z as span axis"),
        ),
        default="AUTO",
    )
    edge_tolerance: FloatProperty(
        name="Edge Tolerance",
        description="Band size near edge (fraction of model size along edge axis)",
        default=0.03,
        min=0.0,
        max=0.5,
    )
    show_auto_edge_fallback: BoolProperty(
        name="Show Auto Edge Fallback",
        description="Show fallback settings used only when no 2 vertices are selected in Edit Mode",
        default=False,
    )
    replace_existing: BoolProperty(name="Replace Existing Named Groups", default=True)
    batch_cleanup_imported: BoolProperty(name="Cleanup Imported Objects", default=True)
    batch_overwrite_bak: BoolProperty(name="Overwrite .bak", default=True)

_MODEL_SPLIT_TARGET_CATEGORY_ITEMS = (
    ("RESOLUTION", "Resolution", "A3OB Resolution LOD stored in Visuals"),
    ("GEOMETRIES", "Geometries", "A3OB Geometry LOD stored in Geometries"),
    ("POINT_CLOUDS", "Point clouds", "A3OB Memory LOD stored in Point clouds"),
    ("ROADWAY", "Roadway", "A3OB Roadway LOD stored in Misc"),
)

class CRAY_PG_ModelSplitSettings(PropertyGroup):
    part_number: IntProperty(
        name="Part Number",
        description="Numeric suffix for the new split part collection",
        default=1,
        min=1,
        max=999,
    )
    named_model_name: StringProperty(
        name="New Model Name",
        default="",
        description="Name of the new standalone model; .p3d is added automatically",
    )
    named_transfer_mode: EnumProperty(
        name="Action",
        items=(
            ("MOVE", "Move", "Move selected objects out of the source model into the standalone model"),
            ("COPY", "Copy", "Copy selected objects into the standalone model and keep originals"),
        ),
        default="MOVE",
    )
    named_source_collection: PointerProperty(
        name="Source Collection",
        description="Pick the original .p3d root collection that selected meshes come from",
        type=bpy.types.Collection,
    )
    named_target_collection: PointerProperty(
        name="Target Collection",
        description="Pick a .p3d root collection or one of its child A3OB category collections",
        type=bpy.types.Collection,
    )
    named_target_category: EnumProperty(
        name="Category",
        description="A3OB category where selected mesh objects should be placed",
        items=_MODEL_SPLIT_TARGET_CATEGORY_ITEMS,
        default="RESOLUTION",
    )
    named_export_mode: EnumProperty(
        name="Export Target",
        items=(
            ("SOURCE_SIBLING", "Next to source", "Save Back to source path next to the original model"),
            ("CUSTOM_DIR", "Custom folder", "Save Back to source path into a selected folder"),
        ),
        default="SOURCE_SIBLING",
    )
    named_export_directory: StringProperty(
        name="Export Folder",
        default="",
        subtype="DIR_PATH",
        description="Folder used when Export Target is set to Custom folder",
    )


_COLLIDER_TARGET_LOD_ITEMS = (
    ("6", "Geometry", "Object collision geometry and occluders"),
    ("14", "View Geometry", "View occlusion for AI"),
    ("15", "Fire Geometry", "Hitbox geometry"),
)
_COLLIDER_LOD_NAMES = {
    "6": "Geometry",
    "8": "Geometry PhysX",
    "14": "View Geometry",
    "15": "Fire Geometry",
}
_COLLIDER_KNOWN_LOD_NAMES = {
    **_COLLIDER_LOD_NAMES,
    "0": "Resolution",
    "9": "Memory",
    "11": "Roadway",
}
_VISUALS_COLLECTION_NAME = "Visuals"
_VISUALS_COLLECTION_COLOR = "COLOR_02"
_COLLIDER_COLLECTION_NAME = "Geometries"
_COLLIDER_COLLECTION_ALIASES = ("Geometry",)
_COLLIDER_COLLECTION_COLOR = "COLOR_03"
_COLLIDER_OBJECT_COLOR = (1.0, 0.93, 0.55, 1.0)
_MEMORY_COLLECTION_NAME = "Point clouds"
_MEMORY_COLLECTION_ALIASES = ("Memory",)
_MEMORY_COLLECTION_COLOR = "COLOR_05"
_MISC_COLLECTION_NAME = "Misc"
_MISC_COLLECTION_COLOR = "COLOR_04"
_ROADWAY_LOD_TOKEN = "11"
_ROADWAY_OBJECT_COLOR = (0.72, 0.88, 1.0, 1.0)
_ROADWAY_SURFACES_FOLDER = r"P:\DZ\surfaces\data\roadway"
_ROADWAY_MATERIAL_NONE = "__NONE__"
_ROADWAY_MATERIAL_ENUM_CACHE = [
    (_ROADWAY_MATERIAL_NONE, "<no materials>", "Roadway object has no assigned materials")
]
_FIRE_GEOMETRY_LOD_TOKEN = "15"
_FIRE_GEOMETRY_RVMAT_FOLDER = r"P:\DZ\data\data\penetration"
_FIRE_GEOMETRY_MATERIAL_NONE = "__NONE__"
_FIRE_GEOMETRY_MATERIAL_ENUM_CACHE = [
    (_FIRE_GEOMETRY_MATERIAL_NONE, "<no materials>", "Selected Fire Geometry object has no assigned materials")
]
_MATERIAL_ADD_NEW = "__ADD_NEW__"
_COLLIDER_MATERIAL_SELECTION_SYNCING = False
_COLLIDER_LOD_SYNCING_FROM_OBJECT = False
_GEOMETRY_LOD_TOKEN = "6"
_GEOMETRY_LOD_DEFAULT_TOTAL_MASS = 1000.0
_MODEL_SPLIT_TARGET_CATEGORY_SPECS = {
    "RESOLUTION": {
        "collection": _VISUALS_COLLECTION_NAME,
        "aliases": (),
        "color": _VISUALS_COLLECTION_COLOR,
        "lod": "0",
    },
    "GEOMETRIES": {
        "collection": _COLLIDER_COLLECTION_NAME,
        "aliases": _COLLIDER_COLLECTION_ALIASES,
        "color": _COLLIDER_COLLECTION_COLOR,
        "lod": "6",
    },
    "POINT_CLOUDS": {
        "collection": _MEMORY_COLLECTION_NAME,
        "aliases": _MEMORY_COLLECTION_ALIASES,
        "color": _MEMORY_COLLECTION_COLOR,
        "lod": "9",
    },
    "ROADWAY": {
        "collection": _MISC_COLLECTION_NAME,
        "aliases": (),
        "color": _MISC_COLLECTION_COLOR,
        "lod": _ROADWAY_LOD_TOKEN,
    },
}
_MODEL_SPLIT_VISUAL_LODS = {"0", "1", "2", "3", "18"}
_MODEL_SPLIT_GEOMETRY_LODS = {
    "6", "7", "8", "14", "15", "16", "17", "19", "20", "21", "22", "23", "24", "30"
}
_MODEL_SPLIT_POINT_CLOUD_LODS = {"9", "10", "13"}
_MODEL_SPLIT_ROADWAY_LODS = {"11"}


def _material_enum_items_for_object(obj, *, none_value: str, missing_object_desc: str, missing_material_desc: str, slot_desc_prefix: str):
    items = []

    if obj is None or obj.type != "MESH":
        return [(none_value, missing_object_desc, missing_object_desc)]

    items.append((_MATERIAL_ADD_NEW, "Добавить новый", f"Create and assign a new {slot_desc_prefix.lower()}"))
    material_count = 0

    seen = set()
    for slot_idx, slot in enumerate(obj.material_slots, start=1):
        mat = slot.material
        if mat is None:
            continue

        key = mat.name.lower()
        if key in seen:
            continue
        seen.add(key)

        image_names = []
        if mat.use_nodes and mat.node_tree:
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE" and getattr(node, "image", None):
                    image_names.append(node.image.name)

        desc = f"{slot_desc_prefix} from slot {slot_idx}"
        if image_names:
            uniq_images = sorted(set(image_names), key=lambda x: x.lower())
            desc = f"{desc} | Images: {', '.join(uniq_images[:3])}"
            if len(uniq_images) > 3:
                desc += f" (+{len(uniq_images) - 3} more)"

        items.append((mat.name, mat.name, desc))
        material_count += 1

    if material_count == 0:
        items.append((none_value, "<no materials>", missing_material_desc))

    return items


def get_roadway_material_enum_items(self, context):
    del self

    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    obj = getattr(cs, "roadway_object", None) if cs else None
    items = _material_enum_items_for_object(
        obj,
        none_value=_ROADWAY_MATERIAL_NONE,
        missing_object_desc="<no roadway object>",
        missing_material_desc="Selected Roadway Object has no assigned materials",
        slot_desc_prefix="Roadway material",
    )

    global _ROADWAY_MATERIAL_ENUM_CACHE
    _ROADWAY_MATERIAL_ENUM_CACHE = items
    return _ROADWAY_MATERIAL_ENUM_CACHE


def get_fire_geometry_material_enum_items(self, context):
    del self

    obj = _resolve_fire_geometry_object_for_material(context)
    items = _material_enum_items_for_object(
        obj,
        none_value=_FIRE_GEOMETRY_MATERIAL_NONE,
        missing_object_desc="<no fire geometry object>",
        missing_material_desc="Selected Fire Geometry object has no assigned materials",
        slot_desc_prefix="Fire Geometry material",
    )

    global _FIRE_GEOMETRY_MATERIAL_ENUM_CACHE
    _FIRE_GEOMETRY_MATERIAL_ENUM_CACHE = items
    return _FIRE_GEOMETRY_MATERIAL_ENUM_CACHE


def _on_collider_target_lod_changed(self, context):
    global _COLLIDER_LOD_SYNCING_FROM_OBJECT
    if _COLLIDER_LOD_SYNCING_FROM_OBJECT:
        return

    cs = self
    if context is None:
        return

    target_obj = getattr(cs, "geometry_object", None)
    if target_obj is None or target_obj.type != "MESH":
        return

    lod_token = str(getattr(cs, "target_lod", "") or "").strip()
    if lod_token not in _COLLIDER_LOD_NAMES:
        return

    try:
        _set_collider_lod_a3ob_props(target_obj, lod_token)
        _apply_collider_visual_style(target_obj)
        _enable_collider_object_color_preview(context)
        if lod_token == _FIRE_GEOMETRY_LOD_TOKEN:
            setattr(cs, "fire_geometry_object", target_obj)
            _sync_fire_geometry_material_selection(context)
        _set_collider_settings_object(context, "geometry_object", target_obj)
    except Exception:
        pass


def _unique_material_name(base_name: str) -> str:
    base = (base_name or "Material").strip() or "Material"
    if bpy.data.materials.get(base) is None:
        return base
    idx = 1
    while True:
        candidate = f"{base}.{idx:03d}"
        if bpy.data.materials.get(candidate) is None:
            return candidate
        idx += 1


def _ensure_material_slot(obj, mat):
    if obj is None or getattr(obj, "type", None) != "MESH" or mat is None or obj.data is None:
        return -1
    for idx, existing in enumerate(obj.data.materials):
        if existing == mat:
            return idx
    obj.data.materials.append(mat)
    return len(obj.data.materials) - 1


def _assign_material_to_target_selection(obj, mat) -> bool:
    slot_idx = _ensure_material_slot(obj, mat)
    if slot_idx < 0:
        return False

    assigned = False
    if obj.mode == "EDIT":
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        selected_faces = [face for face in bm.faces if face.select]
        if selected_faces:
            for face in selected_faces:
                face.material_index = slot_idx
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            assigned = True

    if not assigned:
        for poly in obj.data.polygons:
            poly.material_index = slot_idx
        assigned = len(obj.data.polygons) > 0

    return assigned


def _selected_material_assignment_objects(context, object_attr: str):
    if object_attr == "fire_geometry_object":
        predicate = lambda obj: _poll_fire_geometry_object(None, obj)
    elif object_attr == "roadway_object":
        predicate = lambda obj: _poll_roadway_object(None, obj)
    else:
        predicate = lambda obj: obj is not None and getattr(obj, "type", None) == "MESH"

    objects = []
    seen = set()
    for obj in getattr(context, "selected_objects", []):
        if not predicate(obj):
            continue
        try:
            ptr = obj.as_pointer()
        except Exception:
            ptr = id(obj)
        if ptr in seen:
            continue
        seen.add(ptr)
        objects.append(obj)
    return objects


def _create_and_assign_target_material(context, *, object_attr: str, material_attr: str, default_name: str, sync_fn):
    global _COLLIDER_MATERIAL_SELECTION_SYNCING

    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    if cs is None:
        return None

    target_obj = getattr(cs, object_attr, None)
    if object_attr == "fire_geometry_object":
        target_obj = _resolve_fire_geometry_object_for_material(context)
    if target_obj is None or getattr(target_obj, "type", None) != "MESH":
        _COLLIDER_MATERIAL_SELECTION_SYNCING = True
        try:
            setattr(cs, material_attr, _FIRE_GEOMETRY_MATERIAL_NONE if object_attr == "fire_geometry_object" else _ROADWAY_MATERIAL_NONE)
        finally:
            _COLLIDER_MATERIAL_SELECTION_SYNCING = False
        return None

    mat = bpy.data.materials.new(_unique_material_name(default_name))
    assignment_objects = _selected_material_assignment_objects(context, object_attr)
    if not assignment_objects:
        assignment_objects = [target_obj]

    target_in_assignment = False
    for obj in assignment_objects:
        if obj == target_obj:
            target_in_assignment = True
        _assign_material_to_target_selection(obj, mat)
    if not target_in_assignment:
        _ensure_material_slot(target_obj, mat)

    sync_fn(context, mat.name)
    return mat


def _on_roadway_material_changed(self, context):
    if _COLLIDER_MATERIAL_SELECTION_SYNCING:
        return
    if (getattr(self, "roadway_material", "") or "") != _MATERIAL_ADD_NEW:
        return
    _create_and_assign_target_material(
        context,
        object_attr="roadway_object",
        material_attr="roadway_material",
        default_name="RoadwayMaterial",
        sync_fn=_sync_roadway_material_selection,
    )


def _on_fire_geometry_material_changed(self, context):
    if _COLLIDER_MATERIAL_SELECTION_SYNCING:
        return
    if (getattr(self, "fire_geometry_material", "") or "") != _MATERIAL_ADD_NEW:
        return
    _create_and_assign_target_material(
        context,
        object_attr="fire_geometry_object",
        material_attr="fire_geometry_material",
        default_name="FireGeometryMaterial",
        sync_fn=_sync_fire_geometry_material_selection,
    )


def _actual_collider_lod_token_from_object(obj) -> str:
    if obj is None or getattr(obj, "type", None) != "MESH":
        return ""

    if not hasattr(obj, "a3ob_properties_object"):
        return ""

    try:
        props = obj.a3ob_properties_object
        if not bool(getattr(props, "is_a3_lod", False)):
            return ""
        return str(getattr(props, "lod", "") or "").strip()
    except Exception:
        return ""


def _collider_lod_token_from_object(obj, *, allow_name_fallback: bool = True) -> str:
    lod_token = _actual_collider_lod_token_from_object(obj)
    if lod_token in _COLLIDER_LOD_NAMES:
        return lod_token

    if not allow_name_fallback or obj is None or getattr(obj, "type", None) != "MESH":
        return ""

    logical_name = _logical_collection_name(getattr(obj, "name", "") or "")
    for lod_token, lod_name in _COLLIDER_LOD_NAMES.items():
        if logical_name == _logical_collection_name(lod_name):
            return str(lod_token)

    return ""


def _resolve_fire_geometry_object_for_material(context):
    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    if cs is None:
        return None

    candidates = (
        getattr(cs, "fire_geometry_object", None),
        getattr(cs, "geometry_object", None),
    )
    for obj in candidates:
        if obj is None or getattr(obj, "type", None) != "MESH":
            continue
        if _collider_lod_token_from_object(obj, allow_name_fallback=True) == _FIRE_GEOMETRY_LOD_TOKEN:
            try:
                cs.fire_geometry_object = obj
            except Exception:
                pass
            return obj

    return None


def _object_name_startswith_lod(obj, lod_token: str) -> bool:
    if obj is None or getattr(obj, "type", None) != "MESH":
        return False

    expected = _logical_collection_name(_collider_lod_name(lod_token))
    actual = _logical_collection_name(getattr(obj, "name", "") or "")
    return bool(expected and actual.startswith(expected))


def _poll_fire_geometry_object(self, obj):
    del self
    return _object_name_startswith_lod(obj, _FIRE_GEOMETRY_LOD_TOKEN)


def _poll_roadway_object(self, obj):
    del self
    return _object_name_startswith_lod(obj, _ROADWAY_LOD_TOKEN)


def _active_or_selected_mesh_object(context):
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active_obj = getattr(active, "active", None) if active is not None else None
    if active_obj is not None and getattr(active_obj, "type", None) == "MESH":
        return active_obj
    for obj in getattr(context, "selected_objects", []):
        if obj is not None and getattr(obj, "type", None) == "MESH":
            return obj
    return None


def _on_collider_geometry_object_changed(self, context):
    if context is None:
        return

    target_obj = getattr(self, "geometry_object", None)
    lod_token = _collider_lod_token_from_object(target_obj, allow_name_fallback=True)
    if lod_token not in _COLLIDER_LOD_NAMES:
        return

    try:
        if str(getattr(self, "target_lod", "") or "") != lod_token:
            global _COLLIDER_LOD_SYNCING_FROM_OBJECT
            _COLLIDER_LOD_SYNCING_FROM_OBJECT = True
            try:
                self.target_lod = lod_token
            finally:
                _COLLIDER_LOD_SYNCING_FROM_OBJECT = False
        else:
            _apply_collider_visual_style(target_obj)
            _enable_collider_object_color_preview(context)
        if lod_token == _FIRE_GEOMETRY_LOD_TOKEN:
            self.fire_geometry_object = target_obj
            _sync_fire_geometry_material_selection(context)
    except Exception:
        pass


class CRAY_PG_ColliderSettings(PropertyGroup):
    source_object: PointerProperty(
        name="Source Object",
        description="Visual/source object used to build colliders",
        type=bpy.types.Object,
    )
    geometry_object: PointerProperty(
        name="Target LOD Object",
        description="Geometry LOD mesh that receives generated colliders",
        type=bpy.types.Object,
        update=_on_collider_geometry_object_changed,
    )
    target_lod: EnumProperty(
        name="Target LOD",
        description="A3OB LOD type for the generated collider object",
        items=_COLLIDER_TARGET_LOD_ITEMS,
        default="6",
        update=_on_collider_target_lod_changed,
    )
    box_thickness: FloatProperty(
        name="Thickness",
        description="Thickness used for wall-like selections and flat convex hull fallback",
        default=0.20,
        min=0.0,
        precision=4,
        unit="LENGTH",
    )
    bounds_padding: FloatProperty(
        name="Bounds Padding",
        description="Expand the object bounds before creating a box collider",
        default=0.0,
        min=0.0,
        precision=4,
        unit="LENGTH",
    )
    merge_distance: FloatProperty(
        name="Merge Distance",
        description="Optional weld distance applied to the new collider points before convex hull",
        default=0.0,
        min=0.0,
        precision=5,
        unit="LENGTH",
    )
    recalc_normals: BoolProperty(
        name="Recalculate Normals",
        description="Recalculate normals on the newly created collider faces",
        default=True,
    )
    show_hotkey_button_fallbacks: BoolProperty(
        name="Show Hotkey Buttons",
        description="Show clickable fallback buttons for the collider hotkeys",
        default=False,
    )
    show_advanced_build_buttons: BoolProperty(
        name="Show Extra Build Buttons",
        description="Show extra build buttons that are not on hotkeys",
        default=False,
    )
    show_fire_geometry_tools: BoolProperty(
        name="Show Fire Geometry Tools",
        description="Show Fire Geometry material tools",
        default=True,
    )
    show_roadway_tools: BoolProperty(
        name="Show Roadway Tools",
        description="Show Roadway material and weld tools",
        default=True,
    )
    fire_geometry_object: PointerProperty(
        name="Fire Geometry Object",
        description="Fire Geometry LOD mesh stored in Geometries collection",
        type=bpy.types.Object,
        poll=_poll_fire_geometry_object,
    )
    fire_geometry_material: EnumProperty(
        name="Fire Geometry Material",
        description="Current material on the Fire Geometry object",
        items=get_fire_geometry_material_enum_items,
        update=_on_fire_geometry_material_changed,
    )
    roadway_object: PointerProperty(
        name="Roadway Object",
        description="Roadway LOD mesh stored in Misc collection",
        type=bpy.types.Object,
        poll=_poll_roadway_object,
    )
    roadway_material: EnumProperty(
        name="Roadway Material",
        description="Current material on the Roadway object",
        items=get_roadway_material_enum_items,
        update=_on_roadway_material_changed,
    )
    roadway_weld_distance: FloatProperty(
        name="Roadway Weld Distance",
        description="Merge nearly coincident Roadway vertices so AI pathing stays fully connected",
        default=0.0001,
        min=0.0,
        precision=6,
        unit="LENGTH",
    )


# ------------------------------------------------------------------------
#  Operators (scatter)
# ------------------------------------------------------------------------

class CRAY_OT_LoadConfig(Operator):
    bl_idname = "cray.load_config"
    bl_label = "Load .cpp & Parse"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.cray_settings
        if not s.config_path:
            self.report({"ERROR"}, "Config .cpp path is empty")
            return {"CANCELLED"}

        config_abs = bpy.path.abspath(s.config_path)
        if not os.path.isfile(config_abs):
            self.report({"ERROR"}, f"Config file not found: {config_abs}")
            return {"CANCELLED"}

        try:
            parse_dayz_config(config_abs)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to parse config '{config_abs}': {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not CONFIG_SURFACES:
            self.report({"WARNING"}, "No surfaces found in CfgSurfaceCharacters")
        else:
            self.report({"INFO"}, f"Loaded {len(CONFIG_SURFACES)} surfaces and {len(CONFIG_CLUTTER)} clutter classes")

        s.selected_surface = "NONE"
        return {"FINISHED"}


class CRAY_OT_ScatterProxies(Operator):
    bl_idname = "object.cray_scatter_proxies"
    bl_label = "Scatter Proxies (DayZ-style)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.cray_settings
        try:
            obj = _resolve_scatter_edit_mesh_object(context)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}
        if not s.config_path:
            self.report({"ERROR"}, "Config .cpp path is not set")
            return {"CANCELLED"}
        if s.selected_surface == "NONE":
            self.report({"ERROR"}, "Surface is not selected")
            return {"CANCELLED"}
        if not hasattr(obj, "a3ob_properties_object_proxy"):
            self.report({"ERROR"}, "Missing 'a3ob_properties_object_proxy' (check Arma 3 Object Builder).")
            return {"CANCELLED"}

        config_abs = bpy.path.abspath(s.config_path)
        if not os.path.isfile(config_abs):
            self.report({"ERROR"}, f"Config file not found: {config_abs}")
            return {"CANCELLED"}

        try:
            parse_dayz_config(config_abs)
            clutter_names, clutter_probs, clutter_defs = build_clutter_distribution(s.selected_surface)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        triangles = _collect_selected_face_triangles_world(obj)
        if not triangles:
            self.report({"ERROR"}, "Select polygons in Edit Mode first")
            return {"CANCELLED"}

        if s.density_scale <= 0.0:
            self.report({"ERROR"}, "Density scale must be > 0")
            return {"CANCELLED"}
        grid = s.grid_size / math.sqrt(s.density_scale)
        if grid <= 0.0:
            self.report({"ERROR"}, "Grid size must be > 0")
            return {"CANCELLED"}

        if obj.users_collection:
            target_coll = obj.users_collection[0]
        else:
            target_coll = context.scene.collection

        cell_area = grid * grid
        if cell_area <= 0.0:
            self.report({"ERROR"}, "Density parameters produced invalid sample area")
            return {"CANCELLED"}

        return_to_edit = (obj.mode == "EDIT")
        if return_to_edit:
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception as e:
                self.report({"ERROR"}, f"Failed to switch to Object Mode: {_fmt_exc(e)}")
                return {"CANCELLED"}

        created_count = 0
        proxy_index = 0
        candidate_count = 0
        skipped_by_probability = 0
        limit_reached = False
        total_area = 0.0
        removed_count = 0
        try:
            removed_count = _clear_generated_scatter_proxies(obj)

            for tri_idx, (v0, v1, v2, tri_normal, tri_area) in enumerate(triangles, start=1):
                total_area += tri_area
                slope_factor = _scatter_slope_density_factor(tri_normal, s.slope_falloff)
                if slope_factor <= 1e-6:
                    continue

                expected = (tri_area / cell_area) * slope_factor
                tri_rng = random.Random((int(s.seed) ^ (tri_idx * 2654435761)) & 0xFFFFFFFFFFFFFFFF)
                samples = int(expected)
                if tri_rng.random() < max(0.0, expected - samples):
                    samples += 1

                for sample_idx in range(samples):
                    if s.max_proxies > 0 and created_count >= s.max_proxies:
                        limit_reached = True
                        break

                    candidate_count += 1
                    sample_rng = random.Random(
                        ((int(s.seed) & 0xFFFFFFFF) ^ (tri_idx * 73856093) ^ ((sample_idx + 1) * 19349663))
                        & 0xFFFFFFFFFFFFFFFF
                    )
                    if s.spawn_probability < 1.0 and sample_rng.random() > s.spawn_probability:
                        skipped_by_probability += 1
                        continue

                    hit_loc = _sample_point_on_triangle(v0, v1, v2, sample_rng)
                    clutter_class = pick_weighted_random(clutter_names, clutter_probs, rng=sample_rng)
                    c_def = clutter_defs[clutter_class]
                    proxy_index += 1

                    create_proxy_object(
                        context=context,
                        collection=target_coll,
                        parent_obj=obj,
                        location=hit_loc,
                        normal=tri_normal,
                        model_path=c_def["model"],
                        proxy_index=proxy_index,
                        scale_min=c_def.get("scaleMin", 1.0),
                        scale_max=c_def.get("scaleMax", 1.0),
                        rng=sample_rng,
                    )
                    created_count += 1
                if limit_reached:
                    break
        finally:
            if return_to_edit:
                try:
                    context.view_layer.objects.active = obj
                except Exception:
                    pass
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass

        limit_suffix = " (max limit reached)" if limit_reached else ""
        self.report(
            {"INFO"},
            (
                f"Removed {removed_count}, created {created_count} proxies from {len(triangles)} selected triangle(s)"
                f" | area: {total_area:.2f}, candidates: {candidate_count}, prob-skip: {skipped_by_probability}"
                f"{limit_suffix}"
            ),
        )
        return {"FINISHED"}


# ------------------------------------------------------------------------
#  Snap points (.sp_*) for Memory LOD
# ------------------------------------------------------------------------

_SP_GROUP_RE = re.compile(r"^[A-Za-z0-9_]+$")
_SP_P3D_NAME_RE = re.compile(r"^[A-Za-z0-9]+$")
_SP_PAIR_CODE_RE = re.compile(r"^[A-Za-z0-9]{1,3}$")

_A3OB_IMPORT_CANDIDATES = (
    (
        "a3ob.import_p3d",
        (
            "filepath",
            "first_lod_only",
            "absolute_paths",
            "enclose",
            "groupby",
            "additional_data_allowed",
            "additional_data",
            "validate_meshes",
            "proxy_action",
            "translate_selections",
            "cleanup_empty_selections",
            "load_textures",
        ),
    ),
    ("import_scene.a3ob_p3d", ("filepath",)),
    ("import_scene.a3ob_model", ("filepath",)),
    ("a3ob.import_model", ("filepath",)),
)

_A3OB_EXPORT_CANDIDATES = (
    (
        "a3ob.export_p3d",
        (
            "filepath",
            "use_selection",
            "visible_only",
            "relative_paths",
            "preserve_normals",
            "validate_meshes",
            "apply_transforms",
            "apply_modifiers",
            "sort_sections",
            "lod_collisions",
            "validate_lods",
            "validate_lods_warning_errors",
            "generate_components",
            "force_lowercase",
        ),
    ),
    ("export_scene.a3ob_p3d", ("filepath", "use_selection")),
    ("a3ob.export_model", ("filepath", "use_selection")),
)

_A3OB_IMPORT_READ_FILE_PATCHES = []
_A3OB_IMPORT_TRACKING_SUPPRESS_DEPTH = 0

def _op_handle(op_idname: str):
    try:
        mod, op = op_idname.split(".", 1)
    except ValueError:
        return None
    mod_obj = getattr(bpy.ops, mod, None)
    if mod_obj is None:
        return None
    return getattr(mod_obj, op, None)

def _has_any_a3ob_import_ops():
    return any(_op_handle(op) is not None for op, _ in _A3OB_IMPORT_CANDIDATES)

def _has_any_a3ob_io_ops():
    has_import = _has_any_a3ob_import_ops()
    has_export = any(_op_handle(op) is not None for op, _ in _A3OB_EXPORT_CANDIDATES)
    return has_import and has_export

def _call_first_available(op_candidates, **kwargs):
    last_err = None
    for op_idname, allowed_keys in op_candidates:
        fn = _op_handle(op_idname)
        if fn is None:
            continue
        payload = {k: v for k, v in kwargs.items() if k in allowed_keys}
        try:
            rna = fn.get_rna_type()
            valid_keys = {prop.identifier for prop in rna.properties if prop.identifier != "rna_type"}
            payload = {k: v for k, v in payload.items() if k in valid_keys}
        except Exception:
            pass
        try:
            result = fn(**payload)
            if isinstance(result, set) and "CANCELLED" in result:
                last_err = RuntimeError(f"{op_idname} returned CANCELLED")
                continue
            return result, op_idname, None
        except Exception as e:
            last_err = e
            continue
    return None, None, last_err


@contextmanager
def _suppress_a3ob_import_tracking():
    global _A3OB_IMPORT_TRACKING_SUPPRESS_DEPTH
    _A3OB_IMPORT_TRACKING_SUPPRESS_DEPTH += 1
    try:
        yield
    finally:
        _A3OB_IMPORT_TRACKING_SUPPRESS_DEPTH = max(0, _A3OB_IMPORT_TRACKING_SUPPRESS_DEPTH - 1)


def _import_first_available_module(module_names):
    for module_name in module_names:
        try:
            return importlib.import_module(module_name)
        except Exception:
            continue
    return None


@contextmanager
def _temporary_disable_a3ob_lod_validation(enabled: bool):
    if not enabled:
        yield False
        return

    export_mod = _get_a3ob_export_p3d_module()
    validator_mod = _get_a3ob_validator_module()
    candidate_classes = []

    for mod in (export_mod, validator_mod):
        cls = getattr(mod, "Validator", None) if mod is not None else None
        if cls is not None:
            candidate_classes.append(cls)

    for module_name, mod in list(sys.modules.items()):
        if not module_name.endswith(".utilities.validator") and not module_name.endswith(".io.export_p3d"):
            continue
        cls = getattr(mod, "Validator", None)
        if cls is not None:
            candidate_classes.append(cls)

    patched_validators = []
    seen_classes = set()
    for validator_cls in candidate_classes:
        try:
            key = id(validator_cls)
        except Exception:
            key = None
        if key is not None and key in seen_classes:
            continue
        if key is not None:
            seen_classes.add(key)
        original_validate = getattr(validator_cls, "validate_lod", None)
        if callable(original_validate):
            patched_validators.append((validator_cls, original_validate))

    patched_proxy_checks = []
    for mod in (export_mod,):
        original_validate_proxies = getattr(mod, "validate_proxies", None) if mod is not None else None
        if callable(original_validate_proxies):
            patched_proxy_checks.append((mod, original_validate_proxies))

    if not patched_validators and not patched_proxy_checks:
        yield False
        return

    def _always_valid(self, obj, lod, lazy=False, warns_errs=True, relative_paths=False):
        return True

    def _always_valid_proxies(operator, proxy_objects):
        return True

    for validator_cls, _original_validate in patched_validators:
        validator_cls.validate_lod = _always_valid
    for mod, _original_validate_proxies in patched_proxy_checks:
        mod.validate_proxies = _always_valid_proxies

    try:
        yield True
    finally:
        for validator_cls, original_validate in patched_validators:
            validator_cls.validate_lod = original_validate
        for mod, original_validate_proxies in patched_proxy_checks:
            mod.validate_proxies = original_validate_proxies


def _call_export_with_optional_relaxed_validation(force_all_lods: bool, **kwargs):
    with _temporary_disable_a3ob_lod_validation(force_all_lods) as relaxed:
        if force_all_lods:
            print("=== Batch Export Collections: Force export all LODs ===")
            print(
                "A3OB validation/proxy guards bypassed: "
                f"{'yes' if relaxed else 'no (A3OB modules were not found)'}"
            )
        return _call_first_available(_A3OB_EXPORT_CANDIDATES, **kwargs)


def _get_a3ob_export_p3d_module():
    return _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.export_p3d",
            "Arma3ObjectBuilder.io.export_p3d",
        )
    )


def _get_a3ob_validator_module():
    return _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.utilities.validator",
            "Arma3ObjectBuilder.utilities.validator",
        )
    )


def _get_a3ob_data_p3d_module():
    return _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.data_p3d",
            "Arma3ObjectBuilder.io.data_p3d",
        )
    )


def _lod_signature_key(signature: float) -> str:
    return f"{float(signature):.6e}"


def _a3ob_lod_signature_from_props(props, p3d_mod):
    lod_res_cls = getattr(p3d_mod, "P3D_LOD_Resolution", None)
    if lod_res_cls is None:
        return None

    try:
        lod_idx = int(getattr(props, "lod", 0))
    except Exception:
        return None

    lod_unknown = int(getattr(lod_res_cls, "UNKNOWN", -1))
    try:
        if lod_idx == lod_unknown:
            resolution = float(getattr(props, "resolution_float", 0.0) or 0.0)
        else:
            resolution = float(getattr(props, "resolution", 0.0) or 0.0)
    except Exception:
        resolution = 0.0

    try:
        signature = lod_res_cls.encode(lod_idx, resolution)
    except Exception:
        return None
    if signature is None:
        return None
    return float(signature)


def _collect_expected_lod_entries(export_objects):
    p3d_mod = _get_a3ob_data_p3d_module()
    if p3d_mod is None:
        return {}

    expected = {}
    for obj in export_objects:
        if obj is None or obj.type != "MESH" or obj.parent is not None:
            continue
        if not hasattr(obj, "a3ob_properties_object"):
            continue

        props = obj.a3ob_properties_object
        if not bool(getattr(props, "is_a3_lod", False)):
            continue

        signature = _a3ob_lod_signature_from_props(props, p3d_mod)
        if signature is None:
            continue

        try:
            lod_name = str(props.get_name())
        except Exception:
            lod_name = obj.name

        key = _lod_signature_key(signature)
        rec = expected.get(key)
        if rec is None:
            expected[key] = {
                "signature": signature,
                "lod_name": lod_name,
                "objects": [obj.name],
            }
        else:
            if obj.name not in rec["objects"]:
                rec["objects"].append(obj.name)

    return expected

def _is_a3ob_resolution_lod_object(obj) -> bool:
    if obj is None or obj.type != "MESH":
        return False
    if not hasattr(obj, "a3ob_properties_object"):
        return False

    try:
        props = obj.a3ob_properties_object
        if not bool(getattr(props, "is_a3_lod", False)):
            return False
        lod_value = str(getattr(props, "lod", "") or "").strip()
        if lod_value == "0":
            return True
        try:
            return int(lod_value) == 0
        except Exception:
            return False
    except Exception:
        return False

def _format_resolution_lod_index_value(value) -> str:
    try:
        num = float(value)
    except Exception:
        raw = str(value or "").strip()
        return raw or "0"

    if math.isfinite(num) and abs(num - round(num)) <= 1e-6:
        return str(int(round(num)))
    return f"{num:g}"

def _actual_top_level_collection_key_under_root(root_collection, obj):
    source_path = _best_object_collection_path_under_root(root_collection, obj)
    if not source_path:
        return "<root>", ("<root>",)

    actual_parts = tuple(getattr(col, "name", "") or "" for col in list(source_path)[1:])
    if not actual_parts:
        return "<root>", ("<root>",)
    return actual_parts[0], actual_parts

def _collect_resolution_lod_index_conflicts(root_collection, export_objects):
    buckets = {}

    for obj in export_objects:
        if not _is_a3ob_resolution_lod_object(obj):
            continue

        try:
            props = obj.a3ob_properties_object
            resolution_value = int(getattr(props, "resolution", 0) or 0)
        except Exception:
            resolution_value = 0

        top_level_key, actual_parts = _actual_top_level_collection_key_under_root(root_collection, obj)
        resolution_key = _format_resolution_lod_index_value(resolution_value)

        branch_bucket = buckets.setdefault(top_level_key, {})
        branch_bucket.setdefault(resolution_key, []).append(
            {
                "object_name": obj.name,
                "actual_branch": actual_parts,
            }
        )

    conflicts = []
    for branch_key, resolution_map in buckets.items():
        for resolution_key, items in resolution_map.items():
            if len(items) <= 1:
                continue
            conflicts.append(
                {
                    "branch_name": branch_key,
                    "resolution_index": resolution_key,
                    "items": items,
                }
            )

    conflicts.sort(
        key=lambda rec: (
            rec["branch_name"],
            rec["resolution_index"],
        )
    )
    return conflicts

def _report_resolution_lod_index_conflicts_in_console(collection_name: str, filepath: str, conflicts):
    if not conflicts:
        return

    print("=== Batch Export Collections: Duplicate Resolution LOD indices ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(
        "WARNING: Duplicate Resolution LOD indices were found inside the same actual top-level collection branch."
    )
    for rec in conflicts:
        print(f"Top-level branch: {rec['branch_name']}")
        print(f"Resolution index: {rec['resolution_index']}")
        for item in rec["items"]:
            actual_branch = " > ".join(item["actual_branch"])
            print(f" - {item['object_name']} | actual branch: {actual_branch}")

def _is_a3ob_lod_root_object(obj) -> bool:
    if obj is None or obj.type != "MESH" or obj.parent is not None:
        return False
    if not hasattr(obj, "a3ob_properties_object"):
        return False
    try:
        return bool(getattr(obj.a3ob_properties_object, "is_a3_lod", False))
    except Exception:
        return False

def _is_a3ob_proxy_object(obj) -> bool:
    if obj is None or obj.type != "MESH":
        return False
    if not hasattr(obj, "a3ob_properties_object_proxy"):
        return False
    try:
        return bool(getattr(obj.a3ob_properties_object_proxy, "is_a3_proxy", False))
    except Exception:
        return False

def _iter_a3ob_export_meshes_for_lod_root(root_obj):
    if not _is_a3ob_lod_root_object(root_obj):
        return []

    meshes = [root_obj]
    for child in getattr(root_obj, "children", []):
        if child is None or child.type != "MESH":
            continue
        if _is_a3ob_proxy_object(child):
            continue
        meshes.append(child)
    return meshes


def _geometry_lod_root_objects(export_objects):
    roots = []
    seen = set()
    for obj in export_objects or []:
        if not _is_a3ob_lod_root_object(obj):
            continue
        try:
            lod_token = str(getattr(obj.a3ob_properties_object, "lod", "") or "").strip()
        except Exception:
            continue
        if lod_token != _GEOMETRY_LOD_TOKEN:
            continue
        try:
            ptr = obj.as_pointer()
        except Exception:
            ptr = id(obj)
        if ptr in seen:
            continue
        seen.add(ptr)
        roots.append(obj)
    return roots


def _read_mesh_mass_values(obj):
    if obj is None or getattr(obj, "type", None) != "MESH" or obj.data is None:
        return []
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        layer = bm.verts.layers.float.get("a3ob_mass")
        if layer is None:
            return [0.0 for _vert in bm.verts]
        return [float(vert[layer]) for vert in bm.verts]
    finally:
        bm.free()


def _write_mesh_mass_uniform(obj, value_per_vertex: float):
    if obj is None or getattr(obj, "type", None) != "MESH" or obj.data is None:
        return 0
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        layer = bm.verts.layers.float.get("a3ob_mass")
        if layer is None:
            layer = bm.verts.layers.float.new("a3ob_mass")
        for vert in bm.verts:
            vert[layer] = value_per_vertex
        changed = len(bm.verts)
        bm.to_mesh(obj.data)
        obj.data.update()
        return changed
    finally:
        bm.free()


def _prepare_geometry_lod_mass_for_export(export_objects):
    prepared = []
    for root_obj in _geometry_lod_root_objects(export_objects):
        meshes = list(_iter_a3ob_export_meshes_for_lod_root(root_obj))
        if not meshes:
            continue

        values_by_obj = []
        total_verts = 0
        total_mass = 0.0
        has_missing_mass = False
        for mesh_obj in meshes:
            values = _read_mesh_mass_values(mesh_obj)
            if not values:
                continue
            values_by_obj.append((mesh_obj, values))
            total_verts += len(values)
            total_mass += math.fsum(values)
            if any(value <= 1e-7 for value in values):
                has_missing_mass = True

        if total_verts <= 0:
            continue
        if total_mass > 1e-7 and not has_missing_mass:
            continue

        target_total_mass = total_mass if total_mass > 1e-7 else _GEOMETRY_LOD_DEFAULT_TOTAL_MASS
        value_per_vertex = target_total_mass / total_verts
        changed_verts = 0
        for mesh_obj, _values in values_by_obj:
            changed_verts += _write_mesh_mass_uniform(mesh_obj, value_per_vertex)
        if changed_verts:
            prepared.append((root_obj.name, changed_verts, target_total_mass))

    return prepared


def _mesh_ngon_stats(mesh_obj):
    if mesh_obj is None or mesh_obj.type != "MESH" or mesh_obj.data is None:
        return 0, 0

    ngon_count = 0
    max_sides = 0
    for poly in getattr(mesh_obj.data, "polygons", []):
        side_count = len(getattr(poly, "vertices", ()))
        if side_count <= 4:
            continue
        ngon_count += 1
        if side_count > max_sides:
            max_sides = side_count
    return ngon_count, max_sides


def _mesh_isolated_vertex_count(mesh_obj):
    return len(_mesh_isolated_vertex_indices(mesh_obj))


def _mesh_isolated_vertex_indices(mesh_obj):
    if mesh_obj is None or mesh_obj.type != "MESH" or mesh_obj.data is None:
        return []

    mesh = mesh_obj.data
    if not getattr(mesh, "vertices", None):
        return []

    used_vertex_indices = set()
    for edge in getattr(mesh, "edges", []):
        try:
            used_vertex_indices.update(edge.vertices)
        except Exception:
            pass
    for poly in getattr(mesh, "polygons", []):
        try:
            used_vertex_indices.update(poly.vertices)
        except Exception:
            pass

    return [vert.index for vert in mesh.vertices if vert.index not in used_vertex_indices]


def _is_point_cloud_export_lod(root_obj, lod_token: str, lod_name: str) -> bool:
    if lod_token in _MODEL_SPLIT_POINT_CLOUD_LODS:
        return True

    logical_names = {
        _logical_collection_name(_MEMORY_COLLECTION_NAME),
        _logical_collection_name(_MemoryLodManager.OBJECT_NAME),
    }
    return _logical_collection_name(lod_name) in logical_names or _logical_collection_name(root_obj.name) in logical_names


def _collect_export_loose_vertex_warnings(root_collection, export_objects):
    warnings = []
    seen_lod_roots = set()

    for obj in export_objects:
        if not _is_a3ob_lod_root_object(obj):
            continue
        try:
            root_ptr = obj.as_pointer()
        except Exception:
            root_ptr = None
        if root_ptr in seen_lod_roots:
            continue
        if root_ptr is not None:
            seen_lod_roots.add(root_ptr)

        try:
            lod_token = str(getattr(obj.a3ob_properties_object, "lod", "") or "").strip()
        except Exception:
            lod_token = ""

        try:
            lod_name = str(obj.a3ob_properties_object.get_name())
        except Exception:
            lod_name = obj.name

        if _is_point_cloud_export_lod(obj, lod_token, lod_name):
            continue

        for mesh_obj in _iter_a3ob_export_meshes_for_lod_root(obj):
            isolated_indices = _mesh_isolated_vertex_indices(mesh_obj)
            isolated_count = len(isolated_indices)
            if isolated_count <= 0:
                continue
            _, actual_parts = _actual_top_level_collection_key_under_root(root_collection, mesh_obj)
            warnings.append(
                {
                    "lod_object_name": obj.name,
                    "lod_name": lod_name,
                    "mesh_object_name": mesh_obj.name,
                    "mesh_object": mesh_obj,
                    "isolated_count": isolated_count,
                    "isolated_indices": isolated_indices,
                    "actual_branch": actual_parts,
                }
            )

    warnings.sort(
        key=lambda rec: (
            rec["lod_name"],
            rec["mesh_object_name"],
        )
    )
    return warnings


def _report_export_loose_vertex_warnings_in_console(collection_name: str, filepath: str, warnings):
    if not warnings:
        return

    print("=== Batch Export Collections: Loose vertices warning ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(
        "WARNING: Export continued, but these LODs contain isolated vertices with no edges or faces. "
        "Only Point clouds > Memory is allowed to keep loose points."
    )
    for item in warnings:
        actual_branch = " > ".join(item["actual_branch"])
        indices = list(item.get("isolated_indices", []) or [])
        index_preview = ", ".join(str(idx) for idx in indices[:20])
        if len(indices) > 20:
            index_preview += ", ..."
        if not index_preview:
            index_preview = "<not available>"
        print(
            f" - LOD: {item['lod_name']} | root: {item['lod_object_name']} | "
            f"mesh: {item['mesh_object_name']} | loose vertices: {item['isolated_count']} | "
            f"branch: {actual_branch} | indices: {index_preview}"
        )


def _loose_vertices_outside_memory_root_collections(context):
    scene = getattr(context, "scene", None)
    if scene is None or getattr(scene, "collection", None) is None:
        return []

    active_obj = getattr(context, "active_object", None)
    active_root = _find_p3d_root_collection_for_object(context, active_obj)
    if active_root is not None:
        return [active_root]

    roots = []
    seen = set()

    for obj in getattr(context, "selected_objects", []) or []:
        root = _find_p3d_root_collection_for_object(context, obj)
        if root is None:
            continue
        try:
            ptr = root.as_pointer()
        except Exception:
            ptr = id(root)
        if ptr in seen:
            continue
        seen.add(ptr)
        roots.append(root)

    if roots:
        return roots

    p3d_roots = list(_iter_p3d_root_collections(scene))
    if p3d_roots:
        return [root for root in p3d_roots if _collection_has_any_mesh(root)]

    return [col for col in scene.collection.children if _collection_has_any_mesh(col)]


def _collect_loose_vertices_outside_memory_records(context):
    records = []
    seen = set()

    for root_collection in _loose_vertices_outside_memory_root_collections(context):
        objects = _collect_collection_objects_recursive(root_collection)
        warnings = _collect_export_loose_vertex_warnings(root_collection, objects)
        for item in warnings:
            mesh_obj = item.get("mesh_object")
            if mesh_obj is None:
                mesh_obj = bpy.data.objects.get(item.get("mesh_object_name", ""))
            if mesh_obj is None or mesh_obj.type != "MESH" or mesh_obj.data is None:
                continue

            isolated_indices = list(item.get("isolated_indices", []) or [])
            if not isolated_indices:
                isolated_indices = _mesh_isolated_vertex_indices(mesh_obj)
            if not isolated_indices:
                continue

            try:
                key = (root_collection.as_pointer(), mesh_obj.as_pointer())
            except Exception:
                key = (id(root_collection), id(mesh_obj))
            if key in seen:
                continue
            seen.add(key)

            rec = dict(item)
            rec["root_collection"] = root_collection
            rec["mesh_object"] = mesh_obj
            rec["isolated_indices"] = isolated_indices
            rec["isolated_count"] = len(isolated_indices)
            records.append(rec)

    records.sort(
        key=lambda rec: (
            getattr(rec.get("root_collection"), "name", ""),
            rec.get("lod_name", ""),
            rec.get("mesh_object_name", ""),
        )
    )
    return records


def _collect_export_ngon_issues(root_collection, export_objects):
    issues = []
    seen_lod_roots = set()

    for obj in export_objects:
        if not _is_a3ob_lod_root_object(obj):
            continue
        try:
            root_ptr = obj.as_pointer()
        except Exception:
            root_ptr = None
        if root_ptr in seen_lod_roots:
            continue
        if root_ptr is not None:
            seen_lod_roots.add(root_ptr)

        try:
            lod_name = str(obj.a3ob_properties_object.get_name())
        except Exception:
            lod_name = obj.name

        for mesh_obj in _iter_a3ob_export_meshes_for_lod_root(obj):
            ngon_count, max_sides = _mesh_ngon_stats(mesh_obj)
            if ngon_count <= 0:
                continue
            _, actual_parts = _actual_top_level_collection_key_under_root(root_collection, mesh_obj)
            issues.append(
                {
                    "lod_object_name": obj.name,
                    "lod_name": lod_name,
                    "mesh_object_name": mesh_obj.name,
                    "ngon_count": ngon_count,
                    "max_sides": max_sides,
                    "actual_branch": actual_parts,
                }
            )

    issues.sort(
        key=lambda rec: (
            rec["lod_name"],
            rec["mesh_object_name"],
        )
    )
    return issues

def _report_export_ngon_issues_in_console(collection_name: str, filepath: str, issues):
    if not issues:
        return

    print("=== Batch Export Collections: N-gons detected ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(
        "WARNING: A3OB validation will skip LODs that contain n-gons. "
        "Triangulate or remove faces with more than 4 vertices before export."
    )
    for item in issues:
        actual_branch = " > ".join(item["actual_branch"])
        print(
            f" - LOD: {item['lod_name']} | root: {item['lod_object_name']} | "
            f"mesh: {item['mesh_object_name']} | n-gon faces: {item['ngon_count']} | "
            f"max verts on one face: {item['max_sides']} | branch: {actual_branch}"
        )


def _read_exported_lod_entries(filepath: str):
    p3d_mod = _get_a3ob_data_p3d_module()
    if p3d_mod is None:
        raise RuntimeError("A3OB data_p3d module is not available")

    mlod = p3d_mod.P3D_MLOD.read_file(filepath, first_lod_only=False)
    exported = {}
    for lod in getattr(mlod, "lods", []):
        try:
            signature = float(lod.resolution)
        except Exception:
            continue
        key = _lod_signature_key(signature)
        exported[key] = {"signature": signature}
    return exported


def _report_missing_lods_in_console(collection_name: str, filepath: str, expected_entries, exported_entries):
    expected_keys = set(expected_entries.keys())
    exported_keys = set(exported_entries.keys())
    missing_keys = sorted(
        expected_keys - exported_keys,
        key=lambda k: expected_entries[k]["signature"],
    )
    if not missing_keys:
        return []

    print("=== Batch Export Collections: Missing LODs ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(
        "WARNING: Not all LODs were exported "
        f"(expected unique: {len(expected_keys)}, exported unique: {len(exported_keys)})"
    )
    for key in missing_keys:
        rec = expected_entries[key]
        objs = ", ".join(rec["objects"])
        print(f" - {rec['lod_name']} | signature: {rec['signature']:.6e} | object(s): {objs}")
    return missing_keys


def _format_lod_signature_preview(keys, entries, limit=8):
    if not keys:
        return "<none>"
    parts = []
    for key in list(keys)[:limit]:
        rec = entries.get(key, {})
        lod_name = str(rec.get("lod_name", "") or "").strip()
        signature = rec.get("signature", None)
        if signature is None:
            text = key
        else:
            text = f"{float(signature):.6e}"
        if lod_name:
            text = f"{lod_name} ({text})"
        parts.append(text)
    if len(keys) > limit:
        parts.append("...")
    return ", ".join(parts)


def _read_lod_entries_if_possible(filepath: str):
    try:
        return _read_exported_lod_entries(filepath), ""
    except Exception as e:
        return None, _fmt_exc(e)


def _should_create_export_backup(filepath: str, expected_entries):
    backup_path = filepath + ".bak"
    if not os.path.isfile(filepath):
        return False, "target file does not exist", []

    target_entries, target_err = _read_lod_entries_if_possible(filepath)
    if target_entries is None:
        return False, f"could not verify existing target LODs: {target_err}", []

    missing_expected = []
    if expected_entries:
        missing_expected = sorted(
            set(expected_entries.keys()) - set(target_entries.keys()),
            key=lambda k: expected_entries[k]["signature"],
        )
        if missing_expected:
            return (
                False,
                (
                    "existing target already misses "
                    f"{len(missing_expected)}/{len(expected_entries)} expected LOD signature(s)"
                ),
                missing_expected,
            )

    if os.path.isfile(backup_path):
        backup_entries, backup_err = _read_lod_entries_if_possible(backup_path)
        if backup_entries is not None and len(target_entries) < len(backup_entries):
            return (
                False,
                (
                    "existing target has fewer LOD signatures "
                    f"({len(target_entries)}) than current backup ({len(backup_entries)})"
                ),
                [],
            )
        if backup_entries is None:
            print("=== Batch Export Collections: Backup verification warning ===")
            print(f"Backup: {backup_path}")
            print(f"WARNING: Existing .bak could not be checked: {backup_err}")

    return True, f"verified existing target with {len(target_entries)} LOD signature(s)", []


def _pending_export_backup_path(filepath: str) -> str:
    return filepath + ".bak.pending"


def _stage_export_backup(filepath: str):
    if not os.path.isfile(filepath):
        return "", "target file does not exist"

    pending_path = _pending_export_backup_path(filepath)
    try:
        if os.path.exists(pending_path):
            os.remove(pending_path)
        shutil.copy2(filepath, pending_path)
    except Exception as e:
        return "", _fmt_exc(e)
    return pending_path, ""


def _lod_entries_missing_expected(entries, expected_entries):
    if not expected_entries:
        return []
    if entries is None:
        return list(expected_entries.keys())
    return sorted(
        set(expected_entries.keys()) - set(entries.keys()),
        key=lambda k: expected_entries[k]["signature"],
    )


def _promote_pending_export_backup(pending_path: str, backup_path: str):
    if not pending_path or not os.path.isfile(pending_path):
        raise RuntimeError("pending backup file is missing")
    shutil.copy2(pending_path, backup_path)
    try:
        os.remove(pending_path)
    except Exception:
        pass


def _discard_pending_export_backup(pending_path: str):
    if not pending_path:
        return
    try:
        if os.path.exists(pending_path):
            os.remove(pending_path)
    except Exception:
        pass


def _finalize_export_backup(filepath: str, pending_path: str, expected_entries, export_complete: bool):
    backup_path = filepath + ".bak"
    if not pending_path:
        return "none", "no backup was staged", []

    pending_entries, pending_err = _read_lod_entries_if_possible(pending_path)
    if pending_entries is None:
        _discard_pending_export_backup(pending_path)
        return "skipped", f"could not verify staged backup: {pending_err}", []

    pending_missing = _lod_entries_missing_expected(pending_entries, expected_entries)
    backup_entries = None
    backup_err = ""
    if os.path.isfile(backup_path):
        backup_entries, backup_err = _read_lod_entries_if_possible(backup_path)

    backup_has_more_lods = (
        backup_entries is not None
        and len(backup_entries) > len(pending_entries)
    )

    if export_complete:
        if backup_has_more_lods:
            _discard_pending_export_backup(pending_path)
            return (
                "preserved",
                (
                    "existing .bak has more LOD signatures "
                    f"({len(backup_entries)}) than pre-export target ({len(pending_entries)})"
                ),
                [],
            )
        _promote_pending_export_backup(pending_path, backup_path)
        if pending_missing:
            return (
                "updated",
                (
                    "export completed with more expected LODs than the pre-export target; "
                    "saved the replaced target as .bak"
                ),
                pending_missing,
            )
        return "updated", f"saved pre-export target with {len(pending_entries)} LOD signature(s)", []

    if pending_missing:
        _discard_pending_export_backup(pending_path)
        if backup_entries is not None:
            return (
                "preserved",
                (
                    "export was partial and the pre-export target was also missing "
                    f"{len(pending_missing)}/{len(expected_entries)} expected LOD signature(s); "
                    "kept existing .bak"
                ),
                pending_missing,
            )
        return (
            "skipped",
            (
                "export was partial and the pre-export target was also missing "
                f"{len(pending_missing)}/{len(expected_entries)} expected LOD signature(s)"
            ),
            pending_missing,
        )

    if backup_has_more_lods:
        _discard_pending_export_backup(pending_path)
        return (
            "preserved",
            (
                "export was partial; kept existing .bak because it has more LOD signatures "
                f"({len(backup_entries)}) than pre-export target ({len(pending_entries)})"
            ),
            [],
        )

    if backup_entries is None and backup_err:
        print("=== Batch Export Collections: Backup verification warning ===")
        print(f"Backup: {backup_path}")
        print(f"WARNING: Existing .bak could not be checked: {backup_err}")

    _promote_pending_export_backup(pending_path, backup_path)
    return (
        "updated",
        (
            "export was partial, but the pre-export target had all expected LOD signatures; "
            "saved it as .bak"
        ),
        [],
    )


def _report_export_backup_skipped_in_console(collection_name: str, filepath: str, reason: str, missing_keys, expected_entries):
    print("=== Batch Export Collections: Backup skipped ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(f"Backup: {filepath}.bak")
    print(f"WARNING: Existing target was not copied to .bak: {reason}")
    if missing_keys:
        print(
            "Missing in existing target: "
            f"{_format_lod_signature_preview(missing_keys, expected_entries)}"
        )


def _report_export_backup_preserved_in_console(collection_name: str, filepath: str, reason: str, missing_keys, expected_entries):
    print("=== Batch Export Collections: Backup preserved ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(f"Backup: {filepath}.bak")
    print(f"INFO: Existing .bak was kept: {reason}")
    if missing_keys:
        print(
            "Missing in pre-export target: "
            f"{_format_lod_signature_preview(missing_keys, expected_entries)}"
        )


def _report_export_backup_updated_in_console(collection_name: str, filepath: str, reason: str, missing_keys, expected_entries):
    if not reason or not missing_keys:
        return
    print("=== Batch Export Collections: Backup updated ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(f"Backup: {filepath}.bak")
    print(f"INFO: {reason}")
    print(
        "Missing in pre-export target: "
        f"{_format_lod_signature_preview(missing_keys, expected_entries)}"
    )


class _A3OBValidationCaptureLogger:
    def __init__(self, depth=0):
        self.depth = depth
        self.lines = []

    def start_subproc(self, message=""):
        if message:
            self.step(message)
        self.depth += 1

    def end_subproc(self, showtime=False):
        self.depth = max(0, self.depth - 1)

    def step(self, message):
        self.lines.append(f"{'  ' * self.depth}{message}")


def _is_ascii_text(value) -> bool:
    try:
        str(value or "").encode("ascii")
        return True
    except Exception:
        return False


def _collect_a3ob_proxy_validation_diagnostics(operator, proxy_objects):
    lines = []
    for proxy in proxy_objects or []:
        original_name = ""
        try:
            original_name = str(proxy.get("a3ob_original_object", "") or "")
        except Exception:
            original_name = ""
        display_name = original_name or getattr(proxy, "name", "<unnamed proxy>")

        issues = []
        mesh = getattr(proxy, "data", None)
        poly_count = len(getattr(mesh, "polygons", []) or []) if mesh is not None else 0
        vert_count = len(getattr(mesh, "vertices", []) or []) if mesh is not None else 0
        first_face_verts = 0
        if mesh is not None and poly_count > 0:
            try:
                first_face_verts = len(mesh.polygons[0].vertices)
            except Exception:
                first_face_verts = 0
        if poly_count != 1 or first_face_verts != 3:
            issues.append(
                "geometry must be exactly one triangular face "
                f"(verts={vert_count}, faces={poly_count}, first_face_verts={first_face_verts})"
            )

        proxy_props = getattr(proxy, "a3ob_properties_object_proxy", None)
        if proxy_props is None:
            issues.append("missing A3OB proxy properties")
        else:
            try:
                proxy_path, _proxy_selection = proxy_props.to_placeholder(operator.relative_paths)
            except Exception as e:
                issues.append(f"proxy path read failed: {_fmt_exc(e)}")
            else:
                if not _is_ascii_text(proxy_path):
                    issues.append(f"proxy path has non-ASCII characters: {proxy_path}")

        bad_groups = [
            group.name for group in getattr(proxy, "vertex_groups", [])
            if not _is_ascii_text(getattr(group, "name", ""))
        ]
        if bad_groups:
            preview = ", ".join(bad_groups[:5])
            if len(bad_groups) > 5:
                preview += ", ..."
            issues.append(f"vertex group name has non-ASCII characters: {preview}")

        for slot_idx, slot in enumerate(getattr(proxy, "material_slots", []) or []):
            mat = getattr(slot, "material", None)
            if mat is None:
                continue
            mat_props = getattr(mat, "a3ob_properties_material", None)
            if mat_props is None:
                issues.append(f"material slot {slot_idx} '{mat.name}' is missing A3OB material properties")
                continue
            try:
                texture, material = mat_props.to_p3d(operator.relative_paths)
            except Exception as e:
                issues.append(f"material slot {slot_idx} '{mat.name}' read failed: {_fmt_exc(e)}")
                continue
            if not _is_ascii_text(texture) or not _is_ascii_text(material):
                issues.append(
                    f"material slot {slot_idx} '{mat.name}' has non-ASCII path: "
                    f"texture='{texture}', material='{material}'"
                )

        if issues:
            for issue in issues:
                lines.append(f"Proxy '{display_name}': {issue}")
        else:
            lines.append(f"Proxy '{display_name}': passed detailed proxy checks")

    return lines


def _make_a3ob_export_diagnostic_operator(force_all_lods: bool):
    operator = type("_NH_A3OBExportDiagnosticOperator", (), {})()
    operator.filepath = ""
    operator.use_selection = True
    operator.visible_only = False
    operator.relative_paths = True
    operator.preserve_normals = True
    operator.validate_meshes = False
    operator.apply_transforms = True
    operator.apply_modifiers = True
    operator.sort_sections = True
    operator.lod_collisions = "IGNORE" if force_all_lods else "SKIP"
    operator.validate_lods = False
    operator.validate_lods_warning_errors = False
    operator.generate_components = True
    operator.force_lowercase = True
    operator.renumber_components = False
    operator.translate_selections = False
    return operator


def _collect_a3ob_lod_export_diagnostics(context, source_obj, force_all_lods: bool):
    if source_obj is None or getattr(source_obj, "type", None) != "MESH":
        return ["ERROR: source LOD object is not a mesh"]

    export_mod = _get_a3ob_export_p3d_module()
    validator_mod = _get_a3ob_validator_module()
    validator_cls = getattr(export_mod, "Validator", None) if export_mod is not None else None
    if validator_cls is None and validator_mod is not None:
        validator_cls = getattr(validator_mod, "Validator", None)

    required_names = (
        "create_temp_collection",
        "cleanup_temp_collection",
        "duplicate_object",
        "get_sub_objects",
        "merge_sub_objects",
        "validate_proxies",
        "temporary_component",
    )
    if export_mod is None or validator_cls is None or any(getattr(export_mod, name, None) is None for name in required_names):
        return ["ERROR: A3OB export diagnostics are unavailable (module API not found)"]

    temp_collection = None
    lines = []
    operator = _make_a3ob_export_diagnostic_operator(force_all_lods)
    try:
        temp_collection = export_mod.create_temp_collection(context)
        if getattr(source_obj, "mode", "OBJECT") != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass

        main_obj = export_mod.duplicate_object(source_obj, temp_collection)
        sub_objects, proxy_objects = export_mod.get_sub_objects(source_obj, temp_collection)
        lines.append(
            "Preprocess: "
            f"children={len(getattr(source_obj, 'children', []) or [])}, "
            f"sub-objects={len(sub_objects)}, proxies={len(proxy_objects)}"
        )

        proxy_valid = bool(export_mod.validate_proxies(operator, proxy_objects))
        if not proxy_valid:
            lines.append(
                "ERROR: proxy validation failed "
                "(proxy must be one triangle and use ASCII paths/materials/groups)"
            )
            lines.extend(_collect_a3ob_proxy_validation_diagnostics(operator, proxy_objects))

        export_mod.merge_sub_objects(operator, main_obj, sub_objects)
        mesh = getattr(main_obj, "data", None)
        if mesh is not None:
            lines.append(
                "Merged mesh: "
                f"verts={len(getattr(mesh, 'vertices', []))}, "
                f"edges={len(getattr(mesh, 'edges', []))}, "
                f"faces={len(getattr(mesh, 'polygons', []))}, "
                f"materials={len(getattr(main_obj, 'material_slots', []))}, "
                f"uv_layers={len(getattr(mesh, 'uv_layers', []))}"
            )

        logger = _A3OBValidationCaptureLogger()
        validator = validator_cls(logger)
        lod_token = str(getattr(main_obj.a3ob_properties_object, "lod", "") or "")
        with export_mod.temporary_component(operator, main_obj):
            validation_valid = bool(
                validator.validate_lod(
                    main_obj,
                    lod_token,
                    False,
                    False,
                    True,
                )
            )

        interesting_lines = [
            line for line in logger.lines
            if "ERROR:" in line or "WARNING:" in line or "Validation " in line
        ]
        lines.extend(interesting_lines or logger.lines[-8:])

        if proxy_valid and validation_valid:
            lines.append(
                "A3OB generic validation passed after merge; if this LOD is still missing, "
                "the skip likely happened after validation (duplicate signature or writer-side failure)."
            )
        return lines
    except Exception as e:
        return [f"ERROR: diagnostic failed: {_fmt_exc(e)}"]
    finally:
        if temp_collection is not None:
            try:
                export_mod.cleanup_temp_collection(temp_collection)
            except Exception:
                pass


def _report_missing_lod_diagnostics_in_console(
    context,
    collection_name: str,
    filepath: str,
    missing_keys,
    expected_entries,
    export_objects,
    force_all_lods: bool,
):
    if not missing_keys:
        return

    by_name = {}
    for obj in export_objects or []:
        name = getattr(obj, "name", "")
        if name:
            by_name.setdefault(name, obj)

    print("=== Batch Export Collections: Missing LOD diagnostics ===")
    print(f"Collection: {collection_name}")
    print(f"File: {filepath}")
    print(f"Force export all LODs: {'ON' if force_all_lods else 'OFF'}")
    for key in missing_keys:
        rec = expected_entries.get(key, {})
        print(f"LOD: {rec.get('lod_name', key)} | signature: {rec.get('signature', 0.0):.6e}")
        for obj_name in rec.get("objects", []):
            obj = by_name.get(obj_name) or bpy.data.objects.get(obj_name)
            print(f"Object: {obj_name}")
            diagnostic_lines = _collect_a3ob_lod_export_diagnostics(context, obj, force_all_lods)
            for line in diagnostic_lines[:40]:
                print(f" - {line}")
            if len(diagnostic_lines) > 40:
                print(f" - ... {len(diagnostic_lines) - 40} more diagnostic line(s)")


def _is_memory_lod_mesh_object(obj) -> bool:
    return _MemoryLodManager.is_memory_lod_mesh_object(obj)

def _pick_memory_lod_object(context, source_obj):
    return _MemoryLodManager(context, source_obj).pick_existing_object()

def _set_memory_lod_a3ob_props(memory_obj):
    _MemoryLodManager.apply_a3ob_props(memory_obj)

def _ensure_memory_lod_object(context, source_obj, preferred_obj=None):
    return _MemoryLodManager(context, source_obj).ensure_object(preferred_obj=preferred_obj)

def _snap_target_prop_names(side_token: str):
    side = (side_token or "a").lower()
    if side == "v":
        return "paired_object", "paired_memory_object", "Target (V)", "Memory LOD (V)"
    return "source_object", "memory_object", "Target (A)", "Memory LOD (A)"

def _get_snap_target_object(settings, side_token: str, allow_memory_fallback: bool = False):
    target_prop, memory_prop, _target_label, _memory_label = _snap_target_prop_names(side_token)
    obj = getattr(settings, target_prop, None)
    if obj is None and allow_memory_fallback:
        obj = getattr(settings, memory_prop, None)
    return obj

def _set_snap_memory_object(settings, side_token: str, memory_obj):
    _target_prop, memory_prop, _target_label, _memory_label = _snap_target_prop_names(side_token)
    try:
        setattr(settings, memory_prop, memory_obj)
    except Exception:
        pass

def _snap_target_memory_scope_key(context, target_obj):
    if target_obj is None:
        return None

    root_collection = _find_p3d_root_collection_for_object(context, target_obj)
    if root_collection is not None:
        try:
            return ("p3d", root_collection.as_pointer())
        except Exception:
            return ("p3d", root_collection.name)

    for col in getattr(target_obj, "users_collection", []):
        try:
            return ("collection", col.as_pointer())
        except Exception:
            return ("collection", col.name)

    try:
        return ("object", target_obj.as_pointer())
    except Exception:
        return ("object", target_obj.name)

def _ensure_memory_lod_for_snap_target(context, target_obj):
    if target_obj is None or target_obj.type != "MESH" or target_obj.data is None:
        raise RuntimeError("Target Object must be a mesh")

    root_collection = _find_p3d_root_collection_for_object(context, target_obj)
    if root_collection is not None:
        return _MemoryLodManager(context, source_obj=target_obj, parent_collection=root_collection).ensure_object()

    return _MemoryLodManager(context, source_obj=target_obj).ensure_object()

class _MemoryLodManager:
    OBJECT_NAME = "Memory"

    def __init__(self, context, source_obj=None, parent_collection=None):
        self.context = context
        self.source_obj = source_obj
        self.parent_collection = parent_collection

    @staticmethod
    def is_memory_lod_mesh_object(obj) -> bool:
        if obj is None or obj.type != "MESH":
            return False
        if obj.name == _MemoryLodManager.OBJECT_NAME:
            return True
        if not hasattr(obj, "a3ob_properties_object"):
            return False
        try:
            props = obj.a3ob_properties_object
            return str(getattr(props, "lod", "")) == "9"
        except Exception:
            return False

    def pick_existing_object(self):
        if self.parent_collection is not None:
            memory_collection = self.ensure_collection()
            if memory_collection is not None:
                direct = memory_collection.objects.get(self.OBJECT_NAME)
                if direct is not None and direct.type == "MESH":
                    return direct
                for obj in memory_collection.objects:
                    if self.is_memory_lod_mesh_object(obj):
                        return obj
            return None

        if self.source_obj is not None:
            memory_collection = self.ensure_collection()
            if memory_collection is not None:
                direct = memory_collection.objects.get(self.OBJECT_NAME)
                if direct is not None and direct.type == "MESH":
                    return direct
                for obj in memory_collection.objects:
                    if self.is_memory_lod_mesh_object(obj):
                        return obj

            for col in self.source_obj.users_collection:
                obj = col.objects.get(self.OBJECT_NAME)
                if obj is not None and obj.type == "MESH":
                    return obj
            return None

        obj = bpy.data.objects.get(self.OBJECT_NAME)
        if obj is not None and obj.type == "MESH":
            return obj

        for obj in self.context.scene.objects:
            if self.is_memory_lod_mesh_object(obj):
                return obj
        return None

    @staticmethod
    def apply_a3ob_props(memory_obj):
        if not hasattr(memory_obj, "a3ob_properties_object"):
            return
        try:
            props = memory_obj.a3ob_properties_object
            props.lod = "9"
            props.is_a3_lod = True
            _remove_a3ob_named_property(props, "autocenter")
        except Exception:
            pass

    def ensure_collection(self):
        if self.parent_collection is not None:
            return _ensure_named_child_collection(
                self.parent_collection,
                _MEMORY_COLLECTION_NAME,
                _MEMORY_COLLECTION_COLOR,
                aliases=_MEMORY_COLLECTION_ALIASES,
            )
        return _ensure_memory_collection(self.context, self.source_obj)

    def ensure_object(self, preferred_obj=None):
        if preferred_obj is not None and preferred_obj.type == "MESH":
            memory_obj = preferred_obj
        else:
            memory_obj = self.pick_existing_object()

        memory_collection = self.ensure_collection()
        if memory_obj is None:
            memory_mesh = bpy.data.meshes.new(self.OBJECT_NAME)
            memory_obj = bpy.data.objects.new(self.OBJECT_NAME, memory_mesh)
            if memory_collection is not None:
                memory_collection.objects.link(memory_obj)
            else:
                self.context.scene.collection.objects.link(memory_obj)
            if self.source_obj is not None:
                memory_obj.matrix_world = self.source_obj.matrix_world.copy()
        else:
            _move_object_to_collection(memory_obj, memory_collection)

        self.apply_a3ob_props(memory_obj)
        return memory_obj

def _snap_axis_index_or_none(axis_token: str):
    axis = (axis_token or "").strip().upper()
    if axis == "X":
        return 0
    if axis == "Y":
        return 1
    if axis == "Z":
        return 2
    return None

def _snap_pair_axis_order(points, preferred_axis_token: str = None):
    if len(points) != 2:
        return [0, 1, 2]

    delta = points[1] - points[0]
    axes_by_delta = sorted(range(3), key=lambda idx: (-abs(delta[idx]), idx))
    preferred_axis = _snap_axis_index_or_none(preferred_axis_token)
    max_delta = abs(delta[axes_by_delta[0]]) if axes_by_delta else 0.0
    axis_epsilon = max(1e-6, max_delta * 1e-4)
    if preferred_axis is not None and abs(delta[preferred_axis]) > axis_epsilon:
        return [preferred_axis] + [idx for idx in axes_by_delta if idx != preferred_axis]
    return axes_by_delta

def _sort_snap_pair_world_points(context, world_points, preferred_axis_token: str = None):
    points = [p.copy() for p in world_points]
    if len(points) != 2:
        return points

    axis_order = _snap_pair_axis_order(points, preferred_axis_token=preferred_axis_token)
    points.sort(key=lambda point: tuple(point[idx] for idx in axis_order) + (point[0], point[1], point[2]))
    return points

def _create_snap_pair_in_memory(context, memory_obj, world_points, snap_group: str, snap_side: str, replace_existing: bool, axis_token: str = None):
    mesh = memory_obj.data
    to_local = memory_obj.matrix_world.inverted()
    ordered_world_points = _sort_snap_pair_world_points(context, world_points, preferred_axis_token=axis_token)
    local_points = [to_local @ p for p in ordered_world_points]

    base_idx = len(mesh.vertices)
    mesh.vertices.add(2)
    mesh.vertices[base_idx + 0].co = local_points[0]
    mesh.vertices[base_idx + 1].co = local_points[1]
    mesh.update()

    created_names = []
    for i in range(2):
        vg_name = f".sp_{snap_group}_{snap_side}_{i}"
        if replace_existing:
            old = memory_obj.vertex_groups.get(vg_name)
            if old is not None:
                memory_obj.vertex_groups.remove(old)
        vg = memory_obj.vertex_groups.get(vg_name)
        if vg is None:
            vg = memory_obj.vertex_groups.new(name=vg_name)
        vg.add([base_idx + i], 1.0, "REPLACE")
        created_names.append(vg_name)
    return created_names

def _normalize_snap_p3d_name(value: str) -> str:
    return _sanitize_snap_p3d_name_value(value)

def _build_snap_name_base(p3d_name: str, pair_code: str, axis_token: str) -> str:
    axis = (axis_token or "X").strip().lower() or "x"
    return f"{p3d_name}{pair_code}{axis}"

def _build_snap_point_name(p3d_name: str, pair_code: str, axis_token: str, snap_side: str, point_index: int) -> str:
    base = _build_snap_name_base(p3d_name, pair_code, axis_token)
    return f".sp_{base}_{snap_side}_{point_index}"

def _create_named_snap_points_in_memory(memory_obj, world_points, point_names, replace_existing: bool):
    if memory_obj is None or memory_obj.type != "MESH":
        raise RuntimeError("Memory LOD Object must be a mesh")
    if len(world_points) != len(point_names):
        raise RuntimeError("Point and name count mismatch")

    mesh = memory_obj.data
    to_local = memory_obj.matrix_world.inverted()
    local_points = [(to_local @ point.copy()) for point in world_points]

    base_idx = len(mesh.vertices)
    mesh.vertices.add(len(local_points))
    for offset, local_point in enumerate(local_points):
        mesh.vertices[base_idx + offset].co = local_point
    mesh.update()

    created_names = []
    for offset, point_name in enumerate(point_names):
        if replace_existing:
            old = memory_obj.vertex_groups.get(point_name)
            if old is not None:
                memory_obj.vertex_groups.remove(old)

        vg = memory_obj.vertex_groups.get(point_name)
        if vg is None:
            vg = memory_obj.vertex_groups.new(name=point_name)
        vg.add([base_idx + offset], 1.0, "REPLACE")
        created_names.append(point_name)
    return created_names

class _SnapPointNamePattern:
    def __init__(self, p3d_name: str, pair_code: str, axis_token: str):
        self.p3d_name = p3d_name
        self.pair_code = pair_code
        self.axis_token = (axis_token or "X").strip().upper() or "X"

    @classmethod
    def from_settings(cls, settings):
        p3d_name = _normalize_snap_p3d_name(getattr(settings, "snap_p3d_name", "") or getattr(settings, "snap_group", ""))
        if not p3d_name:
            raise RuntimeError("P3D Name is empty")
        if not _SP_P3D_NAME_RE.fullmatch(p3d_name):
            raise RuntimeError("P3D Name must contain only letters and digits")

        pair_code = (getattr(settings, "snap_pair_code", "") or "").strip()
        if not pair_code:
            raise RuntimeError("ID is empty")
        if not _SP_PAIR_CODE_RE.fullmatch(pair_code):
            raise RuntimeError("ID must contain 1-3 letters or digits")
        return cls(p3d_name=p3d_name, pair_code=pair_code, axis_token=getattr(settings, "edge_axis", "X"))

    @classmethod
    def from_preview_settings(cls, settings):
        p3d_name = _normalize_snap_p3d_name(getattr(settings, "snap_p3d_name", "") or getattr(settings, "snap_group", "")) or "SampleName"
        if not _SP_P3D_NAME_RE.fullmatch(p3d_name):
            p3d_name = "SampleName"

        pair_code = (getattr(settings, "snap_pair_code", "") or "").strip() or "01"
        if not _SP_PAIR_CODE_RE.fullmatch(pair_code):
            pair_code = "01"
        return cls(p3d_name=p3d_name, pair_code=pair_code, axis_token=getattr(settings, "edge_axis", "X"))

    @property
    def preview_base(self) -> str:
        return _build_snap_name_base(self.p3d_name, self.pair_code, self.axis_token)

    def build_pair_names(self, snap_side: str):
        return [
            _build_snap_point_name(self.p3d_name, self.pair_code, self.axis_token, snap_side, point_index)
            for point_index in range(2)
        ]

class _SnapPointPairBuilder:
    _SIDE_LABELS = {
        "a": "Target (A)",
        "v": "Target (V)",
    }
    _MEMORY_LABELS = {
        "a": "Memory LOD (A)",
        "v": "Memory LOD (V)",
    }

    def __init__(self, context, settings):
        self.context = context
        self.settings = settings
        self.naming = _SnapPointNamePattern.from_settings(settings)

    def _require_mesh_object(self, obj, label: str):
        if obj is None or obj.type != "MESH" or obj.data is None:
            raise RuntimeError(f"{label} must be a mesh")
        return obj

    def resolve_target_object(self, side_token: str):
        side = (side_token or "a").lower()
        target_obj = _get_snap_target_object(self.settings, side, allow_memory_fallback=True)
        label = self._SIDE_LABELS.get(side, "Target")
        if target_obj is None:
            raise RuntimeError(f"Pick {label} first")
        return self._require_mesh_object(target_obj, label)

    def resolve_memory_object(self, side_token: str):
        side = (side_token or "a").lower()
        target_obj = self.resolve_target_object(side)
        memory_obj = _ensure_memory_lod_for_snap_target(self.context, target_obj)
        memory_label = self._MEMORY_LABELS.get(side, "Memory LOD")
        memory_obj = self._require_mesh_object(memory_obj, memory_label)
        _set_snap_memory_object(self.settings, side, memory_obj)
        return target_obj, memory_obj

    def ensure_object_mode(self):
        if self.context.mode == "OBJECT":
            return
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as e:
            raise RuntimeError(f"Failed to switch to Object Mode: {_fmt_exc(e)}")

    def collect_selected_points(self):
        edit_obj = getattr(self.context, "edit_object", None)
        if edit_obj is None or edit_obj.type != "MESH":
            raise RuntimeError("Select exactly 2 vertices in Edit Mode on any mesh")

        world_points = _collect_snap_pair_selected_world_points(edit_obj)
        if len(world_points) != 2:
            raise RuntimeError("Select exactly 2 vertices in Edit Mode")

        return _sort_snap_pair_world_points(self.context, world_points, preferred_axis_token=self.naming.axis_token)

    def create_dual_model_set(self):
        world_points = self.collect_selected_points()
        target_a, memory_a = self.resolve_memory_object("a")
        target_v, memory_v = self.resolve_memory_object("v")
        if memory_a == memory_v:
            raise RuntimeError("Choose targets from two different model roots")

        self.ensure_object_mode()
        self.settings.snap_p3d_name = self.naming.p3d_name

        created_names = []
        targets = (
            ("a", target_a, memory_a),
            ("v", target_v, memory_v),
        )
        for side_token, _target_obj, memory_obj in targets:
            created_names.extend(
                _create_named_snap_points_in_memory(
                    memory_obj=memory_obj,
                    world_points=world_points,
                    point_names=self.naming.build_pair_names(side_token),
                    replace_existing=self.settings.replace_existing,
                )
            )
        return targets, created_names

def _collect_snap_pair_selected_world_points(source_obj):
    if source_obj is None or source_obj.type != "MESH" or source_obj.mode != "EDIT":
        return []

    bm = bmesh.from_edit_mesh(source_obj.data)
    selected = [source_obj.matrix_world @ vert.co for vert in bm.verts if vert.select]
    if not selected:
        return []
    return _dedupe_world_points(selected)

def _axis_index_from_token(token: str) -> int:
    t = (token or "").upper()
    if t == "X":
        return 0
    if t == "Y":
        return 1
    return 2

def _pick_span_axis_index(edge_axis_idx: int, span_token: str) -> int:
    t = (span_token or "AUTO").upper()
    if t == "AUTO":
        # For walls/segments AUTO uses horizontal perpendicular axis.
        return 1 if edge_axis_idx == 0 else 0
    idx = _axis_index_from_token(t)
    if idx == edge_axis_idx:
        return 2 if edge_axis_idx != 2 else 0
    return idx

def _auto_snap_points_from_model_edge(model_obj, edge_axis_token: str, edge_side_token: str,
                                      span_axis_token: str, edge_tolerance: float):
    if model_obj is None or model_obj.type != "MESH" or model_obj.data is None:
        raise RuntimeError("Model Object must be a mesh")
    if len(model_obj.data.vertices) < 2:
        raise RuntimeError("Model object must have at least 2 vertices")

    edge_axis = _axis_index_from_token(edge_axis_token)
    span_axis = _pick_span_axis_index(edge_axis, span_axis_token)
    verts_local = [v.co.copy() for v in model_obj.data.vertices]

    edge_values = [v[edge_axis] for v in verts_local]
    edge_min = min(edge_values)
    edge_max = max(edge_values)
    edge_range = edge_max - edge_min
    target_edge = edge_min if (edge_side_token or "POS").upper() == "NEG" else edge_max

    tol_abs = max(1e-6, edge_range * max(0.0, edge_tolerance))
    candidates = [v for v in verts_local if abs(v[edge_axis] - target_edge) <= tol_abs]
    if len(candidates) < 2:
        sorted_by_edge = sorted(verts_local, key=lambda v: abs(v[edge_axis] - target_edge))
        candidates = sorted_by_edge[:max(2, len(sorted_by_edge))]

    if len(candidates) < 2:
        raise RuntimeError("Could not detect enough vertices on selected edge")

    v0 = min(candidates, key=lambda v: v[span_axis])
    v1 = max(candidates, key=lambda v: v[span_axis])
    if (v0 - v1).length_squared < 1e-12:
        farthest = None
        best_d2 = -1.0
        for i in range(len(candidates)):
            for j in range(i + 1, len(candidates)):
                d2 = (candidates[i] - candidates[j]).length_squared
                if d2 > best_d2:
                    best_d2 = d2
                    farthest = (candidates[i], candidates[j])
        if farthest is None:
            raise RuntimeError("Failed to determine distinct edge points")
        v0, v1 = farthest

    return [model_obj.matrix_world @ v0, model_obj.matrix_world @ v1]

def _pick_model_mesh_from_objects(objs):
    meshes = [o for o in objs if o is not None and o.type == "MESH" and o.data is not None]
    if not meshes:
        return None

    for o in meshes:
        if (o.name or "").strip().lower() == "resolution 0":
            return o

    non_memory = [o for o in meshes if not _is_memory_lod_mesh_object(o)]
    if non_memory:
        return max(non_memory, key=lambda o: len(o.data.polygons) if o.data else 0)

    return max(meshes, key=lambda o: len(o.data.polygons) if o.data else 0)

def _pick_memory_mesh_from_objects(objs):
    for o in objs:
        if _is_memory_lod_mesh_object(o):
            return o
    return None

def _deselect_all_in_view_layer(context):
    for o in context.view_layer.objects:
        if o.select_get():
            o.select_set(False)

def _cleanup_imported_objects(imported_obj_names, pre_collection_ptrs):
    live = [bpy.data.objects.get(n) for n in imported_obj_names]
    live = [o for o in live if o is not None]
    live.sort(key=_obj_depth, reverse=True)
    for obj in live:
        if bpy.data.objects.get(obj.name) is not None:
            bpy.data.objects.remove(obj, do_unlink=True)

    for col in list(bpy.data.collections):
        if col.as_pointer() in pre_collection_ptrs:
            continue
        if len(col.objects) != 0 or len(col.children) != 0:
            continue
        try:
            bpy.data.collections.remove(col)
        except Exception:
            pass

def _is_p3d_root_collection_name(name: str) -> bool:
    base = _strip_blender_numeric_suffix((name or "").strip())
    return base.lower().endswith(".p3d")

def _iter_p3d_root_collections(scene):
    if scene is None or scene.collection is None:
        return []

    roots = []
    for col in _collect_collections_deep(scene.collection):
        if col is None or col == scene.collection:
            continue
        if _is_p3d_root_collection_name(col.name):
            roots.append(col)
    return roots

class CRAY_OT_EnsureMemoryLOD(Operator):
    bl_idname = "cray.ensure_memory_lod"
    bl_label = "Create/Find Point clouds > Memory"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ss = context.scene.cray_snap_settings
        prepared = []
        prepared_scopes = set()

        for side_token in ("a", "v"):
            target_obj = _get_snap_target_object(ss, side_token, allow_memory_fallback=False)
            if target_obj is None:
                continue

            _target_prop, _memory_prop, target_label, _memory_label = _snap_target_prop_names(side_token)
            if target_obj.type != "MESH" or target_obj.data is None:
                self.report({"ERROR"}, f"{target_label} must be a mesh")
                return {"CANCELLED"}

            scope_key = _snap_target_memory_scope_key(context, target_obj)
            if scope_key in prepared_scopes:
                continue

            memory_obj = _ensure_memory_lod_for_snap_target(context, target_obj)
            _set_snap_memory_object(ss, side_token, memory_obj)
            prepared_scopes.add(scope_key)
            prepared.append(f"{target_obj.name} -> {memory_obj.name}")

        if prepared:
            preview = ", ".join(prepared[:3])
            if len(prepared) > 3:
                preview = f"{preview}, ..."
            self.report({"INFO"}, f"Prepared {len(prepared)} target Memory LODs: {preview}")
            return {"FINISHED"}

        root_collections = _iter_p3d_root_collections(context.scene)
        if not root_collections:
            self.report({"ERROR"}, "No .p3d collections found in the scene")
            return {"CANCELLED"}

        prepared = []
        for root_col in root_collections:
            memory_obj = _MemoryLodManager(context, parent_collection=root_col).ensure_object()
            prepared.append(f"{root_col.name} -> {memory_obj.name}")

        preview = ", ".join(prepared[:3])
        if len(prepared) > 3:
            preview = f"{preview}, ..."
        self.report({"INFO"}, f"Prepared {len(prepared)} Memory LODs: {preview}")
        return {"FINISHED"}

class CRAY_OT_CreateSnapPairFromModelEdge(Operator):
    bl_idname = "cray.create_snap_pair_from_model_edge"
    bl_label = "Create Snap Points"
    bl_description = (
        "Copy 2 selected vertices from the active Edit Mode mesh into Point clouds > Memory of both chosen targets"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ss = context.scene.cray_snap_settings
        try:
            targets, created_names = _SnapPointPairBuilder(context, ss).create_dual_model_set()
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        target_names = ", ".join(
            f"{side.upper()}: {target_obj.name} -> {memory_obj.name}"
            for side, target_obj, memory_obj in targets
        )
        self.report(
            {"INFO"},
            (
                f"Created {len(created_names)} snap points in {target_names}: "
                f"{', '.join(created_names)}"
            ),
        )
        return {"FINISHED"}

class CRAY_OT_SnapBatchProcess(Operator):
    bl_idname = "cray.snap_batch_process"
    bl_label = "Batch Process P3D (Backup + Snap)"
    bl_options = {"REGISTER"}

    filter_glob: StringProperty(default="*.p3d", options={"HIDDEN"})
    directory: StringProperty(subtype="DIR_PATH")
    files: CollectionProperty(type=OperatorFileListElement)

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        ss = context.scene.cray_snap_settings

        if not _has_any_a3ob_io_ops():
            self.report({"ERROR"}, "A3OB import/export operators not found")
            return {"CANCELLED"}

        snap_group = (ss.snap_group or "").strip()
        if not snap_group:
            self.report({"ERROR"}, "Snap Group is empty")
            return {"CANCELLED"}
        if not _SP_GROUP_RE.fullmatch(snap_group):
            self.report({"ERROR"}, "Snap Group must contain only letters, digits and underscores")
            return {"CANCELLED"}

        paths = []
        for item in self.files:
            p = os.path.join(self.directory, item.name)
            paths.append(bpy.path.abspath(p))
        if not paths:
            self.report({"ERROR"}, "No files selected")
            return {"CANCELLED"}

        prev_selected_names = [o.name for o in context.selected_objects]
        prev_active_name = context.view_layer.objects.active.name if context.view_layer.objects.active else None

        ok_count = 0
        fail_count = 0
        backup_count = 0
        exported_count = 0
        failures = []

        for filepath in paths:
            if not os.path.isfile(filepath):
                fail_count += 1
                failures.append((filepath, "file-not-found"))
                continue

            bak_path = filepath + ".bak"
            try:
                if os.path.exists(bak_path) and not ss.batch_overwrite_bak:
                    bak_path = filepath + ".bak.prev"
                shutil.copy2(filepath, bak_path)
                backup_count += 1
            except Exception as e:
                fail_count += 1
                failures.append((filepath, f"backup-failed: {_fmt_exc(e)}"))
                continue

            pre_obj_ptrs = {o.as_pointer() for o in bpy.data.objects}
            pre_col_ptrs = {c.as_pointer() for c in bpy.data.collections}

            with _suppress_a3ob_import_tracking():
                _, used_import, import_err = _call_first_available(
                    _A3OB_IMPORT_CANDIDATES,
                    filepath=filepath,
                    first_lod_only=False,
                    absolute_paths=True,
                    enclose=True,
                    groupby="TYPE",
                    additional_data_allowed=True,
                    additional_data={"PROPS", "SELECTIONS"},
                    validate_meshes=False,
                    proxy_action="SEPARATE",
                    translate_selections=False,
                    cleanup_empty_selections=False,
                    load_textures=False,
                )
            if used_import is None:
                fail_count += 1
                failures.append((filepath, f"import-failed: {_fmt_exc(import_err) if import_err else 'no operator'}"))
                continue

            imported_objs = [o for o in bpy.data.objects if o.as_pointer() not in pre_obj_ptrs]
            imported_names = [o.name for o in imported_objs]
            if not imported_objs:
                fail_count += 1
                failures.append((filepath, "import-produced-no-objects"))
                continue

            model_obj = _pick_model_mesh_from_objects(imported_objs)
            if model_obj is None:
                fail_count += 1
                failures.append((filepath, "no-mesh-model-found"))
                if ss.batch_cleanup_imported:
                    _cleanup_imported_objects(imported_names, pre_col_ptrs)
                continue

            memory_obj = _pick_memory_mesh_from_objects(imported_objs)
            memory_obj = _ensure_memory_lod_object(context, model_obj, preferred_obj=memory_obj)

            try:
                world_points = _auto_snap_points_from_model_edge(
                    model_obj=model_obj,
                    edge_axis_token=ss.edge_axis,
                    edge_side_token=ss.edge_side,
                    span_axis_token=ss.edge_span_axis,
                    edge_tolerance=ss.edge_tolerance,
                )
                _create_snap_pair_in_memory(
                    context=context,
                    memory_obj=memory_obj,
                    world_points=world_points,
                    snap_group=snap_group,
                    snap_side=ss.snap_side,
                    replace_existing=ss.replace_existing,
                    axis_token=ss.edge_axis,
                )
            except Exception as e:
                fail_count += 1
                failures.append((filepath, f"snap-failed: {_fmt_exc(e)}"))
                if ss.batch_cleanup_imported:
                    _cleanup_imported_objects(imported_names, pre_col_ptrs)
                continue

            _deselect_all_in_view_layer(context)
            for name in imported_names:
                live = bpy.data.objects.get(name)
                if live is None:
                    continue
                try:
                    live.hide_set(False)
                except Exception:
                    pass
                try:
                    live.hide_viewport = False
                except Exception:
                    pass
                live.select_set(True)
            if bpy.data.objects.get(model_obj.name) is not None:
                context.view_layer.objects.active = bpy.data.objects.get(model_obj.name)

            _, used_export, export_err = _call_first_available(
                _A3OB_EXPORT_CANDIDATES,
                filepath=filepath,
                use_selection=True,
                visible_only=True,
                relative_paths=True,
                preserve_normals=True,
                validate_meshes=False,
                apply_transforms=True,
                apply_modifiers=True,
                sort_sections=True,
                lod_collisions="SKIP",
                validate_lods=False,
                generate_components=True,
                force_lowercase=True,
            )
            if used_export is None:
                fail_count += 1
                failures.append((filepath, f"export-failed: {_fmt_exc(export_err) if export_err else 'no operator'}"))
            else:
                ok_count += 1
                exported_count += 1

            if ss.batch_cleanup_imported:
                _cleanup_imported_objects(imported_names, pre_col_ptrs)

        _deselect_all_in_view_layer(context)
        for name in prev_selected_names:
            o = bpy.data.objects.get(name)
            if o is not None:
                o.select_set(True)
        if prev_active_name and bpy.data.objects.get(prev_active_name) is not None:
            context.view_layer.objects.active = bpy.data.objects.get(prev_active_name)

        if failures:
            print("=== Batch Snap Process Failures ===")
            for path, reason in failures:
                print(f"{path} :: {reason}")

        msg = f"Batch done: ok {ok_count}/{len(paths)}, exported {exported_count}, backups {backup_count}, failed {fail_count}"
        if fail_count > 0:
            self.report({"WARNING"}, msg + " (see System Console)")
        else:
            self.report({"INFO"}, msg)
        return {"FINISHED"}


# ------------------------------------------------------------------------
#  Collider helper tools for Geometry LOD
# ------------------------------------------------------------------------

def _collider_lod_name(lod_token: str) -> str:
    return _COLLIDER_KNOWN_LOD_NAMES.get(str(lod_token), f"LOD {lod_token}")


def _is_collider_lod_mesh_object(obj, lod_token=None) -> bool:
    if obj is None or obj.type != "MESH":
        return False

    expected = str(lod_token) if lod_token is not None else None
    value = _actual_collider_lod_token_from_object(obj)
    if not value:
        return False

    if expected is None:
        return value in _COLLIDER_KNOWN_LOD_NAMES
    return value == expected


def _object_in_logical_collection(obj, collection_name: str) -> bool:
    if obj is None:
        return False

    wanted_names = _logical_collection_names(collection_name)
    if collection_name == _COLLIDER_COLLECTION_NAME:
        wanted_names.update(_logical_collection_names(_COLLIDER_COLLECTION_ALIASES))
    for col in getattr(obj, "users_collection", []):
        if _logical_collection_name(getattr(col, "name", "")) in wanted_names:
            return True
    return False


def _is_auto_reusable_collider_target(obj, lod_token=None) -> bool:
    if obj is None or obj.type != "MESH":
        return False

    if _is_collider_lod_mesh_object(obj, lod_token=lod_token):
        return True

    if lod_token is None:
        return False

    expected_name = _logical_collection_name(_collider_lod_name(lod_token))
    return (
        _object_in_logical_collection(obj, _COLLIDER_COLLECTION_NAME)
        and _logical_collection_name(getattr(obj, "name", "") or "") == expected_name
    )


def _pick_collider_lod_object(context, source_obj, lod_token):
    expected_name = _collider_lod_name(lod_token)

    parent = _preferred_collider_parent_collection(context, source_obj)
    collider_collection = _find_named_child_collection(
        parent,
        _COLLIDER_COLLECTION_NAME,
        aliases=_COLLIDER_COLLECTION_ALIASES,
    )
    if collider_collection is None:
        return None

    direct = collider_collection.objects.get(expected_name)
    if _is_auto_reusable_collider_target(direct, lod_token=lod_token):
        return direct

    for obj in collider_collection.objects:
        if _is_auto_reusable_collider_target(obj, lod_token=lod_token):
            return obj

    return None


def _find_parent_collection(root_collection, target_collection):
    if root_collection is None or target_collection is None:
        return None

    for child in root_collection.children:
        if child == target_collection:
            return root_collection
        found = _find_parent_collection(child, target_collection)
        if found is not None:
            return found
    return None


def _logical_collection_name(name: str) -> str:
    return re.sub(r"\.\d{3}$", "", (name or "").strip().lower())


def _logical_collection_names(*names) -> set:
    result = set()
    for name in names:
        if not name:
            continue
        if isinstance(name, (tuple, list, set)):
            result.update(_logical_collection_names(*name))
            continue
        result.add(_logical_collection_name(name))
    return result


def _preferred_collider_parent_collection(context, source_obj):
    source_col = None
    if source_obj is not None and source_obj.users_collection:
        source_col = source_obj.users_collection[0]
    if source_col is None:
        return context.scene.collection

    parent = _find_parent_collection(context.scene.collection, source_col)
    if parent is None:
        return source_col

    logical_group_names = {
        "visuals",
        "shadows",
        "geometry",
        "geometries",
        "point clouds",
        "misc",
    }
    if _logical_collection_name(source_col.name) in logical_group_names:
        return parent
    return source_col


def _ensure_collider_collection(context, source_obj):
    parent = _preferred_collider_parent_collection(context, source_obj)
    if parent is None:
        parent = context.scene.collection

    return _ensure_named_child_collection(
        parent,
        _COLLIDER_COLLECTION_NAME,
        _COLLIDER_COLLECTION_COLOR,
        aliases=_COLLIDER_COLLECTION_ALIASES,
    )


def _ensure_named_child_collection(parent_collection, collection_name, color_tag=None, aliases=()):
    if parent_collection is None:
        return None

    target = _find_named_child_collection(parent_collection, collection_name, aliases=aliases)
    if target is None:
        target = bpy.data.collections.new(collection_name)
        parent_collection.children.link(target)
    elif _logical_collection_name(target.name) != _logical_collection_name(collection_name):
        try:
            target.name = collection_name
        except Exception:
            pass

    if color_tag:
        try:
            target.color_tag = color_tag
        except Exception:
            pass

    return target


def _find_named_child_collection(parent_collection, collection_name, aliases=()):
    if parent_collection is None:
        return None

    target = parent_collection.children.get(collection_name)
    logical_names = _logical_collection_names(collection_name, aliases)
    if target is None:
        for child in parent_collection.children:
            if _logical_collection_name(child.name) in logical_names:
                target = child
                break
    return target


def _ensure_memory_collection(context, source_obj):
    parent = _preferred_collider_parent_collection(context, source_obj)
    if parent is None:
        parent = context.scene.collection
    return _ensure_named_child_collection(
        parent,
        _MEMORY_COLLECTION_NAME,
        _MEMORY_COLLECTION_COLOR,
        aliases=_MEMORY_COLLECTION_ALIASES,
    )


def _ensure_misc_collection(context, source_obj):
    parent = _preferred_collider_parent_collection(context, source_obj)
    if parent is None:
        parent = context.scene.collection
    return _ensure_named_child_collection(parent, _MISC_COLLECTION_NAME, _MISC_COLLECTION_COLOR)


def _pick_named_lod_object(context, source_obj, lod_token, object_name):
    if source_obj is not None:
        for col in source_obj.users_collection:
            obj = col.objects.get(object_name)
            if obj is not None and obj.type == "MESH":
                return obj

    obj = bpy.data.objects.get(object_name)
    if obj is not None and obj.type == "MESH":
        return obj

    for obj in context.scene.objects:
        if _is_collider_lod_mesh_object(obj, lod_token=lod_token):
            return obj

    return None


def _remove_a3ob_named_property(props, name: str):
    items = getattr(props, "properties", None)
    if items is None:
        return

    remove_indices = []
    for idx, item in enumerate(items):
        if (getattr(item, "name", "") or "").strip().lower() == name.lower():
            remove_indices.append(idx)

    for idx in reversed(remove_indices):
        try:
            items.remove(idx)
        except Exception:
            pass


def _set_collider_lod_a3ob_props(target_obj, lod_token):
    if not hasattr(target_obj, "a3ob_properties_object"):
        return

    try:
        props = target_obj.a3ob_properties_object
        props.lod = str(lod_token)
        props.resolution = 1
        props.resolution_float = 1.0
        props.is_a3_lod = True
        _remove_a3ob_named_property(props, "autocenter")
        lod_name = props.get_name() if hasattr(props, "get_name") else _collider_lod_name(lod_token)
        target_obj.name = lod_name
        if target_obj.data is not None:
            target_obj.data.name = lod_name
    except Exception:
        pass


def _collider_target_validation_error(target_obj, lod_token, source_obj=None, allow_same_source=False):
    if target_obj is None:
        return None
    if target_obj.type != "MESH":
        return "Target LOD Object must be a mesh"
    if source_obj is not None and target_obj == source_obj and not allow_same_source:
        if not _is_collider_lod_mesh_object(target_obj, lod_token=lod_token):
            return "Target LOD Object must be separate from the Source Object"
    if not hasattr(target_obj, "a3ob_properties_object"):
        return None

    try:
        props = target_obj.a3ob_properties_object
        if not bool(getattr(props, "is_a3_lod", False)):
            return None
        current_lod = str(getattr(props, "lod", ""))
    except Exception:
        return None

    if current_lod and current_lod != str(lod_token):
        return (
            f"Target LOD Object '{target_obj.name}' is already "
            f"A3OB LOD '{_collider_lod_name(current_lod)}'"
        )
    return None


def _tag_redraw_all_areas(context):
    screen = getattr(getattr(context, "window", None), "screen", None) or getattr(context, "screen", None)
    if screen is None:
        return

    for area in getattr(screen, "areas", []):
        try:
            for region in area.regions:
                region.tag_redraw()
        except Exception:
            pass
        try:
            area.tag_redraw()
        except Exception:
            pass


def _set_collider_settings_object(context, attr_name, obj):
    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    if cs is None or not hasattr(cs, attr_name):
        return

    current = getattr(cs, attr_name, None)
    try:
        if current == obj:
            setattr(cs, attr_name, None)
        setattr(cs, attr_name, obj)
    except Exception:
        pass

    try:
        context.view_layer.update()
    except Exception:
        pass
    _tag_redraw_all_areas(context)


def _sync_material_selection(context, material_attr: str, items_fn, none_value: str, preferred_name=""):
    global _COLLIDER_MATERIAL_SELECTION_SYNCING

    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    if cs is None:
        return

    items = items_fn(None, context)
    valid_values = [
        item[0]
        for item in items
        if item and item[0] not in {none_value, _MATERIAL_ADD_NEW}
    ]
    current = (getattr(cs, material_attr, "") or "").strip()
    preferred_name = (preferred_name or "").strip()

    if preferred_name and preferred_name in valid_values:
        chosen = preferred_name
    elif current and current in valid_values:
        chosen = current
    elif valid_values:
        chosen = valid_values[0]
    else:
        chosen = none_value

    _COLLIDER_MATERIAL_SELECTION_SYNCING = True
    try:
        try:
            setattr(cs, material_attr, chosen)
        except Exception:
            pass
    finally:
        _COLLIDER_MATERIAL_SELECTION_SYNCING = False

    _tag_redraw_all_areas(context)


def _sync_roadway_material_selection(context, preferred_name=""):
    _sync_material_selection(
        context,
        "roadway_material",
        get_roadway_material_enum_items,
        _ROADWAY_MATERIAL_NONE,
        preferred_name,
    )


def _sync_fire_geometry_material_selection(context, preferred_name=""):
    _sync_material_selection(
        context,
        "fire_geometry_material",
        get_fire_geometry_material_enum_items,
        _FIRE_GEOMETRY_MATERIAL_NONE,
        preferred_name,
    )


def _get_selected_material_from_object(obj, selected_name: str, *, create_name: str = ""):
    if obj is None or obj.type != "MESH":
        return None

    selected_name = (selected_name or "").strip()
    fallback_mat = None

    for slot in obj.material_slots:
        mat = slot.material
        if mat is None:
            continue
        if fallback_mat is None:
            fallback_mat = mat
        if selected_name and mat.name == selected_name:
            return mat

    if fallback_mat is not None or not create_name:
        return fallback_mat

    mat = bpy.data.materials.new(create_name)
    obj.data.materials.append(mat)
    return mat


def _get_selected_roadway_material(context):
    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    if cs is None:
        return None

    roadway_obj = getattr(cs, "roadway_object", None)
    selected_name = getattr(cs, "roadway_material", "") or ""
    return _get_selected_material_from_object(roadway_obj, selected_name)


def _get_selected_fire_geometry_material(context, *, create_name: str = ""):
    cs = getattr(getattr(context, "scene", None), "cray_collider_settings", None)
    if cs is None:
        return None

    fire_obj = _resolve_fire_geometry_object_for_material(context)
    selected_name = getattr(cs, "fire_geometry_material", "") or ""
    return _get_selected_material_from_object(fire_obj, selected_name, create_name=create_name)


def _apply_collider_visual_style(target_obj):
    _apply_object_visual_style(target_obj, _COLLIDER_OBJECT_COLOR)


def _apply_object_visual_style(target_obj, color):
    if target_obj is None:
        return

    try:
        target_obj.color = color
    except Exception:
        pass
    try:
        target_obj.show_wire = True
    except Exception:
        pass


def _is_existing_roadway_target(obj) -> bool:
    if obj is None or getattr(obj, "type", None) != "MESH":
        return False
    if _is_collider_lod_mesh_object(obj, lod_token=_ROADWAY_LOD_TOKEN):
        return True
    return _logical_collection_name(getattr(obj, "name", "") or "") == _logical_collection_name(_collider_lod_name(_ROADWAY_LOD_TOKEN))


def _pick_roadway_lod_object(context, source_obj):
    parent = _preferred_collider_parent_collection(context, source_obj)
    misc_collection = _find_named_child_collection(parent, _MISC_COLLECTION_NAME)
    if misc_collection is None:
        return None

    expected_name = _collider_lod_name(_ROADWAY_LOD_TOKEN)
    direct = misc_collection.objects.get(expected_name)
    if _is_existing_roadway_target(direct):
        return direct

    for obj in misc_collection.objects:
        if _is_existing_roadway_target(obj):
            return obj

    return None


def _ensure_roadway_lod_object(context, source_obj, preferred_obj=None):
    misc_collection = _ensure_misc_collection(context, source_obj)
    if misc_collection is None:
        misc_collection = context.scene.collection

    if (
        _is_existing_roadway_target(preferred_obj)
        and _collection_directly_contains_object(misc_collection, preferred_obj)
    ):
        target_obj = preferred_obj
    else:
        target_obj = _pick_roadway_lod_object(context, source_obj)

    if target_obj is None:
        obj_name = _collider_lod_name(_ROADWAY_LOD_TOKEN)
        mesh = bpy.data.meshes.new(obj_name)
        target_obj = bpy.data.objects.new(obj_name, mesh)
        misc_collection.objects.link(target_obj)
        if source_obj is not None:
            target_obj.matrix_world = source_obj.matrix_world.copy()

    _set_collider_lod_a3ob_props(target_obj, _ROADWAY_LOD_TOKEN)
    _apply_object_visual_style(target_obj, _ROADWAY_OBJECT_COLOR)
    _enable_collider_object_color_preview(context)
    try:
        target_obj.show_all_edges = True
    except Exception:
        pass
    try:
        target_obj.show_name = True
    except Exception:
        pass
    return target_obj


def _enable_collider_object_color_preview(context):
    area = getattr(context, "area", None)
    space = getattr(context, "space_data", None)
    if area is None or area.type != "VIEW_3D" or space is None:
        return

    shading = getattr(space, "shading", None)
    if shading is None:
        return

    try:
        shading.color_type = "OBJECT"
    except Exception:
        pass


def _is_existing_collider_target_for_lod(obj, lod_token) -> bool:
    if obj is None or getattr(obj, "type", None) != "MESH":
        return False
    if _is_collider_lod_mesh_object(obj, lod_token=lod_token):
        return True
    expected_name = _logical_collection_name(_collider_lod_name(lod_token))
    return _logical_collection_name(getattr(obj, "name", "") or "") == expected_name

def _ensure_collider_lod_object(context, source_obj, lod_token, preferred_obj=None):
    collider_collection = _ensure_collider_collection(context, source_obj)
    if collider_collection is None:
        collider_collection = context.scene.collection

    if (
        _is_existing_collider_target_for_lod(preferred_obj, lod_token)
        and _collection_directly_contains_object(collider_collection, preferred_obj)
    ):
        target_obj = preferred_obj
    else:
        target_obj = _pick_collider_lod_object(context, source_obj, lod_token)

    if target_obj is None:
        obj_name = _collider_lod_name(lod_token)
        mesh = bpy.data.meshes.new(obj_name)
        target_obj = bpy.data.objects.new(obj_name, mesh)
        collider_collection.objects.link(target_obj)
        if source_obj is not None:
            target_obj.matrix_world = source_obj.matrix_world.copy()

    _set_collider_lod_a3ob_props(target_obj, lod_token)
    _apply_collider_visual_style(target_obj)
    _enable_collider_object_color_preview(context)
    return target_obj


def _resolve_collider_source_object(context, preferred_obj=None):
    active = context.view_layer.objects.active
    if active is not None and active.type == "MESH":
        return active
    if preferred_obj is not None and preferred_obj.type == "MESH":
        return preferred_obj
    return None


def _resolve_collider_selection_source_object(context, preferred_obj=None):
    active = context.view_layer.objects.active
    if active is not None and active.type == "MESH" and active.mode == "EDIT":
        return active
    if preferred_obj is not None and preferred_obj.type == "MESH" and preferred_obj.mode == "EDIT":
        return preferred_obj
    return _resolve_collider_source_object(context, preferred_obj)


def _collect_selected_vertex_world_points(source_obj):
    if source_obj is None or source_obj.type != "MESH" or source_obj.mode != "EDIT":
        raise RuntimeError("Source object must be the active mesh in Edit Mode")

    bm = bmesh.from_edit_mesh(source_obj.data)
    selected = [source_obj.matrix_world @ vert.co for vert in bm.verts if vert.select]
    if not selected:
        raise RuntimeError("Select at least one vertex on the source mesh")
    return _dedupe_world_points(selected)


def _world_normal_from_selected_faces(source_obj, selected_faces):
    normal = Vector((0.0, 0.0, 0.0))
    for face in selected_faces:
        if len(face.verts) < 3:
            continue
        p0 = source_obj.matrix_world @ face.verts[0].co
        p1 = source_obj.matrix_world @ face.verts[1].co
        p2 = source_obj.matrix_world @ face.verts[2].co
        cross = (p1 - p0).cross(p2 - p0)
        if cross.length_squared > 1e-12:
            normal += cross

    if normal.length_squared <= 1e-12:
        return None

    normal.normalize()
    return normal


def _estimate_world_points_normal(points):
    if len(points) < 3:
        return None

    origin = points[0]
    farthest = None
    farthest_d2 = 0.0
    for point in points[1:]:
        d2 = (point - origin).length_squared
        if d2 > farthest_d2:
            farthest_d2 = d2
            farthest = point

    if farthest is None or farthest_d2 <= 1e-12:
        return None

    axis = farthest - origin
    best_normal = None
    best_d2 = 0.0
    for point in points[1:]:
        cross = axis.cross(point - origin)
        d2 = cross.length_squared
        if d2 > best_d2:
            best_d2 = d2
            best_normal = cross

    if best_normal is None or best_d2 <= 1e-12:
        return None

    best_normal.normalize()
    return best_normal


def _dedupe_world_points(points, tolerance=1e-6):
    if tolerance <= 0.0:
        return [p.copy() for p in points]

    scale = 1.0 / tolerance
    unique = []
    seen = set()
    for point in points:
        key = (
            round(point.x * scale),
            round(point.y * scale),
            round(point.z * scale),
        )
        if key in seen:
            continue
        seen.add(key)
        unique.append(point.copy())
    return unique


def _vector_quantized_key(vec, tolerance=1e-6):
    tol = max(float(tolerance), 1e-12)
    scale = 1.0 / tol
    return (
        round(vec.x * scale),
        round(vec.y * scale),
        round(vec.z * scale),
    )


def _collect_selected_collider_input(source_obj, loose_only=False):
    if source_obj is None or source_obj.type != "MESH" or source_obj.mode != "EDIT":
        raise RuntimeError("Source object must be the active mesh in Edit Mode")

    bm = bmesh.from_edit_mesh(source_obj.data)
    selected_faces = [face for face in bm.faces if face.select]
    selected_edges = [edge for edge in bm.edges if edge.select]

    selected_verts = {vert for vert in bm.verts if vert.select}
    for edge in selected_edges:
        selected_verts.update(edge.verts)
    for face in selected_faces:
        selected_verts.update(face.verts)

    selected_verts = list(selected_verts)
    if loose_only:
        selected_verts = [
            vert for vert in selected_verts
            if len(vert.link_edges) == 0 and len(vert.link_faces) == 0
        ]

    if not selected_verts:
        if loose_only:
            raise RuntimeError("No isolated selected vertices found")
        raise RuntimeError("Select vertices, edges or faces on the source mesh")

    world_points = _dedupe_world_points([source_obj.matrix_world @ vert.co for vert in selected_verts])
    local_points = [vert.co.copy() for vert in selected_verts]

    normal = _world_normal_from_selected_faces(source_obj, selected_faces)
    if normal is None:
        normal = _estimate_world_points_normal(world_points)

    return {
        "world_points": world_points,
        "local_points": local_points,
        "normal": normal,
        "face_count": len(selected_faces),
        "vert_count": len(selected_verts),
    }


def _points_are_flat(points, normal, epsilon=1e-5):
    if len(points) < 4 or normal is None or normal.length_squared <= 1e-12:
        return False

    origin = points[0]
    max_dist = 0.0
    for point in points[1:]:
        max_dist = max(max_dist, abs((point - origin).dot(normal)))
    return max_dist <= epsilon


def _extrude_points_along_normal(points, normal, thickness):
    if thickness <= 0.0:
        raise RuntimeError("Thickness must be greater than zero")
    if normal is None or normal.length_squared <= 1e-12:
        raise RuntimeError("Could not determine a stable normal for the current selection")

    n = normal.normalized()
    half = thickness * 0.5
    out = []
    for point in points:
        out.append(point + n * half)
        out.append(point - n * half)
    return _dedupe_world_points(out)


def _world_corners_from_local_bounds(source_obj, local_points, padding=0.0, min_axis_size=0.0):
    if not local_points:
        raise RuntimeError("No points available to build bounds")

    min_v = Vector((
        min(point.x for point in local_points),
        min(point.y for point in local_points),
        min(point.z for point in local_points),
    ))
    max_v = Vector((
        max(point.x for point in local_points),
        max(point.y for point in local_points),
        max(point.z for point in local_points),
    ))

    if padding > 0.0:
        pad = Vector((padding, padding, padding))
        min_v -= pad
        max_v += pad

    if min_axis_size > 0.0:
        for axis in range(3):
            if abs(max_v[axis] - min_v[axis]) >= 1e-6:
                continue
            expand = min_axis_size * 0.5
            min_v[axis] -= expand
            max_v[axis] += expand

    corners = []
    for x in (min_v.x, max_v.x):
        for y in (min_v.y, max_v.y):
            for z in (min_v.z, max_v.z):
                corners.append(source_obj.matrix_world @ Vector((x, y, z)))
    return corners


def _delete_bmesh_geom(bm, geom_items):
    unique_items = []
    seen = set()
    for item in geom_items:
        key = id(item)
        if key in seen:
            continue
        seen.add(key)
        unique_items.append(item)

    verts = [item for item in unique_items if isinstance(item, bmesh.types.BMVert) and item.is_valid]
    edges = [item for item in unique_items if isinstance(item, bmesh.types.BMEdge) and item.is_valid]
    faces = [item for item in unique_items if isinstance(item, bmesh.types.BMFace) and item.is_valid]

    if faces:
        bmesh.ops.delete(bm, geom=faces, context="FACES")
    if edges:
        bmesh.ops.delete(bm, geom=edges, context="EDGES")
    if verts:
        bmesh.ops.delete(bm, geom=verts, context="VERTS")


def _finalize_convex_hull_geometry(bm, hull_result, seed_verts, recalc_normals=True):
    created_faces = [
        item for item in hull_result.get("geom", [])
        if isinstance(item, bmesh.types.BMFace) and item.is_valid
    ]

    cleanup = []
    cleanup.extend(hull_result.get("geom_unused", []))
    cleanup.extend(hull_result.get("geom_interior", []))
    if cleanup:
        _delete_bmesh_geom(bm, cleanup)

    affected_verts = {vert for vert in seed_verts if vert.is_valid}
    for face in created_faces:
        if not face.is_valid:
            continue
        for vert in face.verts:
            if vert.is_valid:
                affected_verts.add(vert)

    created_face_set = {face for face in created_faces if face.is_valid}
    affected_edges = {
        edge
        for face in created_face_set
        for edge in face.edges
        if edge.is_valid
        and all(link_face in created_face_set for link_face in edge.link_faces if link_face.is_valid)
    }

    if affected_edges:
        bmesh.ops.dissolve_limit(
            bm,
            angle_limit=1e-5,
            use_dissolve_boundaries=True,
            verts=[vert for vert in affected_verts if vert.is_valid],
            edges=[edge for edge in affected_edges if edge.is_valid],
            delimit=set(),
        )

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    loose_edges = [edge for edge in affected_edges if edge.is_valid and len(edge.link_faces) == 0]
    if loose_edges:
        bmesh.ops.delete(bm, geom=loose_edges, context="EDGES")

    loose_verts = [
        vert for vert in affected_verts
        if vert.is_valid and len(vert.link_edges) == 0 and len(vert.link_faces) == 0
    ]
    if loose_verts:
        bmesh.ops.delete(bm, geom=loose_verts, context="VERTS")

    final_faces = {
        face
        for vert in affected_verts
        if vert.is_valid
        for face in vert.link_faces
        if face.is_valid
    }
    if not final_faces:
        raise RuntimeError("Convex hull did not create faces (selection may be too flat or degenerate)")

    final_faces = list(final_faces)
    if recalc_normals:
        bmesh.ops.recalc_face_normals(bm, faces=final_faces)

    return final_faces


def _select_only_faces_in_bmesh(bm, faces):
    face_set = {face for face in faces if face is not None and face.is_valid}
    for face in bm.faces:
        face.select = False
    for edge in bm.edges:
        edge.select = False
    for vert in bm.verts:
        vert.select = False
    for face in face_set:
        face.select = True
    bm.select_flush_mode()


def _build_clean_hull_data_from_local_points(local_points, merge_distance=0.0, recalc_normals=True):
    unique_points = []
    seen = set()
    for point in local_points:
        key = _vector_quantized_key(point)
        if key in seen:
            continue
        seen.add(key)
        unique_points.append(point.copy())

    if len(unique_points) < 4:
        raise RuntimeError("Selected vertices collapse below 4 unique points")

    bm = bmesh.new()
    try:
        seed_verts = [bm.verts.new(point) for point in unique_points]
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        if merge_distance > 0.0 and seed_verts:
            bmesh.ops.remove_doubles(bm, verts=seed_verts, dist=merge_distance)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            seed_verts = [vert for vert in seed_verts if vert.is_valid]

        unique_point_keys = {_vector_quantized_key(vert.co) for vert in seed_verts if vert.is_valid}
        if len(unique_point_keys) < 4:
            raise RuntimeError("Selected vertices collapse below 4 unique points")

        hull = bmesh.ops.convex_hull(bm, input=seed_verts, use_existing_faces=False)
        final_faces = _finalize_convex_hull_geometry(
            bm,
            hull,
            seed_verts,
            recalc_normals=recalc_normals,
        )

        used_verts = []
        used_vert_ids = set()
        for face in final_faces:
            if face is None or not face.is_valid:
                continue
            for vert in face.verts:
                if vert is None or not vert.is_valid:
                    continue
                key = id(vert)
                if key in used_vert_ids:
                    continue
                used_vert_ids.add(key)
                used_verts.append(vert)

        if len(used_verts) < 4:
            raise RuntimeError("Convex hull did not keep enough vertices to build a clean result")

        vert_index_by_id = {id(vert): idx for idx, vert in enumerate(used_verts)}
        face_indices = []
        for face in final_faces:
            if face is None or not face.is_valid or len(face.verts) < 3:
                continue
            indices = [vert_index_by_id[id(vert)] for vert in face.verts if vert is not None and vert.is_valid]
            if len(indices) >= 3:
                face_indices.append(indices)

        if not face_indices:
            raise RuntimeError("Convex hull did not create faces (selection may be too flat or degenerate)")

        return {
            "verts": [vert.co.copy() for vert in used_verts],
            "faces": face_indices,
            "used_verts": len(unique_point_keys),
        }
    finally:
        bm.free()


def _replace_selection_with_clean_hull_in_edit_object(
    context,
    target_obj,
    hull_data,
    selected_geom,
    recalc_normals=True,
):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target object must be a mesh")
    if target_obj.mode != "EDIT":
        raise RuntimeError("Target object must be in Edit Mode")

    mesh = target_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    geom_to_delete = []
    geom_to_delete.extend(selected_geom.get("faces", []))
    geom_to_delete.extend(selected_geom.get("edges", []))
    geom_to_delete.extend(selected_geom.get("verts", []))
    if geom_to_delete:
        _delete_bmesh_geom(bm, geom_to_delete)

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    new_verts = [bm.verts.new(point) for point in hull_data["verts"]]
    bm.verts.ensure_lookup_table()

    new_faces = []
    for face_indices in hull_data["faces"]:
        face_verts = [new_verts[idx] for idx in face_indices if 0 <= idx < len(new_verts)]
        if len(face_verts) < 3 or len(set(face_verts)) < 3:
            continue
        try:
            face = bm.faces.new(face_verts)
        except ValueError:
            continue
        new_faces.append(face)

    if not new_faces:
        raise RuntimeError("Could not write clean convex hull back to the mesh")

    if recalc_normals:
        bmesh.ops.recalc_face_normals(bm, faces=new_faces)

    _select_only_faces_in_bmesh(bm, new_faces)
    bm.normal_update()
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=True)
    if context.mode == "EDIT_MESH":
        try:
            bpy.ops.mesh.select_mode(type="FACE")
        except Exception:
            pass

    return {
        "verts_added": len(new_verts),
        "faces_added": len(new_faces),
    }


def _append_collider_hull_to_object(target_obj, world_points, merge_distance=0.0, recalc_normals=True):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target Geometry LOD object must be a mesh")
    if target_obj.mode == "EDIT":
        raise RuntimeError("Target Geometry LOD must not be in Edit Mode")

    unique_points = _dedupe_world_points(world_points)
    if len(unique_points) < 4:
        raise RuntimeError("Need at least 4 unique points to build a collider")

    mesh = target_obj.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        before_vert_count = len(bm.verts)
        before_face_count = len(bm.faces)

        to_local = target_obj.matrix_world.inverted_safe()
        local_points = [to_local @ point for point in unique_points]
        hull_data = _build_clean_hull_data_from_local_points(
            local_points,
            merge_distance=merge_distance,
            recalc_normals=recalc_normals,
        )

        new_verts = [bm.verts.new(point) for point in hull_data["verts"]]
        bm.verts.ensure_lookup_table()

        new_faces = []
        for face_indices in hull_data["faces"]:
            face_verts = [new_verts[idx] for idx in face_indices if 0 <= idx < len(new_verts)]
            if len(face_verts) < 3 or len(set(face_verts)) < 3:
                continue
            try:
                face = bm.faces.new(face_verts)
            except ValueError:
                continue
            new_faces.append(face)

        if not new_faces:
            raise RuntimeError("Could not append clean convex hull to the target mesh")

        if recalc_normals:
            bmesh.ops.recalc_face_normals(bm, faces=new_faces)

        bm.normal_update()
        bm.to_mesh(mesh)
        mesh.update(calc_edges=True)

        return {
            "verts_added": len(mesh.vertices) - before_vert_count,
            "faces_added": len(mesh.polygons) - before_face_count,
            "used_verts": hull_data["used_verts"],
        }
    finally:
        bm.free()


def _append_world_vertices_to_object(target_obj, world_points):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target Geometry LOD object must be a mesh")
    if target_obj.mode == "EDIT":
        raise RuntimeError("Target Geometry LOD must not be in Edit Mode while copying vertices")

    unique_points = _dedupe_world_points(world_points)
    if not unique_points:
        raise RuntimeError("No vertices to append")

    mesh = target_obj.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        to_local = target_obj.matrix_world.inverted_safe()
        new_verts = []
        for point in unique_points:
            try:
                vert = bm.verts.new(to_local @ point)
                new_verts.append(vert)
            except ValueError:
                continue

        bm.verts.ensure_lookup_table()
        new_indices = [vert.index for vert in new_verts if vert.is_valid]
        if not new_indices:
            raise RuntimeError("Selected vertices already exist in Geometry")

        bm.to_mesh(mesh)
        mesh.update(calc_edges=True)
        return new_indices
    finally:
        bm.free()


def _duplicate_selected_verts_as_loose_points_in_edit_object(target_obj):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target Geometry LOD object must be a mesh")
    if target_obj.mode != "EDIT":
        raise RuntimeError("Target Geometry LOD must be active in Edit Mode")

    mesh = target_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()

    selected_verts = [vert for vert in bm.verts if vert.is_valid and vert.select]
    if not selected_verts:
        raise RuntimeError("Select at least one vertex on the source mesh")

    dup = bmesh.ops.duplicate(bm, geom=selected_verts)
    new_verts = [
        item for item in dup.get("geom", [])
        if isinstance(item, bmesh.types.BMVert) and item.is_valid
    ]
    if not new_verts:
        raise RuntimeError("Could not duplicate selected vertices")

    for vert in bm.verts:
        vert.select = False
    for edge in bm.edges:
        edge.select = False
    for face in bm.faces:
        face.select = False
    for vert in new_verts:
        vert.select = True

    bm.select_flush_mode()
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=True)
    return [vert.index for vert in new_verts if vert.is_valid]


def _append_selected_faces_to_object(target_obj, source_obj, recalc_normals=True, weld_distance=0.0):
    if source_obj is None or source_obj.type != "MESH" or source_obj.mode != "EDIT":
        raise RuntimeError("Source object must be the active mesh in Edit Mode")
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target Roadway object must be a mesh")
    if target_obj.mode == "EDIT":
        raise RuntimeError("Target Roadway object must not be in Edit Mode while copying polygons")
    if target_obj == source_obj:
        raise RuntimeError("Target Roadway object must be separate from the edited source mesh")

    bm_src = bmesh.from_edit_mesh(source_obj.data)
    selected_faces = [face for face in bm_src.faces if face.select]
    if not selected_faces:
        raise RuntimeError("Select at least one polygon on the source mesh")

    material_slot_map = {}
    preferred_material_name = ""
    source_slots = list(getattr(source_obj, "material_slots", []))
    target_materials = target_obj.data.materials

    for src_material_index in sorted({face.material_index for face in selected_faces}):
        src_mat = source_slots[src_material_index].material if src_material_index < len(source_slots) else None

        if src_mat is not None:
            target_material_index, roadway_material_name = _ensure_roadway_material(target_materials, src_mat)
            if not preferred_material_name:
                preferred_material_name = roadway_material_name
        elif len(target_materials) > 0:
            target_material_index = 0
        else:
            target_material_index, roadway_material_name = _ensure_roadway_material(target_materials, None)
            if not preferred_material_name:
                preferred_material_name = roadway_material_name

        material_slot_map[src_material_index] = target_material_index

    mesh = target_obj.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        before_vert_count = len(bm.verts)
        before_face_count = len(bm.faces)

        to_target_local = target_obj.matrix_world.inverted_safe()
        source_to_world = source_obj.matrix_world
        vert_map = {}
        created_faces = []

        for src_face in selected_faces:
            face_verts = []
            for src_vert in src_face.verts:
                key = src_vert.index
                new_vert = vert_map.get(key)
                if new_vert is None or not new_vert.is_valid:
                    new_vert = bm.verts.new(to_target_local @ (source_to_world @ src_vert.co))
                    vert_map[key] = new_vert
                face_verts.append(new_vert)

            if len(face_verts) < 3 or len(set(face_verts)) < 3:
                continue

            try:
                new_face = bm.faces.new(face_verts)
            except ValueError:
                continue
            new_face.material_index = material_slot_map.get(src_face.material_index, 0)
            created_faces.append(new_face)

        if not created_faces:
            raise RuntimeError("Could not copy selected polygons to Roadway")

        if weld_distance > 0.0 and bm.verts:
            bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=weld_distance)
            bm.verts.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            created_faces = [face for face in created_faces if face.is_valid]

        if recalc_normals:
            bmesh.ops.recalc_face_normals(bm, faces=created_faces)

        for vert in bm.verts:
            vert.select = False
        for edge in bm.edges:
            edge.select = False
        for face in bm.faces:
            face.select = False
        for face in created_faces:
            if face.is_valid:
                face.select = True

        bm.normal_update()
        bm.to_mesh(mesh)
        mesh.update(calc_edges=True)
        return {
            "verts_added": len(mesh.vertices) - before_vert_count,
            "faces_added": len(mesh.polygons) - before_face_count,
            "preferred_material_name": preferred_material_name,
        }
    finally:
        bm.free()


def _weld_mesh_vertices(target_obj, merge_distance):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Roadway Object must be a mesh")
    if merge_distance <= 0.0:
        return {"removed_verts": 0}
    if target_obj.mode != "EDIT":
        raise RuntimeError("Roadway Object must be active in Edit Mode")

    mesh = target_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    before_vert_count = len(bm.verts)
    if before_vert_count == 0:
        return {"removed_verts": 0, "selected_verts": 0}

    selected_verts = []
    seen_indices = set()

    def _add_vert(vert):
        if vert is None or not vert.is_valid:
            return
        key = vert.index
        if key in seen_indices:
            return
        seen_indices.add(key)
        selected_verts.append(vert)

    for vert in bm.verts:
        if vert.select:
            _add_vert(vert)
    for edge in bm.edges:
        if edge.select:
            for vert in edge.verts:
                _add_vert(vert)
    for face in bm.faces:
        if face.select:
            for vert in face.verts:
                _add_vert(vert)

    if not selected_verts:
        raise RuntimeError("Select Roadway vertices, edges, or faces to weld")

    bmesh.ops.remove_doubles(bm, verts=selected_verts, dist=merge_distance)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.normal_update()
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=True)

    return {
        "removed_verts": max(0, before_vert_count - len(bm.verts)),
        "selected_verts": len(selected_verts),
    }


def _activate_object_vertex_edit(context, obj, selected_indices=None):
    if obj is None or obj.type != "MESH":
        raise RuntimeError("Target object must be a mesh")

    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    _deselect_all_in_view_layer(context)
    try:
        obj.hide_set(False)
    except Exception:
        pass
    try:
        obj.hide_viewport = False
    except Exception:
        pass
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_mode(type="VERT")

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    for vert in bm.verts:
        vert.select = False
    if selected_indices:
        for idx in selected_indices:
            if 0 <= idx < len(bm.verts):
                bm.verts[idx].select = True
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _activate_object_edit_mode(context, obj, select_mode="VERT"):
    if obj is None or obj.type != "MESH":
        raise RuntimeError("Target object must be a mesh")

    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    _deselect_all_in_view_layer(context)
    try:
        obj.hide_set(False)
    except Exception:
        pass
    try:
        obj.hide_viewport = False
    except Exception:
        pass
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_mode(type=select_mode)


def _delete_loose_vertices_by_local_keys(target_obj, local_keys, tolerance=1e-6):
    if target_obj is None or target_obj.type != "MESH" or not local_keys:
        return 0

    mesh = target_obj.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        remove_verts = [
            vert for vert in bm.verts
            if vert.is_valid
            and len(vert.link_edges) == 0
            and len(vert.link_faces) == 0
            and _vector_quantized_key(vert.co, tolerance) in local_keys
        ]
        if not remove_verts:
            return 0

        removed_count = len(remove_verts)
        bmesh.ops.delete(bm, geom=remove_verts, context="VERTS")
        bm.normal_update()
        bm.to_mesh(mesh)
        mesh.update(calc_edges=True)
        return removed_count
    finally:
        bm.free()


def _build_convex_hull_from_loose_geometry_verts(context, target_obj, merge_distance=0.0, recalc_normals=True):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target Geometry LOD object must be a mesh")
    if target_obj.mode != "EDIT":
        raise RuntimeError("Geometry object must be active in Edit Mode while building hull")

    mesh = target_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    before_vert_count = len(bm.verts)
    before_face_count = len(bm.faces)

    loose_verts = [
        vert for vert in bm.verts
        if vert.is_valid and vert.select and len(vert.link_edges) == 0 and len(vert.link_faces) == 0
    ]

    if len(loose_verts) < 4:
        raise RuntimeError("Need at least 4 selected loose vertices in Geometry to build a collider")

    if merge_distance > 0.0:
        bmesh.ops.remove_doubles(bm, verts=loose_verts, dist=merge_distance)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        loose_verts = [
            vert for vert in bm.verts
            if vert.is_valid and vert.select and len(vert.link_edges) == 0 and len(vert.link_faces) == 0
        ]

    local_points = [vert.co.copy() for vert in loose_verts if vert is not None and vert.is_valid]
    unique_point_keys = {_vector_quantized_key(point) for point in local_points}
    if len(unique_point_keys) < 4:
        raise RuntimeError("Selected loose vertices collapse below 4 unique points")

    hull = bmesh.ops.convex_hull(bm, input=loose_verts, use_existing_faces=False)
    final_faces = _finalize_convex_hull_geometry(bm, hull, loose_verts, recalc_normals=recalc_normals)
    _select_only_faces_in_bmesh(bm, final_faces)
    bm.normal_update()
    bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)
    try:
        bpy.ops.mesh.select_mode(type="FACE")
    except Exception:
        pass

    return {
        "verts_added": len(bm.verts) - before_vert_count,
        "faces_added": len(bm.faces) - before_face_count,
        "used_verts": len(unique_point_keys),
        "removed_source_verts": 0,
    }


def _build_convex_hull_from_current_selection_operator(context, target_obj, recalc_normals=True):
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target object must be a mesh")
    if context.mode != "EDIT_MESH" or target_obj.mode != "EDIT":
        raise RuntimeError("Convex hull requires the target object to be active in Edit Mode")

    mesh = target_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    selected_verts = {vert for vert in bm.verts if vert.select and vert.is_valid}
    for edge in bm.edges:
        if edge.select and edge.is_valid:
            for vert in edge.verts:
                if vert.is_valid:
                    selected_verts.add(vert)
    for face in bm.faces:
        if face.select and face.is_valid:
            for vert in face.verts:
                if vert.is_valid:
                    selected_verts.add(vert)

    unique_point_keys = {_vector_quantized_key(vert.co) for vert in selected_verts}
    if len(unique_point_keys) < 4:
        raise RuntimeError("Need at least 4 unique selected vertices to build a collider")

    before_vert_count = len(bm.verts)
    before_face_count = len(bm.faces)

    bpy.ops.mesh.select_mode(type="VERT")
    bpy.ops.mesh.convex_hull(
        delete_unused=True,
        use_existing_faces=False,
        make_holes=False,
        join_triangles=True,
        face_threshold=0.0001745329,
        shape_threshold=0.0001745329,
        uvs=False,
        vcols=False,
        seam=False,
        sharp=False,
        materials=False,
    )
    bpy.ops.mesh.select_mode(type="FACE")
    bpy.ops.mesh.tris_convert_to_quads(
        face_threshold=3.14159265,
        shape_threshold=3.14159265,
        uvs=False,
        vcols=False,
        seam=False,
        sharp=False,
        materials=False,
    )

    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    if recalc_normals:
        selected_faces = [face for face in bm.faces if face.select and face.is_valid]
        if selected_faces:
            bmesh.ops.recalc_face_normals(bm, faces=selected_faces)

    bm.normal_update()
    bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)
    try:
        bpy.ops.mesh.select_mode(type="FACE")
    except Exception:
        pass

    return {
        "verts_added": len(bm.verts) - before_vert_count,
        "faces_added": len(bm.faces) - before_face_count,
        "used_verts": len(unique_point_keys),
        "removed_source_verts": 0,
    }


def _build_collider_hull_from_world_points_via_edit_target(
    context,
    target_obj,
    world_points,
    merge_distance=0.0,
    recalc_normals=True,
):
    before_vert_count = len(target_obj.data.vertices)
    before_face_count = len(target_obj.data.polygons)

    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    added_indices = _append_world_vertices_to_object(target_obj, world_points)
    _activate_object_vertex_edit(context, target_obj, added_indices)
    stats = _build_convex_hull_from_loose_geometry_verts(
        context,
        target_obj,
        merge_distance=merge_distance,
        recalc_normals=recalc_normals,
    )
    stats["verts_added"] = len(target_obj.data.vertices) - before_vert_count
    stats["faces_added"] = len(target_obj.data.polygons) - before_face_count
    return stats


def _build_selection_hull_via_target(
    context,
    source_obj,
    target_obj,
    *,
    merge_distance=0.0,
    recalc_normals=True,
    box_thickness=0.0,
    loose_only=False,
):
    if source_obj is None or source_obj.type != "MESH" or source_obj.mode != "EDIT":
        raise RuntimeError("Source object must be the active mesh in Edit Mode")
    if target_obj is None or target_obj.type != "MESH":
        raise RuntimeError("Target Geometry LOD object must be a mesh")

    bm = bmesh.from_edit_mesh(source_obj.data)
    selected_faces = [face for face in bm.faces if face.select and face.is_valid]
    selected_edges = [edge for edge in bm.edges if edge.select and edge.is_valid]
    selected_verts = {vert for vert in bm.verts if vert.select and vert.is_valid}
    for edge in selected_edges:
        for vert in edge.verts:
            if vert.is_valid:
                selected_verts.add(vert)
    for face in selected_faces:
        for vert in face.verts:
            if vert.is_valid:
                selected_verts.add(vert)

    selected_geom = {
        "verts": list(selected_verts),
        "edges": selected_edges,
        "faces": selected_faces,
    }

    selection = _collect_selected_collider_input(source_obj, loose_only=loose_only)
    world_points = selection["world_points"]
    normal = selection["normal"]
    auto_thickened = False

    flat_eps = max(1e-5, merge_distance * 2.0)
    if _points_are_flat(world_points, normal, epsilon=flat_eps):
        if box_thickness <= 0.0:
            raise RuntimeError("Flat selection detected. Increase Thickness or use a non-flat selection")
        world_points = _extrude_points_along_normal(world_points, normal, box_thickness)
        auto_thickened = True

    if target_obj == source_obj and target_obj.mode == "EDIT":
        stats = _build_convex_hull_from_current_selection_operator(
            context,
            target_obj,
            recalc_normals=recalc_normals,
        )
    else:
        stats = _build_collider_hull_from_world_points_via_edit_target(
            context,
            target_obj,
            world_points,
            merge_distance=merge_distance,
            recalc_normals=recalc_normals,
        )

    stats["auto_thickened"] = auto_thickened
    return stats


def _collect_object_bounds_points(source_obj, padding=0.0, min_axis_size=0.0):
    if source_obj is None or source_obj.type != "MESH":
        raise RuntimeError("Source object must be a mesh")

    local_points = [Vector(corner) for corner in source_obj.bound_box]
    if not local_points:
        raise RuntimeError("Source object has no bounding box data")

    return _world_corners_from_local_bounds(
        source_obj,
        local_points,
        padding=padding,
        min_axis_size=min_axis_size,
    )

def _collect_single_selected_vertex_world_point(source_obj):
    if source_obj is None or source_obj.type != "MESH":
        raise RuntimeError("Source object must be a mesh")
    if source_obj.mode != "EDIT":
        raise RuntimeError("Source object must be the active mesh in Edit Mode")

    bm = bmesh.from_edit_mesh(source_obj.data)
    selected = [vert for vert in bm.verts if vert.select]
    if len(selected) != 1:
        raise RuntimeError("Select exactly one vertex on the active mesh")
    return source_obj.matrix_world @ selected[0].co.copy()

def _try_restore_edit_mode(context, obj):
    if obj is None or obj.type != "MESH":
        return
    if bpy.data.objects.get(obj.name) is None:
        return
    try:
        if context.view_layer.objects.active != obj:
            context.view_layer.objects.active = obj
        obj.select_set(True)
    except Exception:
        pass
    try:
        bpy.ops.object.mode_set(mode="EDIT")
    except Exception:
        pass


class CRAY_OT_CopySelectedVertsToGeometry(Operator):
    """Copy selected source vertices into the active Geometry LOD as loose points"""

    bl_idname = "cray.copy_selected_verts_to_geometry"
    bl_label = "Copy Selected Verts To Geometry"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        source_obj = _resolve_collider_selection_source_object(context, cs.source_object)
        if source_obj is None or source_obj.type != "MESH":
            self.report({"ERROR"}, "Source Object must be a mesh")
            return {"CANCELLED"}
        if source_obj.mode != "EDIT":
            self.report({"ERROR"}, "Copy requires the Source Object to be active in Edit Mode")
            return {"CANCELLED"}

        allow_same_source = (
            cs.geometry_object is not None
            and cs.geometry_object == source_obj
            and _is_collider_lod_mesh_object(source_obj, lod_token=cs.target_lod)
        )
        err = _collider_target_validation_error(
            cs.geometry_object,
            cs.target_lod,
            source_obj=source_obj,
            allow_same_source=allow_same_source,
        )
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        target_obj = _ensure_collider_lod_object(
            context,
            source_obj,
            cs.target_lod,
            preferred_obj=cs.geometry_object,
        )
        _set_collider_settings_object(context, "geometry_object", target_obj)

        try:
            if target_obj == source_obj and source_obj.mode == "EDIT":
                added_indices = _duplicate_selected_verts_as_loose_points_in_edit_object(target_obj)
                bpy.ops.mesh.select_mode(type="VERT")
            else:
                world_points = _collect_selected_vertex_world_points(source_obj)
                if context.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
                added_indices = _append_world_vertices_to_object(target_obj, world_points)
                _activate_object_vertex_edit(context, target_obj, added_indices)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"Copied {len(added_indices)} vertex/vertices to {target_obj.name}. You can now Shift+D in Geometry",
        )
        return {"FINISHED"}


class CRAY_OT_HullLooseGeometryVerts(Operator):
    """Build a convex hull from selected loose vertices in the Geometry LOD"""

    bl_idname = "cray.hull_loose_geometry_verts"
    bl_label = "Selected Loose Geometry Verts -> Hull"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        source_obj = cs.source_object if cs.source_object is not None and cs.source_object.type == "MESH" else None

        err = _collider_target_validation_error(cs.geometry_object, cs.target_lod)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        target_obj = _ensure_collider_lod_object(
            context,
            source_obj,
            cs.target_lod,
            preferred_obj=cs.geometry_object,
        )
        _set_collider_settings_object(context, "geometry_object", target_obj)

        try:
            if context.mode != "EDIT_MESH" or context.view_layer.objects.active != target_obj or target_obj.mode != "EDIT":
                self.report({"ERROR"}, "Select loose vertices on the Geometry LOD in Edit Mode")
                return {"CANCELLED"}
            stats = _build_convex_hull_from_loose_geometry_verts(
                context,
                target_obj,
                merge_distance=cs.merge_distance,
                recalc_normals=bool(cs.recalc_normals),
            )
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            (
                f"Built collider from {stats['used_verts']} selected loose Geometry verts in {target_obj.name}: "
                f"+{stats['faces_added']} faces"
            ),
        )
        return {"FINISHED"}


class CRAY_OT_ColliderHotkeysInfo(Operator):
    """Hover to see the NH collider hotkeys"""

    bl_idname = "cray.collider_hotkeys_info"
    bl_label = "Collider Hotkeys"
    bl_options = {"INTERNAL"}

    @classmethod
    def description(cls, context, properties):
        del context, properties
        return (
            "Ctrl+Shift+C: Copy Selected Verts To Geometry\n"
            "Mouse5: Select Isolated Verts\n"
            "Mouse4: Selection -> Hull"
        )

    def execute(self, context):
        del context
        return {"FINISHED"}


class CRAY_OT_SetColliderTargetFromActive(Operator):
    """Use the active selected mesh as the current target object"""

    bl_idname = "cray.set_collider_target_from_active"
    bl_label = "Use Active Mesh"
    bl_options = {"REGISTER", "UNDO"}

    target_attr: EnumProperty(
        name="Target",
        items=(
            ("GEOMETRY", "Target LOD Object", "Set the main Geometry Collider target"),
            ("FIRE", "Fire Geometry", "Set the Fire Geometry target"),
            ("ROADWAY", "Roadway", "Set the Roadway target"),
        ),
        default="GEOMETRY",
        options={"HIDDEN"},
    )

    @classmethod
    def description(cls, context, properties):
        del context
        label = {
            "GEOMETRY": "Target LOD Object",
            "FIRE": "Fire Geometry",
            "ROADWAY": "Roadway",
        }.get(getattr(properties, "target_attr", "GEOMETRY"), "target")
        return f"Use the active selected mesh as {label}"

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        obj = _active_or_selected_mesh_object(context)
        if obj is None:
            self.report({"ERROR"}, "Select a mesh object first")
            return {"CANCELLED"}

        target_attr = str(getattr(self, "target_attr", "GEOMETRY") or "GEOMETRY").upper()
        if target_attr == "FIRE":
            if not _poll_fire_geometry_object(None, obj):
                self.report({"ERROR"}, "Active mesh name must start with 'Fire Geometry'")
                return {"CANCELLED"}
            _set_collider_settings_object(context, "fire_geometry_object", obj)
            _set_collider_settings_object(context, "geometry_object", obj)
            try:
                cs.target_lod = _FIRE_GEOMETRY_LOD_TOKEN
            except Exception:
                pass
            _sync_fire_geometry_material_selection(context)
        elif target_attr == "ROADWAY":
            if not _poll_roadway_object(None, obj):
                self.report({"ERROR"}, "Active mesh name must start with 'Roadway'")
                return {"CANCELLED"}
            _set_collider_settings_object(context, "roadway_object", obj)
            _sync_roadway_material_selection(context)
        else:
            _set_collider_settings_object(context, "geometry_object", obj)
            lod_token = _collider_lod_token_from_object(obj, allow_name_fallback=True)
            if lod_token in _COLLIDER_LOD_NAMES:
                try:
                    cs.target_lod = lod_token
                except Exception:
                    pass
            if lod_token == _FIRE_GEOMETRY_LOD_TOKEN:
                _set_collider_settings_object(context, "fire_geometry_object", obj)
                _sync_fire_geometry_material_selection(context)

        self.report({"INFO"}, f"Target set to {obj.name}")
        return {"FINISHED"}


class CRAY_OT_EnsureRoadwayLOD(Operator):
    """Create or find the Roadway LOD mesh inside Misc collection"""

    bl_idname = "cray.ensure_roadway_lod"
    bl_label = "Create/Find Misc Roadway"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        source_obj = _resolve_collider_source_object(context, cs.source_object)

        err = _collider_target_validation_error(cs.roadway_object, _ROADWAY_LOD_TOKEN, source_obj=source_obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        try:
            roadway_obj = _ensure_roadway_lod_object(
                context,
                source_obj,
                preferred_obj=cs.roadway_object,
            )
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        _set_collider_settings_object(context, "roadway_object", roadway_obj)
        _sync_roadway_material_selection(context)
        self.report({"INFO"}, f"Roadway LOD ready: {roadway_obj.name}")
        return {"FINISHED"}


class CRAY_OT_CopySelectedFacesToRoadway(Operator):
    """Copy selected source polygons into the Roadway mesh in Misc collection"""

    bl_idname = "cray.copy_selected_faces_to_roadway"
    bl_label = "Copy Selected Faces To Roadway"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        source_obj = _resolve_collider_selection_source_object(context, cs.source_object)
        if source_obj is None or source_obj.type != "MESH":
            self.report({"ERROR"}, "Source Object must be a mesh")
            return {"CANCELLED"}
        if source_obj.mode != "EDIT":
            self.report({"ERROR"}, "Copy requires the Source Object to be active in Edit Mode")
            return {"CANCELLED"}

        err = _collider_target_validation_error(cs.roadway_object, _ROADWAY_LOD_TOKEN, source_obj=source_obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        try:
            roadway_obj = _ensure_roadway_lod_object(
                context,
                source_obj,
                preferred_obj=cs.roadway_object,
            )
            stats = _append_selected_faces_to_object(
                roadway_obj,
                source_obj,
                recalc_normals=bool(cs.recalc_normals),
                weld_distance=cs.roadway_weld_distance,
            )
            _activate_object_edit_mode(context, roadway_obj, select_mode="FACE")
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        _set_collider_settings_object(context, "roadway_object", roadway_obj)
        _sync_roadway_material_selection(context, stats.get("preferred_material_name", ""))
        self.report(
            {"INFO"},
            f"Copied source polygons to {roadway_obj.name}: +{stats['verts_added']} verts, +{stats['faces_added']} faces",
        )
        return {"FINISHED"}


class CRAY_OT_WeldRoadwayVertices(Operator):
    """Merge near-duplicate vertices only inside the current Roadway selection"""

    bl_idname = "cray.weld_roadway_vertices"
    bl_label = "Weld Roadway"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        target_obj = cs.roadway_object
        if target_obj is None or target_obj.type != "MESH":
            self.report({"ERROR"}, "Roadway Object must be a mesh")
            return {"CANCELLED"}
        if context.mode != "EDIT_MESH" or target_obj.mode != "EDIT":
            self.report({"ERROR"}, "Weld Roadway works only on the current Roadway selection in Edit Mode")
            return {"CANCELLED"}

        if cs.roadway_weld_distance <= 0.0:
            self.report({"ERROR"}, "Roadway Weld Distance must be greater than zero")
            return {"CANCELLED"}

        try:
            stats = _weld_mesh_vertices(target_obj, cs.roadway_weld_distance)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            (
                f"Welded selected Roadway elements in '{target_obj.name}': "
                f"removed {stats['removed_verts']} duplicate vert(s)"
            ),
        )
        return {"FINISHED"}


class CRAY_OT_OpenRoadwayMaterialFolder(Operator):
    """Pick a roadway material file inside Blender and assign it to the selected Roadway material"""

    bl_idname = "cray.open_roadway_material_folder"
    bl_label = "Choose Roadway Material Path"
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(
        name="Material File",
        description="Choose an .rvmat or .paa file for the selected Roadway material",
        subtype="FILE_PATH",
    )
    filter_glob: StringProperty(default="*.rvmat;*.paa", options={"HIDDEN"})

    def invoke(self, context, event):
        del event

        mat = _get_selected_roadway_material(context)
        if mat is None:
            self.report({"ERROR"}, "Select or create a Roadway material first")
            return {"CANCELLED"}

        default_dir = _ROADWAY_SURFACES_FOLDER if os.path.isdir(_ROADWAY_SURFACES_FOLDER) else ""
        if not default_dir:
            blend_dir = bpy.path.abspath("//")
            if blend_dir and os.path.isdir(blend_dir):
                default_dir = blend_dir
            else:
                default_dir = os.getcwd()

        self.filepath = os.path.join(default_dir, "")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        mat = _get_selected_roadway_material(context)
        if mat is None:
            self.report({"ERROR"}, "Roadway material not found on the selected Roadway object")
            return {"CANCELLED"}

        try:
            filepath = os.path.abspath(bpy.path.abspath(self.filepath or ""))
        except Exception as e:
            self.report({"ERROR"}, f"Could not resolve material path: {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not filepath or not os.path.isfile(filepath):
            self.report({"ERROR"}, "Choose an existing .rvmat or .paa file")
            return {"CANCELLED"}

        ext = os.path.splitext(filepath)[1].lower()
        try:
            if ext == ".rvmat":
                _set_a3ob_material_paths(mat, None, _norm_path(filepath))
            elif ext == ".paa":
                _set_a3ob_material_paths(mat, _norm_path(filepath), None)
            else:
                self.report({"ERROR"}, "Unsupported file type. Choose .rvmat or .paa")
                return {"CANCELLED"}
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        new_name = _basename_no_ext(filepath)
        if new_name:
            try:
                mat.name = new_name
            except Exception:
                pass

        _sync_roadway_material_selection(context, mat.name)
        if ext == ".rvmat":
            self.report({"INFO"}, f"Assigned .rvmat to roadway material: {mat.name}")
        else:
            self.report({"INFO"}, f"Assigned .paa to roadway material: {mat.name}")
        return {"FINISHED"}


class CRAY_OT_OpenFireGeometryRvmatFolder(Operator):
    """Pick a penetration .rvmat and assign it to the selected Fire Geometry material"""

    bl_idname = "cray.open_fire_geometry_rvmat_folder"
    bl_label = "Choose Fire Geometry RVMAT Path"
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(
        name="RVMAT File",
        description="Choose an .rvmat file for the selected Fire Geometry material",
        subtype="FILE_PATH",
    )
    filter_glob: StringProperty(default="*.rvmat", options={"HIDDEN"})

    def invoke(self, context, event):
        del event

        fire_obj = _resolve_fire_geometry_object_for_material(context)
        if fire_obj is None or getattr(fire_obj, "type", None) != "MESH":
            self.report({"ERROR"}, "Create or assign a Fire Geometry object first")
            return {"CANCELLED"}

        default_dir = _FIRE_GEOMETRY_RVMAT_FOLDER if os.path.isdir(_FIRE_GEOMETRY_RVMAT_FOLDER) else ""
        if not default_dir:
            blend_dir = bpy.path.abspath("//")
            if blend_dir and os.path.isdir(blend_dir):
                default_dir = blend_dir
            else:
                default_dir = os.getcwd()

        self.filepath = os.path.join(default_dir, "")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        fire_obj = _resolve_fire_geometry_object_for_material(context)
        if fire_obj is None or getattr(fire_obj, "type", None) != "MESH":
            self.report({"ERROR"}, "Fire Geometry Object must be a mesh")
            return {"CANCELLED"}

        try:
            filepath = os.path.abspath(bpy.path.abspath(self.filepath or ""))
        except Exception as e:
            self.report({"ERROR"}, f"Could not resolve RVMAT path: {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not filepath or not os.path.isfile(filepath):
            self.report({"ERROR"}, "Choose an existing .rvmat file")
            return {"CANCELLED"}
        if os.path.splitext(filepath)[1].lower() != ".rvmat":
            self.report({"ERROR"}, "Unsupported file type. Choose .rvmat")
            return {"CANCELLED"}

        material_name = _basename_no_ext(filepath) or "FireGeometryMaterial"
        mat = _get_selected_fire_geometry_material(context, create_name=material_name)
        if mat is None:
            self.report({"ERROR"}, "Could not create or select a Fire Geometry material")
            return {"CANCELLED"}

        try:
            _set_a3ob_material_paths(mat, None, _norm_path(filepath))
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        try:
            mat.name = material_name
        except Exception:
            pass

        _sync_fire_geometry_material_selection(context, mat.name)
        self.report({"INFO"}, f"Assigned Fire Geometry .rvmat: {mat.name}")
        return {"FINISHED"}


class CRAY_OT_SelectIsolatedVertices(Operator):
    """Select all isolated vertices that are not used by any edge or polygon"""

    bl_idname = "cray.select_isolated_vertices"
    bl_label = "Select Isolated Verts"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return context.mode == "EDIT_MESH" and obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Active object must be a mesh in Edit Mode")
            return {"CANCELLED"}

        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        isolated_verts = [
            vert for vert in bm.verts
            if vert.is_valid and len(vert.link_edges) == 0 and len(vert.link_faces) == 0
        ]

        if not isolated_verts:
            self.report({"WARNING"}, "No isolated vertices found")
            return {"CANCELLED"}

        context.tool_settings.mesh_select_mode = (True, False, False)

        for face in bm.faces:
            face.select = False
        for edge in bm.edges:
            edge.select = False
        for vert in bm.verts:
            vert.select = False
        for vert in isolated_verts:
            vert.select = True

        bm.select_flush_mode()
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        self.report({"INFO"}, f"Selected {len(isolated_verts)} isolated vertex/vertices")
        return {"FINISHED"}


class CRAY_OT_SelectLooseVerticesOutsideMemory(Operator):
    """Find non-Memory LOD loose vertices and select them on the first matching mesh"""

    bl_idname = "cray.select_loose_vertices_outside_memory"
    bl_label = "Select Loose Vertices Outside Memory"
    bl_description = (
        "Find isolated vertices in exportable LODs outside Point clouds > Memory, "
        "then select the first matching mesh in Edit Mode"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            records = _collect_loose_vertices_outside_memory_records(context)
        except Exception as e:
            self.report({"ERROR"}, f"Loose vertex scan failed: {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not records:
            self.report({"INFO"}, "No loose vertices outside Memory found")
            return {"FINISHED"}

        total_vertices = sum(int(rec.get("isolated_count", 0) or 0) for rec in records)
        print("=== Select Loose Vertices Outside Memory ===")
        print(f"Found {total_vertices} loose vertex/vertices in {len(records)} mesh object(s).")
        for rec in records:
            root_collection = rec.get("root_collection")
            root_name = getattr(root_collection, "name", "<unknown>")
            actual_branch = " > ".join(rec.get("actual_branch", ()) or ())
            indices = list(rec.get("isolated_indices", []) or [])
            index_preview = ", ".join(str(idx) for idx in indices[:20])
            if len(indices) > 20:
                index_preview += ", ..."
            print(
                f" - {root_name} | LOD: {rec.get('lod_name', '')} | "
                f"mesh: {rec.get('mesh_object_name', '')} | loose vertices: {len(indices)} | "
                f"branch: {actual_branch} | indices: {index_preview}"
            )

        target = records[0]
        target_obj = target.get("mesh_object")
        target_root = target.get("root_collection")
        target_indices = list(target.get("isolated_indices", []) or [])
        if target_obj is None or target_obj.type != "MESH" or target_obj.data is None or not target_indices:
            self.report({"ERROR"}, "Loose vertex target is no longer available")
            return {"CANCELLED"}

        try:
            if target_root is not None:
                _ensure_collection_visible_in_view_layer(context, target_root)
            _activate_object_vertex_edit(context, target_obj)
            try:
                bpy.ops.mesh.reveal(select=False)
            except Exception:
                pass

            context.tool_settings.mesh_select_mode = (True, False, False)
            bm = bmesh.from_edit_mesh(target_obj.data)
            bm.verts.ensure_lookup_table()
            target_index_set = set(target_indices)
            selected_count = 0

            for face in bm.faces:
                face.select = False
            for edge in bm.edges:
                edge.select = False
            for vert in bm.verts:
                is_target = vert.index in target_index_set
                vert.select = is_target
                if is_target:
                    selected_count += 1

            bm.select_flush_mode()
            bmesh.update_edit_mesh(target_obj.data, loop_triangles=False, destructive=False)
            _tag_redraw_all_areas(context)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to select loose vertices: {_fmt_exc(e)}")
            return {"CANCELLED"}

        msg = f"Selected {selected_count} loose vertex/vertices on {target_obj.name}"
        if len(records) > 1:
            msg += f"; {len(records) - 1} more mesh object(s) listed in System Console"
            self.report({"WARNING"}, msg)
        else:
            self.report({"INFO"}, msg)
        return {"FINISHED"}


def _iter_split_planar_candidate_faces(bm):
    visible_faces = [face for face in bm.faces if face.is_valid and not face.hide]
    if not visible_faces:
        return [], "visible"

    selected_faces = [face for face in visible_faces if face.select]
    if selected_faces:
        return selected_faces, "selection"

    selected_verts = {vert for vert in bm.verts if vert.is_valid and not vert.hide and vert.select}
    selected_edges = {edge for edge in bm.edges if edge.is_valid and not edge.hide and edge.select}
    if not selected_verts and not selected_edges:
        return visible_faces, "visible"

    scoped_faces = []
    for face in visible_faces:
        if any(vert in selected_verts for vert in face.verts):
            scoped_faces.append(face)
            continue
        if any(edge in selected_edges for edge in face.edges):
            scoped_faces.append(face)

    if scoped_faces:
        return scoped_faces, "selection"
    return visible_faces, "visible"


def _split_planar_face_matches_seed_plane(face, plane_point, plane_normal, cos_limit, plane_tolerance):
    if face is None or not face.is_valid or face.hide:
        return False
    if plane_normal.length_squared <= 1e-12:
        return False
    if face.normal.length_squared <= 1e-12:
        return False

    face_normal = face.normal.copy()
    try:
        face_normal.normalize()
    except Exception:
        return False

    if abs(face_normal.dot(plane_normal)) < cos_limit:
        return False

    for vert in face.verts:
        if abs(plane_normal.dot(vert.co - plane_point)) > plane_tolerance:
            return False
    return True


def _collect_split_planar_region(seed_face, allowed_faces, cos_limit, plane_tolerance):
    plane_normal = seed_face.normal.copy()
    if plane_normal.length_squared <= 1e-12 or len(seed_face.verts) < 3:
        return []
    plane_normal.normalize()
    plane_point = seed_face.verts[0].co.copy()

    region_faces = []
    region_set = {seed_face}
    stack = [seed_face]

    while stack:
        face = stack.pop()
        region_faces.append(face)
        for edge in face.edges:
            for neighbor in edge.link_faces:
                if neighbor == face or neighbor not in allowed_faces or neighbor in region_set:
                    continue
                if _split_planar_face_matches_seed_plane(
                    neighbor,
                    plane_point,
                    plane_normal,
                    cos_limit,
                    plane_tolerance,
                ):
                    region_set.add(neighbor)
                    stack.append(neighbor)

    return region_faces


def _collect_connected_face_island(seed_face, allowed_faces):
    if seed_face is None or not seed_face.is_valid or seed_face.hide:
        return []

    island_faces = []
    island_set = {seed_face}
    stack = [seed_face]

    while stack:
        face = stack.pop()
        island_faces.append(face)
        for edge in face.edges:
            for neighbor in edge.link_faces:
                if neighbor == face or neighbor not in allowed_faces or neighbor in island_set:
                    continue
                if neighbor is None or not neighbor.is_valid or neighbor.hide:
                    continue
                island_set.add(neighbor)
                stack.append(neighbor)

    return island_faces


def _connected_face_island_counts(island_faces):
    face_set = {face for face in island_faces if face is not None and face.is_valid}
    vert_set = {vert for face in face_set for vert in face.verts if vert is not None and vert.is_valid}
    edge_set = {edge for face in face_set for edge in face.edges if edge is not None and edge.is_valid}
    return len(vert_set), len(face_set), len(edge_set)


def _connected_face_island_is_coplanar(island_faces, cos_limit, plane_tolerance):
    face_set = [face for face in island_faces if face is not None and face.is_valid and not face.hide]
    if not face_set:
        return False

    seed_face = face_set[0]
    if seed_face.normal.length_squared <= 1e-12 or len(seed_face.verts) < 3:
        return False

    plane_normal = seed_face.normal.copy()
    try:
        plane_normal.normalize()
    except Exception:
        return False
    plane_point = seed_face.verts[0].co.copy()

    for face in face_set:
        if not _split_planar_face_matches_seed_plane(
            face,
            plane_point,
            plane_normal,
            cos_limit,
            plane_tolerance,
        ):
            return False
    return True


def _split_planar_region_is_thin(region_faces, plane_point, plane_normal, cos_limit, plane_tolerance):
    region_set = {face for face in region_faces if face is not None and face.is_valid}
    if not region_set or plane_normal.length_squared <= 1e-12:
        return False

    region_verts = {vert for face in region_set for vert in face.verts if vert is not None and vert.is_valid}
    for vert in region_verts:
        for linked_face in vert.link_faces:
            if linked_face in region_set:
                continue
            if linked_face is None or not linked_face.is_valid or linked_face.hide:
                continue
            if not _split_planar_face_matches_seed_plane(
                linked_face,
                plane_point,
                plane_normal,
                cos_limit,
                plane_tolerance,
            ):
                return False
    return True


def _add_split_region_match(matches_by_signature, region_faces, boundary_edges, boundary_verts, match_kind):
    face_set = {face for face in region_faces if face is not None and face.is_valid}
    if not face_set:
        return False

    signature = frozenset(face_set)
    existing = matches_by_signature.get(signature)
    if existing is None:
        matches_by_signature[signature] = {
            "faces": list(face_set),
            "boundary_edges": [edge for edge in boundary_edges if edge is not None and edge.is_valid],
            "boundary_verts": [vert for vert in boundary_verts if vert is not None and vert.is_valid],
            "kind": match_kind,
        }
        return True

    if existing.get("kind") != "tiny" and match_kind == "tiny":
        existing["kind"] = "tiny"
    elif existing.get("kind") not in {"tiny", "coplanar"} and match_kind == "coplanar":
        existing["kind"] = "coplanar"
    return False


def _classify_split_planar_region_edges(region_faces):
    region_set = set(region_faces)
    boundary_edges = []
    seen_edges = set()
    non_manifold = False

    for face in region_faces:
        for edge in face.edges:
            if edge in seen_edges:
                continue
            seen_edges.add(edge)
            inside_count = sum(1 for link_face in edge.link_faces if link_face in region_set)
            if inside_count == 1:
                boundary_edges.append(edge)
            elif inside_count > 2:
                non_manifold = True

    boundary_verts = {vert for edge in boundary_edges for vert in edge.verts}
    return boundary_edges, boundary_verts, non_manifold


def _split_planar_boundary_is_single_loop(boundary_edges, boundary_verts):
    if not boundary_edges or not boundary_verts:
        return False

    vert_edges = {vert: [] for vert in boundary_verts}
    for edge in boundary_edges:
        if edge is None or not edge.is_valid:
            return False
        for vert in edge.verts:
            if vert not in vert_edges:
                return False
            vert_edges[vert].append(edge)

    if any(len(edges) != 2 for edges in vert_edges.values()):
        return False

    start_vert = next(iter(boundary_verts))
    seen_verts = set()
    stack = [start_vert]
    while stack:
        vert = stack.pop()
        if vert in seen_verts:
            continue
        seen_verts.add(vert)
        for edge in vert_edges[vert]:
            other_vert = edge.other_vert(vert)
            if other_vert not in seen_verts:
                stack.append(other_vert)

    return len(seen_verts) == len(boundary_verts)


def _collect_candidate_face_islands(bm):
    candidate_faces, scope_label = _iter_split_planar_candidate_faces(bm)
    if not candidate_faces:
        return [], scope_label

    allowed_faces = set(candidate_faces)
    islands = []
    processed = set()

    for seed_face in candidate_faces:
        if seed_face in processed or not seed_face.is_valid:
            continue

        island_faces = _collect_connected_face_island(seed_face, allowed_faces)
        if not island_faces:
            processed.add(seed_face)
            continue

        island_faces = [face for face in island_faces if face is not None and face.is_valid]
        if not island_faces:
            continue

        processed.update(island_faces)
        islands.append(island_faces)

    return islands, scope_label


def _build_face_island_match(island_faces, kind, counts=None):
    face_set = {face for face in island_faces if face is not None and face.is_valid}
    edge_set = {edge for face in face_set for edge in face.edges if edge is not None and edge.is_valid}
    vert_set = {vert for face in face_set for vert in face.verts if vert is not None and vert.is_valid}
    return {
        "faces": list(face_set),
        "edges": list(edge_set),
        "verts": list(vert_set),
        "kind": kind,
        "counts": counts or {},
    }


def _select_face_island_matches(bm, matches):
    selected_faces = set()
    selected_edges = set()
    selected_verts = set()

    for item in matches:
        selected_faces.update(face for face in item.get("faces", []) if face is not None and face.is_valid)
        selected_edges.update(edge for edge in item.get("edges", []) if edge is not None and edge.is_valid)
        selected_verts.update(vert for vert in item.get("verts", []) if vert is not None and vert.is_valid)

    for face in bm.faces:
        face.select = False
    for edge in bm.edges:
        edge.select = False
    for vert in bm.verts:
        vert.select = False

    for face in selected_faces:
        face.select = True
    for edge in selected_edges:
        edge.select = True
    for vert in selected_verts:
        vert.select = True

    bm.select_flush_mode()


def _find_small_trash_face_islands(bm):
    islands, scope_label = _collect_candidate_face_islands(bm)
    matches = []

    for island_faces in islands:
        vert_count, face_count, edge_count = _connected_face_island_counts(island_faces)
        if (
            vert_count < _TRASH_TINY_ISLAND_MAX_VERTS
            or edge_count < _TRASH_TINY_ISLAND_MAX_EDGES
            or face_count < _TRASH_TINY_ISLAND_MAX_FACES
        ):
            matches.append(
                _build_face_island_match(
                    island_faces,
                    "trash",
                    counts={
                        "verts": vert_count,
                        "edges": edge_count,
                        "faces": face_count,
                    },
                )
            )

    return matches, scope_label


def _find_coplanar_plate_face_islands(bm, angle_tolerance_deg=0.1, plane_tolerance=0.0001):
    islands, scope_label = _collect_candidate_face_islands(bm)
    matches = []
    cos_limit = math.cos(math.radians(max(0.0, min(180.0, float(angle_tolerance_deg)))))
    plane_tolerance = max(0.0, float(plane_tolerance))

    for island_faces in islands:
        if not _connected_face_island_is_coplanar(island_faces, cos_limit, plane_tolerance):
            continue

        seed_face = next((face for face in island_faces if face is not None and face.is_valid), None)
        if seed_face is None or seed_face.normal.length_squared <= 1e-12 or len(seed_face.verts) < 3:
            continue

        plane_normal = seed_face.normal.copy()
        plane_normal.normalize()
        plane_point = seed_face.verts[0].co.copy()

        boundary_edges, boundary_verts, non_manifold = _classify_split_planar_region_edges(island_faces)
        if non_manifold:
            continue
        if not _split_planar_boundary_is_single_loop(boundary_edges, boundary_verts):
            continue
        if not _split_planar_region_is_thin(
            island_faces,
            plane_point,
            plane_normal,
            cos_limit,
            plane_tolerance,
        ):
            continue

        vert_count, face_count, edge_count = _connected_face_island_counts(island_faces)
        matches.append(
            _build_face_island_match(
                island_faces,
                "plate",
                counts={
                    "verts": vert_count,
                    "edges": edge_count,
                    "faces": face_count,
                },
            )
        )

    return matches, scope_label


class CRAY_OT_SelectSplitPlanarNgons(Operator):
    """Select tiny connected face islands treated as trash"""

    bl_idname = "cray.select_split_planar_ngons"
    bl_label = "Select Trash Islands"
    bl_description = (
        "In Edit Mode, find connected face islands treated as trash: "
        "verts < 5 or edges < 8 or faces < 5. "
        "If faces, edges, or verts are already selected, only that local area is searched"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            context.mode == "EDIT_MESH"
            and obj is not None
            and obj.type == "MESH"
            and obj.mode == "EDIT"
        )

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH" or context.mode != "EDIT_MESH" or obj.mode != "EDIT":
            self.report({"ERROR"}, "Active object must be a mesh in Edit Mode")
            return {"CANCELLED"}

        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        try:
            matches, scope_label = _find_small_trash_face_islands(bm)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to analyze trash islands: {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not matches:
            self.report(
                {"WARNING"},
                (
                    f"No trash islands found "
                    f"(verts < {_TRASH_TINY_ISLAND_MAX_VERTS} or "
                    f"edges < {_TRASH_TINY_ISLAND_MAX_EDGES} or "
                    f"faces < {_TRASH_TINY_ISLAND_MAX_FACES}) "
                    f"in {scope_label} scope"
                ),
            )
            return {"CANCELLED"}

        context.tool_settings.mesh_select_mode = (False, False, True)
        _select_face_island_matches(bm, matches)
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)

        face_total = sum(len(item["faces"]) for item in matches)
        edge_total = sum(len(item["edges"]) for item in matches)
        vert_total = sum(len(item["verts"]) for item in matches)
        self.report(
            {"INFO"},
            (
                f"Selected {len(matches)} trash island(s): "
                f"{face_total} faces, {edge_total} edges, {vert_total} verts "
                f"in {scope_label} scope"
            ),
        )
        return {"FINISHED"}


class CRAY_OT_SelectCoplanarPlateIslands(Operator):
    """Select connected face islands that form a flat plate in one plane"""

    bl_idname = "cray.select_coplanar_plate_islands"
    bl_label = "Select Flat Plates"
    bl_description = (
        "In Edit Mode, find connected face islands that lie in one plane like a flat plate. "
        "If faces, edges, or verts are already selected, only that local area is searched"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            context.mode == "EDIT_MESH"
            and obj is not None
            and obj.type == "MESH"
            and obj.mode == "EDIT"
        )

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH" or context.mode != "EDIT_MESH" or obj.mode != "EDIT":
            self.report({"ERROR"}, "Active object must be a mesh in Edit Mode")
            return {"CANCELLED"}

        ts = context.scene.cray_texreplace_settings
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        try:
            matches, scope_label = _find_coplanar_plate_face_islands(
                bm,
                angle_tolerance_deg=float(ts.split_planar_ngon_angle_tolerance),
                plane_tolerance=float(ts.split_planar_ngon_plane_tolerance),
            )
        except Exception as e:
            self.report({"ERROR"}, f"Failed to analyze flat plates: {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not matches:
            self.report({"WARNING"}, f"No flat plates found in {scope_label} scope")
            return {"CANCELLED"}

        context.tool_settings.mesh_select_mode = (False, False, True)
        _select_face_island_matches(bm, matches)
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)

        face_total = sum(len(item["faces"]) for item in matches)
        edge_total = sum(len(item["edges"]) for item in matches)
        vert_total = sum(len(item["verts"]) for item in matches)
        self.report(
            {"INFO"},
            (
                f"Selected {len(matches)} flat plate island(s): "
                f"{face_total} faces, {edge_total} edges, {vert_total} verts "
                f"in {scope_label} scope"
            ),
        )
        return {"FINISHED"}


class CRAY_OT_EnsureColliderLOD(Operator):
    """Create or find the Geometry LOD object and move it into the Geometries collection"""

    bl_idname = "cray.ensure_collider_lod"
    bl_label = "Create/Find Collider LOD"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        source_obj = _resolve_collider_source_object(context, cs.source_object)
        previous_active = context.view_layer.objects.active if context.view_layer is not None else None

        err = _collider_target_validation_error(cs.geometry_object, cs.target_lod, source_obj=source_obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        target_obj = _ensure_collider_lod_object(
            context,
            source_obj,
            cs.target_lod,
            preferred_obj=cs.geometry_object,
        )
        _set_collider_settings_object(context, "geometry_object", target_obj)
        if str(getattr(cs, "target_lod", "") or "") == _FIRE_GEOMETRY_LOD_TOKEN:
            _set_collider_settings_object(context, "fire_geometry_object", target_obj)
            _sync_fire_geometry_material_selection(context)
        try:
            context.view_layer.update()
        except Exception:
            pass
        if context.mode == "OBJECT" and source_obj is None:
            _deselect_all_in_view_layer(context)
            target_obj.select_set(True)
            context.view_layer.objects.active = target_obj
        elif context.mode == "OBJECT" and previous_active is not None:
            try:
                context.view_layer.objects.active = previous_active
            except Exception:
                pass
        self.report({"INFO"}, f"Collider LOD ready: {target_obj.name}")
        return {"FINISHED"}


class CRAY_OT_BuildCollider(Operator):
    """Directly build collider geometry from the current source selection or object bounds"""

    bl_idname = "cray.build_collider"
    bl_label = "Build Collider"
    bl_options = {"REGISTER", "UNDO"}

    build_mode: EnumProperty(
        name="Build Mode",
        items=(
            ("SELECTION_HULL", "Selection -> Hull", "Selected vertices/faces to convex hull"),
            ("ISOLATED_VERTS_HULL", "Isolated Verts -> Hull", "Use only isolated selected vertices to convex hull"),
            ("SELECTION_BOX", "Selection -> Box", "Selected wall/plane to thickness box"),
            ("OBJECT_BOUNDS", "Object -> Bounds", "Whole object bounds to box collider"),
        ),
        default="SELECTION_HULL",
        options={"HIDDEN"},
    )

    @classmethod
    def description(cls, context, properties):
        mode = getattr(properties, "build_mode", "SELECTION_HULL")
        return {
            "SELECTION_HULL": "Build a convex hull directly from the current source selection",
            "ISOLATED_VERTS_HULL": "Build a convex hull from isolated source vertices only",
            "SELECTION_BOX": "Build a box-like collider from a flat source selection using Thickness",
            "OBJECT_BOUNDS": "Build a box collider from the source object's local bounds",
        }.get(mode, cls.__doc__ or "")

    def execute(self, context):
        cs = context.scene.cray_collider_settings
        if self.build_mode == "OBJECT_BOUNDS":
            source_obj = _resolve_collider_source_object(context, cs.source_object)
        else:
            source_obj = _resolve_collider_selection_source_object(context, cs.source_object)
        if source_obj is None or source_obj.type != "MESH":
            self.report({"ERROR"}, "Source Object must be a mesh")
            return {"CANCELLED"}
        allow_same_source = (
            self.build_mode == "SELECTION_HULL"
            and cs.geometry_object is not None
            and cs.geometry_object == source_obj
            and _is_collider_lod_mesh_object(source_obj, lod_token=cs.target_lod)
        )
        err = _collider_target_validation_error(
            cs.geometry_object,
            cs.target_lod,
            source_obj=source_obj,
            allow_same_source=allow_same_source,
        )
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        if self.build_mode != "OBJECT_BOUNDS":
            active = context.view_layer.objects.active
            if active != source_obj or source_obj.mode != "EDIT":
                self.report({"ERROR"}, "Selection modes require the Source Object to be active in Edit Mode")
                return {"CANCELLED"}

        target_obj = _ensure_collider_lod_object(
            context,
            source_obj,
            cs.target_lod,
            preferred_obj=cs.geometry_object,
        )
        _set_collider_settings_object(context, "geometry_object", target_obj)

        if self.build_mode == "SELECTION_HULL":
            try:
                stats = _build_selection_hull_via_target(
                    context,
                    source_obj,
                    target_obj,
                    merge_distance=cs.merge_distance,
                    recalc_normals=bool(cs.recalc_normals),
                    box_thickness=cs.box_thickness,
                    loose_only=False,
                )
            except Exception as e:
                self.report({"ERROR"}, _fmt_exc(e))
                return {"CANCELLED"}

            extras = []
            if stats.get("auto_thickened"):
                extras.append(f"auto-thickness {cs.box_thickness:g}")
            extra_suffix = "" if not extras else f" ({', '.join(extras)})"
            self.report(
                {"INFO"},
                (
                    f"Built selection hull in {target_obj.name}: "
                    f"+{stats['verts_added']} verts, +{stats['faces_added']} faces{extra_suffix}"
                ),
            )
            return {"FINISHED"}

        if target_obj == source_obj and source_obj.mode == "EDIT":
            self.report({"ERROR"}, "Target Geometry LOD must be separate from the edited source mesh")
            return {"CANCELLED"}

        auto_thickened = False
        try:
            if self.build_mode == "OBJECT_BOUNDS":
                world_points = _collect_object_bounds_points(
                    source_obj,
                    padding=cs.bounds_padding,
                    min_axis_size=cs.box_thickness,
                )
            else:
                selection = _collect_selected_collider_input(
                    source_obj,
                    loose_only=(self.build_mode == "ISOLATED_VERTS_HULL"),
                )
                world_points = selection["world_points"]
                normal = selection["normal"]

                if self.build_mode == "SELECTION_BOX":
                    world_points = _extrude_points_along_normal(world_points, normal, cs.box_thickness)
                else:
                    flat_eps = max(1e-5, cs.merge_distance * 2.0)
                    if _points_are_flat(world_points, normal, epsilon=flat_eps):
                        if cs.box_thickness <= 0.0:
                            raise RuntimeError(
                                "Flat selection detected. Increase Thickness or use a non-flat selection"
                            )
                        world_points = _extrude_points_along_normal(world_points, normal, cs.box_thickness)
                        auto_thickened = True

            stats = _append_collider_hull_to_object(
                target_obj,
                world_points,
                merge_distance=cs.merge_distance,
                recalc_normals=bool(cs.recalc_normals),
            )
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        mode_name = {
            "SELECTION_HULL": "selection hull",
            "ISOLATED_VERTS_HULL": "isolated verts hull",
            "SELECTION_BOX": "selection box",
            "OBJECT_BOUNDS": "object bounds",
        }.get(self.build_mode, self.build_mode.lower())

        extras = []
        if auto_thickened:
            extras.append(f"auto-thickness {cs.box_thickness:g}")
        extra_suffix = "" if not extras else f" ({', '.join(extras)})"
        self.report(
            {"INFO"},
            (
                f"Built {mode_name} collider in {target_obj.name}: "
                f"+{stats['verts_added']} verts, +{stats['faces_added']} faces{extra_suffix}"
            ),
        )
        return {"FINISHED"}


# ------------------------------------------------------------------------
#  Texture Replace (.paa/.rvmat) + Replace from DB via A3OB
# ------------------------------------------------------------------------

_ALLOWED_DB_EXTS = {".paa", ".rvmat"}
_TEXTURE_SUFFIX_RE = re.compile(
    r"([_-])(co|ca|as|nohq|no|n|smdi|spec|det|detail|em|ao|rough|metal|mask)$",
    re.IGNORECASE,
)
def _norm_path(p: str) -> str:
    return (p or "").replace("/", "\\")

def _basename_no_ext(name_or_path: str) -> str:
    s = (name_or_path or "").replace("/", "\\").strip()
    s = s.split("\\")[-1]
    s = os.path.splitext(s)[0]
    return s

def _unique_ci(values):
    out = []
    seen = set()
    for v in values:
        s = (v or "").strip()
        if not s:
            continue
        key = s.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out

def _expand_basename_variants(base: str):
    base = _basename_no_ext(base)
    if not base:
        return []

    variants = [base]

    no_dot_num = re.sub(r"\.\d{3,}$", "", base)
    if no_dot_num != base:
        variants.append(no_dot_num)

    no_sep_num = re.sub(r"[_-]\d{2,4}$", "", no_dot_num)
    if no_sep_num != no_dot_num:
        variants.append(no_sep_num)

    for v in list(variants):
        stripped = _TEXTURE_SUFFIX_RE.sub("", v)
        if stripped and stripped != v:
            variants.append(stripped)

    for v in list(variants):
        if " " in v:
            variants.append(v.replace(" ", "_"))
            variants.append(v.replace(" ", "-"))

    return _unique_ci(variants)

def _build_material_candidates(mat: bpy.types.Material):
    candidates = [_basename_no_ext(mat.name)]

    if mat.use_nodes and mat.node_tree:
        for node in mat.node_tree.nodes:
            if node.type != "TEX_IMAGE" or not getattr(node, "image", None):
                continue
            img = node.image
            fp = getattr(img, "filepath", "") or ""
            if fp.strip():
                candidates.append(_basename_no_ext(fp))
            candidates.append(_basename_no_ext(img.name))

    expanded = []
    for c in _unique_ci(candidates):
        expanded.extend(_expand_basename_variants(c))
    return _unique_ci(expanded)

def _pick_best_db_match(candidates, db_map):
    best = None
    for base in candidates:
        key = base.lower()
        paa_path = db_map.get(f"{key}.paa")
        rvmat_path = db_map.get(f"{key}.rvmat")
        score = int(bool(paa_path)) + int(bool(rvmat_path))
        if score == 0:
            continue
        if best is None or score > best["score"]:
            best = {
                "base": base,
                "paa": paa_path,
                "rvmat": rvmat_path,
                "score": score,
            }
            if score == 2:
                break
    return best

def _walk_folder_build_db(folder_abs: str):
    if not os.path.isdir(folder_abs):
        raise RuntimeError(f"Folder not found: {folder_abs}")

    folder_abs = os.path.normpath(folder_abs)
    root_name = os.path.basename(folder_abs.rstrip("\\/")) or folder_abs

    buckets = {}
    for root, _, files in os.walk(folder_abs):
        for fn in files:
            full = os.path.join(root, fn)
            ext = os.path.splitext(full)[1].lower()
            if ext not in _ALLOWED_DB_EXTS:
                continue
            base = os.path.basename(full)
            key = base.lower()
            buckets.setdefault(key, set()).add(os.path.normpath(full))

    entries = []
    for key, pathset in buckets.items():
        uniq = sorted(pathset)
        chosen = uniq[0]
        rel = os.path.relpath(chosen, folder_abs)
        entries.append({
            "basename": os.path.basename(chosen),
            "abs_path": _norm_path(chosen),
            "rel_path": _norm_path(os.path.join(root_name, rel)),
            "is_problem": (len(uniq) > 1),
            "dup_count": len(uniq),
        })

    entries.sort(key=lambda d: (d["basename"].lower(), d["rel_path"].lower()))
    return entries

def _collect_object_image_materials(obj, out_collection):
    out_collection.clear()
    if not obj or obj.type != "MESH":
        return 0

    mats_done = set()
    count = 0
    for slot in obj.material_slots:
        mat = slot.material
        if not mat or mat in mats_done:
            continue
        mats_done.add(mat)

        if not mat.use_nodes or not mat.node_tree:
            continue

        images = []
        for node in mat.node_tree.nodes:
            if node.type == "TEX_IMAGE" and getattr(node, "image", None):
                images.append(node.image.name)

        if images:
            it = out_collection.add()
            it.mat_name = mat.name
            it.images_csv = ", ".join(sorted(set(images), key=lambda x: x.lower()))
            count += 1
    return count

def _build_db_map(settings):
    db_map = {}
    dup_names = set()
    for it in settings.db_items:
        k = (it.basename or "").lower().strip()
        if not k:
            continue
        if it.is_problem:
            dup_names.add(k)
        db_map[k] = it.abs_path
    return db_map, dup_names

def _iter_descendants(root_obj):
    stack = list(root_obj.children)
    while stack:
        obj = stack.pop()
        yield obj
        stack.extend(obj.children)

def _obj_depth(obj):
    d = 0
    p = obj.parent
    while p is not None:
        d += 1
        p = p.parent
    return d

_HELPER_OBJ_PREFIXES = (
    "sector",
    "sectors",
    "selector",
    "selectors",
    "hierarchy",
    "hierarhy",
    "hierarrhy",
    "hierrarhy",
)

_ROOT_COLLECTION_NAME = "Collection"
_FIX_TARGET_COLLECTION_BASENAME = "NH_Fix_Result"

def _is_helper_object_name(name: str) -> bool:
    n = (name or "").strip().lower()
    return n.startswith(_HELPER_OBJ_PREFIXES) or n.startswith("hier")

def _link_object_to_collection(obj, collection):
    if obj is None or collection is None:
        return
    if not _collection_directly_contains_object(collection, obj):
        collection.objects.link(obj)

def _collection_directly_contains_object(collection, obj):
    if collection is None or obj is None:
        return False
    try:
        obj_ptr = obj.as_pointer()
    except Exception:
        obj_ptr = None
    for item in getattr(collection, "objects", []):
        if item == obj:
            return True
        if obj_ptr is not None:
            try:
                if item.as_pointer() == obj_ptr:
                    return True
            except Exception:
                pass
    return False

def _same_id_data(left, right):
    if left is None or right is None:
        return False
    if left == right:
        return True
    try:
        return left.as_pointer() == right.as_pointer()
    except Exception:
        return False

def _unlink_object_from_collection_tree(obj, root_collection, keep_collection=None):
    if obj is None or root_collection is None:
        return 0

    removed = 0
    for col in _iter_collection_tree(root_collection):
        if _same_id_data(col, keep_collection):
            continue
        if not _collection_directly_contains_object(col, obj):
            continue
        try:
            col.objects.unlink(obj)
            removed += 1
        except Exception:
            pass
    return removed

def _direct_object_collection_names_under_root(root_collection, obj):
    if root_collection is None or obj is None:
        return []
    names = []
    for col in _iter_collection_tree(root_collection):
        if _collection_directly_contains_object(col, obj):
            names.append(getattr(col, "name", "") or "<unnamed>")
    return names

def _move_object_to_collection(obj, target_collection, unlink_roots=None):
    if obj is None or target_collection is None:
        return
    _link_object_to_collection(obj, target_collection)

    unlink_cols = []
    seen = set()
    unlink_root_list = ()

    def _add_unlink_col(col):
        if col is None:
            return
        try:
            ptr = col.as_pointer()
        except Exception:
            ptr = id(col)
        if ptr in seen:
            return
        seen.add(ptr)
        unlink_cols.append(col)

    for col in list(getattr(obj, "users_collection", [])):
        _add_unlink_col(col)

    if unlink_roots is not None:
        unlink_root_list = unlink_roots if isinstance(unlink_roots, (tuple, list, set)) else (unlink_roots,)
        for root in unlink_root_list:
            if root is None:
                continue
            for col in _iter_collection_tree(root):
                if _collection_directly_contains_object(col, obj):
                    _add_unlink_col(col)

    try:
        target_ptr = target_collection.as_pointer()
    except Exception:
        target_ptr = None

    for col in unlink_cols:
        same_as_target = (col == target_collection)
        if not same_as_target and target_ptr is not None:
            try:
                same_as_target = (col.as_pointer() == target_ptr)
            except Exception:
                same_as_target = False
        if same_as_target:
            continue
        try:
            col.objects.unlink(obj)
        except Exception:
            pass

    for root in unlink_root_list:
        _unlink_object_from_collection_tree(obj, root, keep_collection=target_collection)

    if not _collection_directly_contains_object(target_collection, obj):
        _link_object_to_collection(obj, target_collection)

def _is_export_helper_empty_name(name: str) -> bool:
    n = (name or "").strip().lower()
    return n == "visuals" or n.endswith("_a.p3d")

def _scene_fix_collection_name(scene):
    scene_name = (getattr(scene, "name", "") or "").strip()
    if not scene_name:
        return _FIX_TARGET_COLLECTION_BASENAME
    safe = re.sub(r"[\\/:*?\"<>|]+", "_", scene_name)
    return f"{_FIX_TARGET_COLLECTION_BASENAME}_{safe}"

def _ensure_target_collection(context, mesh_obj):
    scene_root = context.scene.collection
    target_name = _scene_fix_collection_name(context.scene)

    target = scene_root.children.get(target_name)
    if target is None:
        target = bpy.data.collections.new(target_name)
        scene_root.children.link(target)
    return target

def _ensure_default_scene_collection(context):
    scene_root = getattr(getattr(context, "scene", None), "collection", None)
    if scene_root is None:
        return None

    target = scene_root.children.get(_ROOT_COLLECTION_NAME)
    if target is None:
        target = bpy.data.collections.new(_ROOT_COLLECTION_NAME)
        scene_root.children.link(target)
    return target

def _sanitize_repair_p3d_collection_name(value: str) -> str:
    raw = os.path.basename((value or "").replace("\\", "/")).strip()
    raw = _strip_blender_numeric_suffix(raw)
    if raw.lower().endswith(".blend"):
        raw = raw[:-6]
    raw = _INVALID_FILENAME_CHARS_RE.sub("_", raw)
    raw = re.sub(r"\s+", " ", raw).strip(" .")
    if not raw:
        return ""
    if not raw.lower().endswith(".p3d"):
        raw += ".p3d"
    return raw

def _is_repair_generic_collection_name(name: str) -> bool:
    logical = _logical_collection_name(_strip_blender_numeric_suffix(name or ""))
    if not logical:
        return True
    generic_names = {
        _logical_collection_name(_ROOT_COLLECTION_NAME),
        _logical_collection_name(_VISUALS_COLLECTION_NAME),
        _logical_collection_name(_COLLIDER_COLLECTION_NAME),
        _logical_collection_name(_MEMORY_COLLECTION_NAME),
        _logical_collection_name(_MISC_COLLECTION_NAME),
        "geometry",
        "memory",
    }
    return logical in generic_names or _is_helper_object_name(logical)

def _is_repair_lod_like_object_name(name: str) -> bool:
    logical = _logical_collection_name(_strip_blender_numeric_suffix(name or ""))
    if not logical:
        return True
    if logical.startswith("resolution"):
        return True
    known = {_logical_collection_name(value) for value in _COLLIDER_KNOWN_LOD_NAMES.values()}
    known.add(_logical_collection_name(_MemoryLodManager.OBJECT_NAME))
    return logical in known

def _repair_scope_source_path(scope_objs):
    for obj in scope_objs or []:
        if obj is None:
            continue
        try:
            src = obj.get(_IE_SOURCE_PATH_KEY)
        except Exception:
            src = ""
        if isinstance(src, str) and src.strip():
            return _norm_path(bpy.path.abspath(src))

        for col in getattr(obj, "users_collection", []):
            try:
                src = col.get(_IE_SOURCE_PATH_KEY)
            except Exception:
                src = ""
            if isinstance(src, str) and src.strip():
                return _norm_path(bpy.path.abspath(src))
    return ""

def _repair_top_collection_candidate(context, scope_objs):
    scene_root = getattr(getattr(context, "scene", None), "collection", None)
    if scene_root is None:
        return ""

    for obj in scope_objs or []:
        if obj is None:
            continue
        for col in getattr(obj, "users_collection", []):
            try:
                path = _find_collection_path(scene_root, col.as_pointer())
            except Exception:
                path = None
            if not path or len(path) < 2:
                continue

            candidate = None
            if _logical_collection_name(getattr(path[1], "name", "")) == _logical_collection_name(_ROOT_COLLECTION_NAME):
                if len(path) >= 3:
                    candidate = path[2]
            else:
                candidate = path[1]
            if candidate is None:
                continue

            name = getattr(candidate, "name", "") or ""
            if _looks_like_p3d_collection_name(name) or not _is_repair_generic_collection_name(name):
                return name
    return ""

def _derive_repair_p3d_collection_name(context, target_obj, scope_objs):
    source_path = _repair_scope_source_path(scope_objs)
    from_source = _sanitize_repair_p3d_collection_name(source_path)
    if from_source:
        return from_source, source_path

    from_collection = _sanitize_repair_p3d_collection_name(_repair_top_collection_candidate(context, scope_objs))
    if from_collection:
        return from_collection, ""

    blend_path = getattr(bpy.data, "filepath", "") or ""
    from_blend = _sanitize_repair_p3d_collection_name(blend_path)
    if from_blend and _normalize_p3d_lookup_key(from_blend) not in {"untitled", "startup"}:
        return from_blend, ""

    obj_name = getattr(target_obj, "name", "") or ""
    if obj_name and not _is_repair_lod_like_object_name(obj_name):
        from_object = _sanitize_repair_p3d_collection_name(obj_name)
        if from_object:
            return from_object, ""

    return "fixed_model.p3d", ""

def _ensure_repair_p3d_root_collection(context, target_obj, scope_objs):
    existing_root = _find_p3d_root_collection_for_object(context, target_obj)
    if existing_root is not None:
        return existing_root, _resolve_collection_source_path(existing_root)

    root_name, source_path = _derive_repair_p3d_collection_name(context, target_obj, scope_objs)
    parent = _ensure_default_scene_collection(context)
    if parent is None:
        raise RuntimeError("Scene collection is not available")

    target = parent.children.get(root_name)
    if target is None:
        target = bpy.data.collections.new(root_name)
        parent.children.link(target)

    if source_path:
        _set_ie_source_path_tag(target, source_path)
    return target, source_path

def _set_resolution0_a3ob_lod_props(obj):
    if obj is None or obj.type != "MESH":
        raise RuntimeError("Repair result must be a mesh")
    if not hasattr(obj, "a3ob_properties_object"):
        raise RuntimeError("A3OB object properties are missing. Enable Arma 3 Object Builder first.")

    props = obj.a3ob_properties_object
    props.lod = "0"
    props.resolution = 0
    props.resolution_float = 0.0
    props.is_a3_lod = True
    _remove_a3ob_named_property(props, "autocenter")

    try:
        lod_name = props.get_name()
    except Exception:
        lod_name = "Resolution 0"
    lod_name = lod_name or "Resolution 0"
    obj.name = lod_name
    if obj.data is not None:
        obj.data.name = lod_name
    return lod_name

def _remove_empty_subcollections(collection):
    if collection is None:
        return 0

    removed = 0
    for child in list(collection.children):
        removed += _remove_empty_subcollections(child)
        if len(child.objects) > 0 or len(child.children) > 0:
            continue
        try:
            collection.children.unlink(child)
        except Exception:
            continue
        if len(child.users) == 0:
            try:
                bpy.data.collections.remove(child)
            except Exception:
                pass
        removed += 1
    return removed

def _collect_fix_scope(context, target_obj):
    ordered = []
    seen = set()

    def _push(o):
        if o is None:
            return
        key = o.name
        if key in seen:
            return
        seen.add(key)
        ordered.append(o)

    selected = list(context.selected_objects)
    if selected:
        for o in selected:
            _push(o)
            for ch in _iter_descendants(o):
                _push(ch)
        return ordered, "selected"

    root = target_obj
    while root is not None and root.parent is not None:
        root = root.parent
    if root is None:
        return [target_obj], "target-only"

    _push(root)
    for ch in _iter_descendants(root):
        _push(ch)
    if root == target_obj:
        return ordered, "target-descendants"
    return ordered, "root-branch"

def _collect_repair_a3ob_scope(context, target_obj):
    selected = [obj for obj in getattr(context, "selected_objects", []) if obj is not None]
    if len(selected) > 1:
        return _collect_fix_scope(context, target_obj)

    p3d_root = _find_p3d_root_collection_for_object(context, target_obj)
    if p3d_root is not None:
        objects = _collect_collection_objects_recursive(p3d_root)
        if objects:
            return objects, ".p3d root collection"

    scene_root = getattr(getattr(context, "scene", None), "collection", None)
    for col in getattr(target_obj, "users_collection", []):
        if scene_root is not None:
            try:
                path = _find_collection_path(scene_root, col.as_pointer())
            except Exception:
                path = None
            if path and len(path) >= 2:
                candidate = col
                if (
                    _logical_collection_name(getattr(path[1], "name", ""))
                    == _logical_collection_name(_ROOT_COLLECTION_NAME)
                    and len(path) >= 3
                ):
                    candidate = path[2]
                elif len(path) >= 2:
                    candidate = path[1]

                objects = _collect_collection_objects_recursive(candidate)
                if objects:
                    return objects, f"collection: {candidate.name}"

        objects = _collect_collection_objects_recursive(col)
        if objects:
            return objects, f"collection: {col.name}"

    return _collect_fix_scope(context, target_obj)

def _pick_primary_mesh(scope_objs, preferred_obj):
    meshes = [o for o in scope_objs if o.type == "MESH" and o.data is not None]
    if not meshes:
        return None, "none"

    if preferred_obj in meshes and not _is_helper_object_name(preferred_obj.name):
        return preferred_obj, "preferred"

    non_helper = [o for o in meshes if not _is_helper_object_name(o.name)]
    if non_helper:
        best = max(non_helper, key=lambda o: len(o.data.polygons) if o.data else 0)
        return best, "largest-non-helper"

    best = max(meshes, key=lambda o: len(o.data.polygons) if o.data else 0)
    return best, "largest-mesh"

def _largest_mesh(objs):
    meshes = [o for o in objs if o is not None and o.type == "MESH" and o.data is not None]
    if not meshes:
        return None
    return max(meshes, key=lambda o: len(o.data.polygons) if o.data else 0)

def _meshes_in_branch(seed_obj):
    if seed_obj is None:
        return []

    root = seed_obj
    while root.parent is not None:
        root = root.parent

    branch = [root]
    branch.extend(_iter_descendants(root))
    return [o for o in branch if o.type == "MESH" and o.data is not None]

def _resolve_fix_target_object(context, picked_obj):
    selected = list(context.selected_objects)

    if selected:
        active = context.view_layer.objects.active
        if active is not None:
            if active.type == "MESH":
                return active, "active"
            branch_meshes = _meshes_in_branch(active)
            mesh = _largest_mesh(branch_meshes)
            if mesh is not None:
                return mesh, "active-branch"

        selected_mesh = _largest_mesh(selected)
        if selected_mesh is not None:
            return selected_mesh, "selected"

        selected_branch_meshes = []
        for o in selected:
            selected_branch_meshes.extend(_meshes_in_branch(o))
        mesh = _largest_mesh(selected_branch_meshes)
        if mesh is not None:
            return mesh, "selected-branch"

    active = context.view_layer.objects.active
    if active is not None:
        if active.type == "MESH":
            return active, "active"
        branch_meshes = _meshes_in_branch(active)
        mesh = _largest_mesh(branch_meshes)
        if mesh is not None:
            return mesh, "active-branch"

    if picked_obj is not None:
        if picked_obj.type == "MESH":
            return picked_obj, "picked"
        branch_meshes = _meshes_in_branch(picked_obj)
        mesh = _largest_mesh(branch_meshes)
        if mesh is not None:
            return mesh, "picked-branch"

    return _resolve_tex_target_object(context, picked_obj)

def _collect_collection_objects_deep(collection):
    if collection is None:
        return []

    out = []
    seen_cols = set()
    seen_objs = set()
    stack = [collection]
    while stack:
        col = stack.pop()
        if col is None:
            continue
        col_key = col.as_pointer()
        if col_key in seen_cols:
            continue
        seen_cols.add(col_key)

        for obj in col.objects:
            obj_key = obj.as_pointer()
            if obj_key in seen_objs:
                continue
            seen_objs.add(obj_key)
            out.append(obj)
        stack.extend(col.children)
    return out

def _collect_collections_deep(collection):
    if collection is None:
        return []

    out = []
    seen = set()
    stack = [collection]
    while stack:
        col = stack.pop()
        if col is None:
            continue
        key = col.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        out.append(col)
        stack.extend(col.children)
    return out

def _pick_random_scene_fix_mesh(context):
    root_col = context.scene.collection.children.get(_ROOT_COLLECTION_NAME)
    if root_col is not None:
        root_col_meshes = [
            o for o in _collect_collection_objects_deep(root_col)
            if o.type == "MESH" and o.data is not None and len(o.data.polygons) > 0
        ]
        if root_col_meshes:
            non_helper = [o for o in root_col_meshes if not _is_helper_object_name(o.name)]
            if non_helper:
                return random.choice(non_helper), "collection-random-non-helper"
            return random.choice(root_col_meshes), "collection-random"

    scene_meshes = [
        o for o in context.scene.objects
        if o.type == "MESH" and o.data is not None and len(o.data.polygons) > 0
    ]
    if not scene_meshes:
        return None, "none"

    non_helper = [o for o in scene_meshes if not _is_helper_object_name(o.name)]
    if non_helper:
        return random.choice(non_helper), "scene-random-non-helper"
    return random.choice(scene_meshes), "scene-random"

def _resolve_tex_target_object(context, picked_obj):
    if picked_obj is not None and picked_obj.type == "MESH":
        return picked_obj, "picked"

    active = context.view_layer.objects.active
    if active is not None and active.type == "MESH":
        return active, "active"

    selected_meshes = [o for o in context.selected_objects if o.type == "MESH"]
    if len(selected_meshes) == 1:
        return selected_meshes[0], "selected"

    scene_meshes = [o for o in context.scene.objects if o.type == "MESH"]
    if not scene_meshes:
        return None, "none"
    if len(scene_meshes) == 1:
        return scene_meshes[0], "scene-single"

    best = max(scene_meshes, key=lambda o: len(o.data.polygons) if o.data else 0)
    return best, "scene-largest"

def _ensure_flat_collection_mesh(context, mesh_obj):
    target_collection = _ensure_target_collection(context, mesh_obj)
    mesh_world = mesh_obj.matrix_world.copy()

    _move_object_to_collection(mesh_obj, target_collection)
    mesh_obj.parent = None
    mesh_obj.matrix_world = mesh_world
    return target_collection, mesh_obj

def _purge_collection_tree(collection):
    deleted_objects = 0
    deleted_collections = 0

    for ch_idx, ch in enumerate(list(collection.children), start=1):
        child_deleted_objects, child_deleted_collections = _purge_collection_tree(ch)
        deleted_objects += child_deleted_objects
        deleted_collections += child_deleted_collections

        try:
            collection.children.unlink(ch)
        except Exception:
            pass
        else:
            if len(ch.users) == 0:
                try:
                    bpy.data.collections.remove(ch)
                except Exception:
                    pass
            deleted_collections += 1
        if ch_idx % 25 == 0:
            _ui_yield()

    for obj_idx, obj in enumerate(list(collection.objects), start=1):
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            continue
        deleted_objects += 1
        if obj_idx % 50 == 0:
            _ui_yield()

    return deleted_objects, deleted_collections

def _cleanup_target_collection_keep_mesh(target_collection, keep_obj):
    deleted_objects = 0
    deleted_collections = 0

    for obj_idx, obj in enumerate(list(target_collection.objects), start=1):
        if obj == keep_obj:
            continue
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            continue
        deleted_objects += 1
        if obj_idx % 50 == 0:
            _ui_yield()

    for ch_idx, ch in enumerate(list(target_collection.children), start=1):
        child_deleted_objects, child_deleted_collections = _purge_collection_tree(ch)
        deleted_objects += child_deleted_objects
        deleted_collections += child_deleted_collections

        try:
            target_collection.children.unlink(ch)
        except Exception:
            continue

        if len(ch.users) == 0:
            try:
                bpy.data.collections.remove(ch)
            except Exception:
                pass
        deleted_collections += 1
        if ch_idx % 25 == 0:
            _ui_yield()

    return deleted_objects, deleted_collections

def _unlink_collection_from_all_parents(col):
    if col is None:
        return
    for scene in _iter_safe_scenes():
        try:
            if scene.collection.children.get(col.name) is not None:
                scene.collection.children.unlink(col)
        except Exception:
            pass
    for parent in list(bpy.data.collections):
        if parent == col:
            continue
        try:
            if parent.children.get(col.name) is not None:
                parent.children.unlink(col)
        except Exception:
            pass

def _unlink_collection_from_scene_parents(scene, col):
    if scene is None or col is None:
        return
    scene_cols = _collect_collections_deep(scene.collection)
    for parent in scene_cols:
        if parent == col:
            continue
        try:
            if any(ch == col for ch in parent.children):
                parent.children.unlink(col)
        except Exception:
            pass

def _force_remove_object(obj, keep_obj=None, allowed_col_ptrs=None):
    if obj is None or obj == keep_obj:
        return False

    cols = list(getattr(obj, "users_collection", []))
    if allowed_col_ptrs is not None:
        for col in cols:
            if col.as_pointer() not in allowed_col_ptrs:
                # Object is shared with another scene/collection tree. Keep it safe.
                return False

    try:
        if keep_obj is not None and keep_obj.parent == obj:
            keep_obj.parent = None
        for ch in list(obj.children):
            if ch == keep_obj:
                ch.parent = None
        obj.parent = None
    except Exception:
        pass

    for col in cols:
        if allowed_col_ptrs is not None and col.as_pointer() not in allowed_col_ptrs:
            continue
        try:
            col.objects.unlink(obj)
        except Exception:
            pass

    try:
        bpy.data.objects.remove(obj, do_unlink=True)
        return True
    except Exception:
        return False

def _remove_helper_named_objects(scene=None, keep_obj=None, max_passes=8):
    if scene is None:
        scene = bpy.context.scene if bpy.context is not None else None
    if scene is None:
        return 0, 0, []

    scene_cols = _collect_collections_deep(scene.collection)
    scene_col_ptrs = {c.as_pointer() for c in scene_cols if c is not None}

    deleted_objects = 0
    deleted_collections = 0

    for pass_idx in range(max_passes):
        deleted_pass = 0

        helpers = [
            o for o in scene.objects
            if o is not None and o != keep_obj and _is_helper_object_name(o.name)
        ]
        helpers.sort(key=_obj_depth, reverse=True)
        for obj_idx, helper in enumerate(helpers, start=1):
            live = helper
            if live is None or live == keep_obj:
                continue
            try:
                live_name = live.name
            except ReferenceError:
                continue
            if not _is_helper_object_name(live_name):
                continue
            if _force_remove_object(live, keep_obj=keep_obj, allowed_col_ptrs=scene_col_ptrs):
                deleted_objects += 1
                deleted_pass += 1
            if obj_idx % 50 == 0:
                _ui_yield()

        helper_cols = [
            c for c in scene_cols
            if c is not None and c != scene.collection and _is_helper_object_name(c.name)
        ]
        # Remove deeper sub-collections first.
        helper_cols.sort(key=lambda c: len(getattr(c, "children_recursive", [])), reverse=True)
        for col_idx, col in enumerate(helper_cols, start=1):
            live_col = col
            if live_col is None:
                continue
            try:
                live_col_name = live_col.name
            except ReferenceError:
                continue
            if not _is_helper_object_name(live_col_name):
                continue

            for obj in list(live_col.objects):
                if _force_remove_object(obj, keep_obj=keep_obj, allowed_col_ptrs=scene_col_ptrs):
                    deleted_objects += 1
                    deleted_pass += 1

            for ch in list(live_col.children):
                try:
                    live_col.children.unlink(ch)
                except Exception:
                    pass
                if len(ch.users) == 0:
                    try:
                        bpy.data.collections.remove(ch)
                    except Exception:
                        pass

            _unlink_collection_from_scene_parents(scene, live_col)
            if len(live_col.users) == 0:
                try:
                    bpy.data.collections.remove(live_col)
                    deleted_collections += 1
                    deleted_pass += 1
                except Exception:
                    pass
            if col_idx % 25 == 0:
                _ui_yield()

        if deleted_pass == 0:
            break
        if pass_idx % 2 == 1:
            _ui_yield()

    remaining_helpers = [
        o.name for o in scene.objects
        if o is not None and o != keep_obj and _is_helper_object_name(o.name)
    ]
    return deleted_objects, deleted_collections, remaining_helpers

def _ui_yield():
    try:
        bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=1)
    except Exception:
        pass

def _ensure_object_visible_for_ops(obj):
    if obj is None:
        return
    try:
        obj.hide_set(False)
    except Exception:
        pass
    try:
        obj.hide_viewport = False
    except Exception:
        pass

def _join_meshes_in_batches(context, anchor_obj, mesh_names, batch_size=24):
    if anchor_obj is None or anchor_obj.type != "MESH" or anchor_obj.data is None:
        raise RuntimeError("Join anchor must be a mesh object")

    batch_size = int(batch_size)
    batch_limit = None if batch_size <= 1 else max(2, batch_size)
    anchor_name = anchor_obj.name
    pending = [n for n in mesh_names if n and n != anchor_name]
    joined_count = 0
    join_passes = 0

    while pending:
        anchor = bpy.data.objects.get(anchor_name)
        if anchor is None or anchor.type != "MESH" or anchor.data is None:
            raise RuntimeError("Join failed: anchor mesh became unavailable")

        batch_names = []
        next_pending = []
        for nm in pending:
            live = bpy.data.objects.get(nm)
            if live is None or live == anchor:
                continue
            if live.type != "MESH" or live.data is None or len(live.data.polygons) == 0:
                continue
            if batch_limit is None or len(batch_names) < batch_limit:
                batch_names.append(nm)
            else:
                next_pending.append(nm)
        pending = next_pending

        if not batch_names:
            break

        bpy.ops.object.select_all(action="DESELECT")
        _ensure_object_visible_for_ops(anchor)
        anchor.select_set(True)
        selected_for_join = [anchor]

        for nm in batch_names:
            live = bpy.data.objects.get(nm)
            if live is None or live == anchor:
                continue
            _ensure_object_visible_for_ops(live)
            live.select_set(True)
            selected_for_join.append(live)

        if len(selected_for_join) <= 1:
            continue

        context.view_layer.objects.active = anchor
        bpy.ops.object.join()
        joined_count += len(selected_for_join) - 1
        join_passes += 1

        active_after = context.view_layer.objects.active
        if active_after is not None and active_after.type == "MESH":
            anchor_name = active_after.name

        _ui_yield()

    merged_obj = bpy.data.objects.get(anchor_name)
    if merged_obj is None or merged_obj.type != "MESH":
        raise RuntimeError("Join failed: no merged mesh after staged join")
    return merged_obj, joined_count, join_passes

def _center_object_bbox_to_world_origin(obj):
    if obj is None:
        return False, Vector((0.0, 0.0, 0.0))

    bbox_world = []
    try:
        for corner in obj.bound_box:
            bbox_world.append(obj.matrix_world @ Vector(corner))
    except Exception:
        bbox_world = []

    if bbox_world:
        center = Vector((0.0, 0.0, 0.0))
        for p in bbox_world:
            center += p
        center /= len(bbox_world)
    else:
        center = obj.matrix_world.translation.copy()

    if center.length <= 1e-7:
        return False, center

    mw = obj.matrix_world.copy()
    mw.translation = mw.translation - center
    obj.matrix_world = mw
    return True, center

# ---------- A3OB material setter (FIXED) ----------

def _find_a3ob_material_pg(mat: bpy.types.Material):
    if mat is None:
        return None
    for attr in dir(mat):
        if not attr.startswith("a3ob"):
            continue
        try:
            pg = getattr(mat, attr)
        except Exception:
            continue
        if hasattr(pg, "bl_rna"):
            return pg
    return None

def _a3ob_props(mat_pg):
    props = []
    for p in mat_pg.bl_rna.properties:
        if p.identifier == "rna_type":
            continue
        # p.type is Blender RNA type label (STRING, ENUM, ...)
        props.append({
            "ui": p.name,
            "id": p.identifier,
            "type": p.type,
        })
    return props

def _pick_enum_id(props, keywords):
    for pr in props:
        if pr["type"] != "ENUM":
            continue
        ui_l = pr["ui"].lower()
        if all(k in ui_l for k in keywords):
            return pr["id"]
    return None

def _pick_string_id(props, keywords):
    for pr in props:
        if pr["type"] != "STRING":
            continue
        ui_l = pr["ui"].lower()
        if all(k in ui_l for k in keywords):
            return pr["id"]
    return None

def _get_a3ob_material_paths(mat: bpy.types.Material):
    pg = _find_a3ob_material_pg(mat)
    if pg is None:
        return None, None

    props = _a3ob_props(pg)
    paa_id = (
        _pick_string_id(props, ["paa"])
        or _pick_string_id(props, ["texture", "paa"])
        or _pick_string_id(props, ["texture"])
        or _pick_string_id(props, ["file"])
        or _pick_string_id(props, ["path"])
    )
    rvmat_id = (
        _pick_string_id(props, ["rvmat"])
        or _pick_string_id(props, ["rvm"])
        or _pick_string_id(props, ["material", "path"])
        or _pick_string_id(props, ["material"])
    )

    paa_path = ""
    rvmat_path = ""
    if paa_id and hasattr(pg, paa_id):
        try:
            paa_path = _norm_path(str(getattr(pg, paa_id, "") or "").strip())
        except Exception:
            paa_path = ""
    if rvmat_id and hasattr(pg, rvmat_id):
        try:
            rvmat_path = _norm_path(str(getattr(pg, rvmat_id, "") or "").strip())
        except Exception:
            rvmat_path = ""

    return paa_path or None, rvmat_path or None

def _get_material_first_image_path(mat: bpy.types.Material):
    if mat is None or not getattr(mat, "use_nodes", False) or not getattr(mat, "node_tree", None):
        return None

    for node in mat.node_tree.nodes:
        if node.type != "TEX_IMAGE":
            continue
        image = getattr(node, "image", None)
        if image is None:
            continue

        raw_path = getattr(image, "filepath_raw", "") or getattr(image, "filepath", "")
        if raw_path:
            try:
                return _norm_path(bpy.path.abspath(raw_path))
            except Exception:
                return _norm_path(str(raw_path))

        image_name = _basename_no_ext(getattr(image, "name", ""))
        if image_name:
            return image_name

    return None

def _derive_roadway_material_name(src_mat: bpy.types.Material):
    if src_mat is None:
        return "RoadwayMaterial"

    paa_path, rvmat_path = _get_a3ob_material_paths(src_mat)
    candidates = [
        paa_path,
        rvmat_path,
        _get_material_first_image_path(src_mat),
        getattr(src_mat, "name", ""),
    ]

    for candidate in candidates:
        base = _basename_no_ext(candidate)
        if base:
            return base

    return "RoadwayMaterial"

def _find_material_slot_index_by_name_ci(materials, material_name):
    target_name = (material_name or "").strip().lower()
    if not target_name:
        return None

    for slot_idx, existing_mat in enumerate(materials):
        if existing_mat is None:
            continue
        if existing_mat.name.strip().lower() == target_name:
            return slot_idx
    return None

def _ensure_roadway_material(target_materials, src_mat: bpy.types.Material):
    material_name = _derive_roadway_material_name(src_mat)
    existing_index = _find_material_slot_index_by_name_ci(target_materials, material_name)
    if existing_index is not None:
        existing_mat = target_materials[existing_index]
        return existing_index, existing_mat.name

    if src_mat is not None:
        roadway_mat = src_mat.copy()
    else:
        roadway_mat = bpy.data.materials.new(name=material_name)

    roadway_mat.name = material_name

    paa_path, rvmat_path = _get_a3ob_material_paths(src_mat)
    try:
        if paa_path or rvmat_path:
            _set_a3ob_material_paths(roadway_mat, paa_path, rvmat_path)
    except Exception:
        pass

    target_materials.append(roadway_mat)
    return len(target_materials) - 1, roadway_mat.name

def _set_a3ob_material_paths(mat: bpy.types.Material, paa_abs: str | None, rvmat_abs: str | None):
    pg = _find_a3ob_material_pg(mat)
    if pg is None:
        raise RuntimeError("A3OB material property group not found")

    props = _a3ob_props(pg)

    # 1) Ensure source enum -> File (TEX)
    # UI name in your screenshot: "Texture Source"
    src_id = _pick_enum_id(props, ["texture", "source"]) or _pick_enum_id(props, ["source"])
    if src_id and hasattr(pg, src_id):
        try:
            setattr(pg, src_id, "TEX")
        except Exception:
            # ignore if enum differs; not fatal
            pass

    # 2) Find string fields for PAA and RVMAT
    # We try multiple keyword combinations to survive different A3OB versions
    paa_id = (
        _pick_string_id(props, ["paa"])
        or _pick_string_id(props, ["texture", "paa"])
        or _pick_string_id(props, ["texture"])
        or _pick_string_id(props, ["file"])
        or _pick_string_id(props, ["path"])
    )

    rvmat_id = (
        _pick_string_id(props, ["rvmat"])
        or _pick_string_id(props, ["rvm"])
        or _pick_string_id(props, ["material", "path"])
        or _pick_string_id(props, ["material"])
    )

    # Hard requirement: if we want to set a value, field must exist
    if paa_abs is not None:
        if not paa_id or not hasattr(pg, paa_id):
            raise RuntimeError("PAA path field not found in A3OB Material Properties")
        setattr(pg, paa_id, paa_abs)

    if rvmat_abs is not None:
        if not rvmat_id or not hasattr(pg, rvmat_id):
            raise RuntimeError("RVMAT path field not found in A3OB Material Properties")
        setattr(pg, rvmat_id, rvmat_abs)

def _iter_unique_materials_from_objects(objects):
    materials = []
    seen = set()
    for obj in objects or []:
        if obj is None or getattr(obj, "type", None) != "MESH":
            continue
        for slot in getattr(obj, "material_slots", []):
            mat = getattr(slot, "material", None)
            if mat is None:
                continue
            ptr = mat.as_pointer()
            if ptr in seen:
                continue
            seen.add(ptr)
            materials.append(mat)
    return materials

def _enable_preview_material_alpha(material: bpy.types.Material):
    try:
        material.blend_method = "HASHED"
    except Exception:
        pass

    try:
        material.shadow_method = "HASHED"
    except Exception:
        pass

def _apply_image_color_space(image, color_space: str):
    if image is None:
        return

    if color_space == "DATA":
        try:
            image.colorspace_settings.is_data = True
        except Exception:
            try:
                image.colorspace_settings.name = "Non-Color"
            except Exception:
                pass
    else:
        try:
            image.colorspace_settings.is_data = False
        except Exception:
            pass

def _has_image_alpha(image) -> bool:
    if image is None:
        return False

    try:
        if getattr(image, "alpha_mode", "NONE") != "NONE":
            return True
    except Exception:
        pass

    try:
        return int(getattr(image, "channels", 0) or 0) >= 4
    except Exception:
        return False

def _remove_image_if_unused(image):
    if image is None:
        return

    try:
        if image.users == 0:
            bpy.data.images.remove(image)
    except Exception:
        pass

def _find_existing_paa_preview_image(filepath: str, color_space: str):
    filepath = os.path.abspath(bpy.path.abspath(filepath)).lower()
    is_data = color_space == "DATA"

    for image in bpy.data.images:
        image_path = getattr(image, "filepath_raw", "") or getattr(image, "filepath", "")
        if not image_path:
            continue

        try:
            image_path = os.path.abspath(bpy.path.abspath(image_path)).lower()
        except Exception:
            continue

        if image_path != filepath:
            continue

        try:
            image_is_data = bool(image.colorspace_settings.is_data)
        except Exception:
            image_is_data = False

        if image_is_data == is_data:
            return image

    return None

def _create_blender_image_from_paa_texture(filepath: str, tex, color_space: str):
    paa_ns = _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.data_paa",
            "Arma3ObjectBuilder.io.data_paa",
        )
    )
    if paa_ns is None:
        return None

    paa_type = getattr(paa_ns, "PAA_Type", None)
    if paa_type is None:
        return None

    dxt1 = getattr(paa_type, "DXT1", None)
    dxt5 = getattr(paa_type, "DXT5", None)
    if tex.type not in (dxt1, dxt5):
        return None

    mip = tex.mips[0]
    mip.decompress(tex.type)
    swiztagg = tex.get_tagg("SWIZ")
    if swiztagg is not None:
        mip.swizzle(swiztagg.data)

    alpha = tex.type == dxt5
    img = bpy.data.images.new(
        os.path.basename(filepath),
        mip.width,
        mip.height,
        alpha=alpha,
        is_data=color_space == "DATA",
    )
    img.filepath_raw = filepath
    if alpha:
        img.alpha_mode = "PREMUL"
    else:
        img.alpha_mode = "NONE"

    _apply_image_color_space(img, color_space)

    img.pixels = [value for c in zip(*mip.data) for value in c]
    img.update()
    img.pack()
    return img

def _load_paa_image_with_original_a3ob(filepath: str, color_space: str = "SRGB", check_existing: bool = True):
    filepath = os.path.abspath(bpy.path.abspath(filepath))
    if check_existing:
        existing = _find_existing_paa_preview_image(filepath, color_space)
        if existing is not None:
            return existing, None

    paa_mod = _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.data_paa",
            "Arma3ObjectBuilder.io.data_paa",
        )
    )
    if paa_mod is None:
        return None, None

    try:
        with open(filepath, "rb") as file:
            tex = paa_mod.PAA_File.read(file)
    except Exception:
        return None, None

    return _create_blender_image_from_paa_texture(filepath, tex, color_space), tex

def _ensure_a3ob_import_paa_helpers():
    import_paa_mod = _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.import_paa",
            "Arma3ObjectBuilder.io.import_paa",
        )
    )
    if import_paa_mod is None:
        return None

    if not callable(getattr(import_paa_mod, "find_existing_image", None)):
        setattr(import_paa_mod, "find_existing_image", _find_existing_paa_preview_image)

    if not callable(getattr(import_paa_mod, "create_image_from_texture", None)):
        def _module_create_image_from_texture(filepath, tex, color_space):
            return _create_blender_image_from_paa_texture(filepath, tex, color_space)
        setattr(import_paa_mod, "create_image_from_texture", _module_create_image_from_texture)

    if not callable(getattr(import_paa_mod, "load_file", None)):
        def _module_load_file(filepath, color_space="SRGB", check_existing=True):
            return _load_paa_image_with_original_a3ob(filepath, color_space=color_space, check_existing=check_existing)
        setattr(import_paa_mod, "load_file", _module_load_file)

    return import_paa_mod

def _resolve_a3ob_texture_path(texture_path: str) -> str:
    raw = (texture_path or "").strip()
    if not raw:
        return ""

    import_p3d_mod = _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.import_p3d",
            "Arma3ObjectBuilder.io.import_p3d",
        )
    )
    resolver = getattr(import_p3d_mod, "resolve_texture_path", None) if import_p3d_mod is not None else None
    if callable(resolver):
        try:
            resolved = resolver(raw)
            if resolved:
                resolved = os.path.abspath(bpy.path.abspath(resolved))
                if os.path.isfile(resolved):
                    return _norm_path(resolved)
        except Exception:
            pass

    utils_mod = _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.utilities.generic",
            "Arma3ObjectBuilder.utilities.generic",
        )
    )
    restore_absolute = getattr(utils_mod, "restore_absolute", None) if utils_mod is not None else None

    candidates = []
    try:
        candidates.append(os.path.abspath(bpy.path.abspath(raw)))
    except Exception:
        pass

    if callable(restore_absolute):
        for extension in ("", ".paa"):
            try:
                candidate = restore_absolute(raw, extension)
            except TypeError:
                try:
                    candidate = restore_absolute(raw)
                except Exception:
                    candidate = ""
            except Exception:
                candidate = ""
            if candidate:
                candidates.append(candidate)

    if os.path.splitext(raw)[1] == "":
        try:
            candidates.append(os.path.abspath(bpy.path.abspath(raw + ".paa")))
        except Exception:
            pass

    checked = set()
    for candidate in candidates:
        if not candidate:
            continue
        try:
            candidate_abs = os.path.abspath(bpy.path.abspath(candidate))
        except Exception:
            continue
        key = os.path.normcase(candidate_abs)
        if key in checked:
            continue
        checked.add(key)
        if os.path.isfile(candidate_abs):
            return _norm_path(candidate_abs)

    return ""

def _paa_preview_cache_path(paa_abs_path: str) -> str:
    root, _ = os.path.splitext(paa_abs_path)
    return root + ".png"

def _save_image_as_png(image, filepath: str):
    folder = os.path.dirname(filepath)
    if folder:
        os.makedirs(folder, exist_ok=True)

    prev_filepath_raw = getattr(image, "filepath_raw", "")
    prev_filepath = getattr(image, "filepath", "")
    prev_file_format = getattr(image, "file_format", None)

    try:
        image.filepath_raw = filepath
        image.filepath = filepath
        if prev_file_format is not None:
            image.file_format = "PNG"
        image.save()
    finally:
        try:
            image.filepath_raw = prev_filepath_raw
        except Exception:
            pass
        try:
            image.filepath = prev_filepath
        except Exception:
            pass
        if prev_file_format is not None:
            try:
                image.file_format = prev_file_format
            except Exception:
                pass

def _load_external_image(filepath: str, color_space: str = "SRGB"):
    image = bpy.data.images.load(filepath, check_existing=True)
    _apply_image_color_space(image, color_space)
    return image

def _load_material_preview_image(texture_path: str, keep_converted_textures: bool, color_space: str = "SRGB"):
    resolved_path = _resolve_a3ob_texture_path(texture_path)
    if not resolved_path:
        return None, False, "", "missing", ""

    ext = os.path.splitext(resolved_path)[1].lower()
    if ext != ".paa":
        try:
            image = _load_external_image(resolved_path, color_space)
            return image, _has_image_alpha(image), resolved_path, "file", ""
        except Exception:
            return None, False, resolved_path, "missing", ""

    import_paa_mod = _import_first_available_module(
        (
            "bl_ext.user_default.Arma3ObjectBuilder.io.import_paa",
            "Arma3ObjectBuilder.io.import_paa",
        )
    )
    if import_paa_mod is None:
        import_paa_mod = _ensure_a3ob_import_paa_helpers()
    else:
        import_paa_mod = _ensure_a3ob_import_paa_helpers() or import_paa_mod
    if import_paa_mod is None:
        return None, False, resolved_path, "missing", ""

    load_file = getattr(import_paa_mod, "load_file", None)
    if not callable(load_file):
        def _fallback_load_file(filepath, color_space="SRGB", check_existing=True):
            return _load_paa_image_with_original_a3ob(filepath, color_space=color_space, check_existing=check_existing)
        load_file = _fallback_load_file

    cache_path = _paa_preview_cache_path(resolved_path)
    if keep_converted_textures and os.path.isfile(cache_path):
        cache_valid = True
        try:
            cache_valid = os.path.getmtime(cache_path) >= os.path.getmtime(resolved_path)
        except Exception:
            cache_valid = True

        if cache_valid:
            try:
                image = _load_external_image(cache_path, color_space)
                return image, _has_image_alpha(image), resolved_path, "cache_hit", cache_path
            except Exception:
                try:
                    os.remove(cache_path)
                except Exception:
                    pass

    try:
        image, tex = load_file(resolved_path, color_space)
    except Exception:
        return None, False, resolved_path, "missing", cache_path

    if image is None:
        return None, False, resolved_path, "missing", cache_path

    has_alpha = _has_image_alpha(image)
    try:
        paa_ns = getattr(import_paa_mod, "paa", None)
        paa_type = getattr(paa_ns, "PAA_Type", None) if paa_ns is not None else None
        dxt5 = getattr(paa_type, "DXT5", None) if paa_type is not None else None
        if tex is not None and dxt5 is not None:
            has_alpha = getattr(tex, "type", None) == dxt5
    except Exception:
        pass

    if keep_converted_textures:
        try:
            _save_image_as_png(image, cache_path)
            cache_image = _load_external_image(cache_path, color_space)
            cache_has_alpha = _has_image_alpha(cache_image) or has_alpha
            _remove_image_if_unused(image)
            return cache_image, cache_has_alpha, resolved_path, "cache_created", cache_path
        except Exception as e:
            print("=== Import/Export planner: failed to write texture cache ===")
            print(f"{resolved_path} -> {_fmt_exc(e)}")

    return image, has_alpha, resolved_path, "paa_runtime", cache_path

def _setup_import_preview_nodes(material: bpy.types.Material, image, texture_label: str, has_alpha: bool):
    if material is None or image is None:
        return False

    material.use_nodes = True
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None:
        return False

    nodes = node_tree.nodes
    links = node_tree.links
    nodes.clear()

    node_output = nodes.new("ShaderNodeOutputMaterial")
    node_output.location = (300, 0)

    node_shader = nodes.new("ShaderNodeBsdfPrincipled")
    node_shader.location = (0, 0)
    links.new(node_shader.outputs["BSDF"], node_output.inputs["Surface"])

    node_texture = nodes.new("ShaderNodeTexImage")
    node_texture.location = (-320, 0)
    node_texture.image = image
    node_texture.label = os.path.basename(texture_label or getattr(image, "filepath", "") or image.name)
    links.new(node_texture.outputs["Color"], node_shader.inputs["Base Color"])

    if has_alpha:
        try:
            links.new(node_texture.outputs["Alpha"], node_shader.inputs["Alpha"])
            _enable_preview_material_alpha(material)
        except Exception:
            pass

    return True

def _postprocess_imported_material_previews(context, imported_objs, *, show_materials: bool, keep_converted_textures: bool):
    result = {
        "materials_total": 0,
        "textured_candidates": 0,
        "previewed": 0,
        "missing": 0,
        "cache_hits": 0,
        "cache_created": 0,
        "errors": [],
    }

    if not show_materials:
        return result

    materials = _iter_unique_materials_from_objects(imported_objs)
    result["materials_total"] = len(materials)

    for mat in materials:
        paa_path, _ = _get_a3ob_material_paths(mat)
        if not paa_path:
            continue

        result["textured_candidates"] += 1
        image, has_alpha, resolved_path, source_kind, _cache_path = _load_material_preview_image(
            paa_path,
            keep_converted_textures,
            color_space="SRGB",
        )
        if image is None:
            result["missing"] += 1
            continue

        try:
            if _setup_import_preview_nodes(mat, image, resolved_path or paa_path, has_alpha):
                result["previewed"] += 1
                if source_kind == "cache_hit":
                    result["cache_hits"] += 1
                elif source_kind == "cache_created":
                    result["cache_created"] += 1
        except Exception as e:
            result["errors"].append(f"{mat.name}: {_fmt_exc(e)}")

    scene = getattr(context, "scene", None)
    tex_settings = getattr(scene, "cray_texreplace_settings", None) if scene is not None else None
    preview_obj = getattr(tex_settings, "picked_object", None) if tex_settings is not None else None
    if preview_obj in imported_objs and tex_settings is not None:
        try:
            _collect_object_image_materials(preview_obj, tex_settings.obj_preview_items)
        except Exception:
            pass

    return result

def _get_import_preview_settings(context, operator=None):
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "cray_ie_settings", None) if scene is not None else None

    show_materials = bool(getattr(settings, "import_show_materials", True))
    if operator is not None and hasattr(operator, "load_textures"):
        try:
            show_materials = bool(getattr(operator, "load_textures"))
        except Exception:
            pass

    keep_converted_textures = bool(getattr(settings, "import_keep_converted_textures", False))
    return show_materials, keep_converted_textures

def _log_import_preview_summary(filepath: str, stats):
    if not stats:
        return

    previewed = int(stats.get("previewed", 0) or 0)
    missing = int(stats.get("missing", 0) or 0)
    cache_hits = int(stats.get("cache_hits", 0) or 0)
    cache_created = int(stats.get("cache_created", 0) or 0)
    errors = list(stats.get("errors", []) or [])

    if previewed == 0 and missing == 0 and cache_hits == 0 and cache_created == 0 and not errors:
        return

    print("=== Import/Export planner: material previews ===")
    print(f"{os.path.basename(filepath) or filepath}")
    print(
        "materials: {materials_total}, textured: {textured_candidates}, previewed: {previewed}, "
        "missing: {missing}, cache hits: {cache_hits}, cache created: {cache_created}".format(
            materials_total=int(stats.get("materials_total", 0) or 0),
            textured_candidates=int(stats.get("textured_candidates", 0) or 0),
            previewed=previewed,
            missing=missing,
            cache_hits=cache_hits,
            cache_created=cache_created,
        )
    )
    if errors:
        for item in errors[:20]:
            print(item)

# ---------- UI data ----------

class CRAY_PG_TexDBItem(PropertyGroup):
    basename: StringProperty()
    abs_path: StringProperty()
    rel_path: StringProperty()
    is_problem: BoolProperty(default=False)
    dup_count: IntProperty(default=0)

class CRAY_PG_ObjMatImagesItem(PropertyGroup):
    mat_name: StringProperty()
    images_csv: StringProperty()

class CRAY_PG_TexReplaceSettings(PropertyGroup):
    folder: StringProperty(name="Folder", default="P:\\NH_ObjectTextures", subtype="DIR_PATH")
    picked_object: PointerProperty(name="Select Object", type=bpy.types.Object)
    fix_list_path: StringProperty(
        name="Fix List .txt",
        description="Structured text file with bad component names per .p3d and LOD",
        default="",
        subtype="FILE_PATH",
    )
    fix_mesh_join_batch: IntProperty(
        name="Fix Mesh Join Batch",
        description=(
            "How many meshes to join in one pass. "
            "1 = try to join all at once (legacy behavior), "
            "higher values split work into stages"
        ),
        default=1,
        min=1,
        max=500,
    )
    fix_mesh_center_to_origin: BoolProperty(
        name="Center Fixed Mesh To (0,0,0)",
        description="After Fix Mesh, move merged object's bounds center to world origin",
        default=True,
    )
    export_warn_loose_vertices: BoolProperty(
        name="Warn Loose Vertices On Export",
        description=(
            "During batch export, warn if any LOD except Point clouds > Memory contains isolated "
            "vertices with no edges or faces. Export continues so the model is still written."
        ),
        default=True,
    )
    split_planar_ngon_vertex_count: IntProperty(
        name="Flat Min N",
        description="Find flat thin face islands whose outer boundary has at least this many vertices",
        default=4,
        min=3,
        max=128,
    )
    split_planar_ngon_angle_tolerance: FloatProperty(
        name="Angle Tol",
        description="Maximum normal deviation in degrees when grouping faces into one planar island",
        default=0.1,
        min=0.0,
        soft_max=5.0,
        precision=4,
    )
    split_planar_ngon_plane_tolerance: FloatProperty(
        name="Plane Tol",
        description="Maximum signed distance from the seed plane for faces in the same planar island",
        default=0.0001,
        min=0.0,
        soft_max=0.01,
        precision=6,
    )
    obj_preview_items: bpy.props.CollectionProperty(type=CRAY_PG_ObjMatImagesItem)
    obj_preview_active_index: IntProperty(default=0)
    db_items: bpy.props.CollectionProperty(type=CRAY_PG_TexDBItem)
    db_active_index: IntProperty(default=0)

class CRAY_UL_TexDB(UIList):
    bl_idname = "CRAY_UL_tex_db"
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.alert = bool(item.is_problem)
        row = layout.row(align=True)
        row.label(text=item.basename, icon="FILE")
        row.label(text=item.rel_path)
        if item.is_problem:
            row.label(text=f"DUP x{item.dup_count}", icon="ERROR")

class CRAY_UL_ObjPreview(UIList):
    bl_idname = "CRAY_UL_obj_preview"
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=item.mat_name, icon="MATERIAL")
        row.label(text=item.images_csv, icon="IMAGE_DATA")

class CRAY_OT_TexDBBuildFromFolder(Operator):
    bl_idname = "cray.tex_db_build_folder"
    bl_label = "Build From Folder"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings
        if not ts.folder:
            self.report({"ERROR"}, "Folder is not set")
            return {"CANCELLED"}

        folder_abs = bpy.path.abspath(ts.folder)
        if not os.path.isdir(folder_abs):
            self.report({"ERROR"}, f"Folder not found: {folder_abs}")
            return {"CANCELLED"}

        try:
            entries = _walk_folder_build_db(folder_abs)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to build DB from '{folder_abs}': {_fmt_exc(e)}")
            return {"CANCELLED"}

        ts.db_items.clear()
        for d in entries:
            it = ts.db_items.add()
            it.basename = d["basename"]
            it.abs_path = d["abs_path"]
            it.rel_path = d["rel_path"]
            it.is_problem = d["is_problem"]
            it.dup_count = d["dup_count"]

        total = len(entries)
        problems = sum(1 for d in entries if d["is_problem"])
        if total == 0:
            self.report({"WARNING"}, "DB is empty: no .paa/.rvmat found")
        elif problems:
            self.report({"WARNING"}, f"DB built: {total}. Problematic duplicates: {problems} (red)")
        else:
            self.report({"INFO"}, f"DB built: {total} (.paa/.rvmat)")
        return {"FINISHED"}

class CRAY_OT_UpdateObjectPreview(Operator):
    bl_idname = "cray.update_object_preview"
    bl_label = "Update Object Preview"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings
        obj, src = _resolve_tex_target_object(context, ts.picked_object)
        if obj is None:
            ts.obj_preview_items.clear()
            self.report({"ERROR"}, "No mesh object found (pick one or select one)")
            return {"CANCELLED"}
        ts.picked_object = obj

        n = _collect_object_image_materials(obj, ts.obj_preview_items)
        if n == 0:
            self.report({"WARNING"}, f"Object '{obj.name}' has no materials with Image Texture nodes")
        else:
            suffix = "" if src == "picked" else f" (auto: {src})"
            self.report({"INFO"}, f"Object '{obj.name}': {n} materials with Image Texture nodes{suffix}")
        return {"FINISHED"}

class CRAY_OT_FixMeshHierarchy(Operator):
    bl_idname = "cray.fix_mesh_hierarchy"
    bl_label = "Fix Mesh/Hierarchy"
    bl_description = (
        "Use the picked/selected/active mesh as the main target, join meshes in scope, clean helper leftovers, "
        "and move the result into the fix collection"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings
        target_obj, src = _resolve_fix_target_object(context, ts.picked_object)
        if target_obj is None:
            self.report({"ERROR"}, "No mesh object found (pick/select one)")
            return {"CANCELLED"}
        ts.picked_object = target_obj

        if context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass

        scope_objs, scope_src = _collect_fix_scope(context, target_obj)

        scope_names = []
        for o in scope_objs:
            try:
                name = o.name
            except ReferenceError:
                continue
            if not name:
                continue
            if name not in scope_names:
                scope_names.append(name)

        mesh_candidates = [
            o for o in (bpy.data.objects.get(name) for name in scope_names)
            if o is not None and o.type == "MESH" and o.data is not None and len(o.data.polygons) > 0
        ]
        if not mesh_candidates:
            self.report({"ERROR"}, "No mesh object in selected scope")
            return {"CANCELLED"}

        anchor_mesh = None
        anchor_src = "largest-non-helper"
        if target_obj in mesh_candidates and not _is_helper_object_name(target_obj.name):
            anchor_mesh = target_obj
            anchor_src = "target"
        else:
            non_helper = [o for o in mesh_candidates if not _is_helper_object_name(o.name)]
            if non_helper:
                anchor_mesh = max(non_helper, key=lambda o: len(o.data.polygons) if o.data else 0)
            else:
                anchor_mesh = max(mesh_candidates, key=lambda o: len(o.data.polygons) if o.data else 0)
                anchor_src = "largest-mesh"
        if anchor_mesh is None:
            self.report({"ERROR"}, "No valid mesh anchor in selected scope")
            return {"CANCELLED"}
        active_mesh_name = anchor_mesh.name
        ts.picked_object = anchor_mesh

        try:
            merged_obj, joined_count, join_passes = _join_meshes_in_batches(
                context=context,
                anchor_obj=anchor_mesh,
                mesh_names=[o.name for o in mesh_candidates],
                batch_size=ts.fix_mesh_join_batch,
            )
        except Exception as e:
            self.report({"ERROR"}, f"Join failed: {_fmt_exc(e)}")
            return {"CANCELLED"}

        live_scope_names = []
        for name in scope_names:
            ch_live = bpy.data.objects.get(name)
            if ch_live is None or ch_live == merged_obj:
                continue
            live_scope_names.append(( _obj_depth(ch_live), name ))
        live_scope_names.sort(key=lambda it: it[0], reverse=True)

        deleted_scope = 0
        for idx, (_, name) in enumerate(live_scope_names, start=1):
            ch_live = bpy.data.objects.get(name)
            if ch_live is None:
                continue
            try:
                bpy.data.objects.remove(ch_live, do_unlink=True)
            except Exception:
                continue
            deleted_scope += 1
            if idx % 50 == 0:
                _ui_yield()

        target_collection, mesh_obj = _ensure_flat_collection_mesh(context, merged_obj)
        deleted_target_objs, deleted_target_cols = _cleanup_target_collection_keep_mesh(target_collection, mesh_obj)

        deleted_helpers, deleted_helper_cols, remaining_helpers = _remove_helper_named_objects(
            scene=context.scene,
            keep_obj=mesh_obj,
        )

        centered = False
        center_vec = Vector((0.0, 0.0, 0.0))
        if ts.fix_mesh_center_to_origin:
            centered, center_vec = _center_object_bbox_to_world_origin(mesh_obj)

        deleted_total = deleted_scope + deleted_target_objs + deleted_helpers
        extras = [
            f"src: {src}",
            f"scope: {scope_src}",
            f"scene: {context.scene.name}",
            f"scope_objs: {len(scope_names)}",
            f"anchor: {active_mesh_name}",
            f"anchor_src: {anchor_src}",
            f"join_passes: {join_passes}",
            f"join_batch: {int(ts.fix_mesh_join_batch)}",
        ]
        if deleted_helper_cols:
            extras.append(f"helper_cols: {deleted_helper_cols}")
        if remaining_helpers:
            extras.append(f"remaining_helpers: {len(remaining_helpers)}")
        if ts.fix_mesh_center_to_origin:
            if centered:
                extras.append(
                    f"centered_to_origin: yes ({center_vec.x:.3f}, {center_vec.y:.3f}, {center_vec.z:.3f})"
                )
            else:
                extras.append("centered_to_origin: already")
        else:
            extras.append("centered_to_origin: off")
        suffix = "" if not extras else f", {', '.join(extras)}"
        self.report(
            {"INFO"},
            (
                f"Fixed '{mesh_obj.name}': joined {joined_count}, removed objects {deleted_total}, "
                f"removed subcollections {deleted_target_cols}, "
                f"hierarchy: {context.scene.collection.name}/{target_collection.name}/{mesh_obj.name}{suffix}"
            ),
        )
        return {"FINISHED"}

class CRAY_OT_ReplaceTexturesFromDB(Operator):
    bl_idname = "cray.replace_textures_from_db"
    bl_label = "Replace Texture from DB"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings
        obj, _ = _resolve_tex_target_object(context, ts.picked_object)

        if obj is None:
            self.report({"ERROR"}, "No mesh object found (pick one or select one)")
            return {"CANCELLED"}
        ts.picked_object = obj
        if len(ts.db_items) == 0:
            self.report({"ERROR"}, "DB is empty. Build From Folder first.")
            return {"CANCELLED"}

        db_map, dup_names = _build_db_map(ts)

        materials_checked = 0
        matched_total = 0
        matched_both = 0
        matched_paa_only = 0
        matched_rvmat_only = 0
        changed = 0
        missing = []
        failed = []

        for slot in obj.material_slots:
            mat = slot.material
            if mat is None:
                continue

            materials_checked += 1
            candidates = _build_material_candidates(mat)
            match = _pick_best_db_match(candidates, db_map)

            if not match:
                preview = ", ".join(candidates[:5]) if candidates else "<none>"
                missing.append(f"{mat.name} -> no .paa/.rvmat match (candidates: {preview})")
                continue

            used_base = match["base"]
            found_paa = match["paa"]
            found_rvmat = match["rvmat"]
            matched_total += 1
            if found_paa and found_rvmat:
                matched_both += 1
            elif found_paa:
                matched_paa_only += 1
            else:
                matched_rvmat_only += 1

            try:
                _set_a3ob_material_paths(mat, found_paa, found_rvmat)
                changed += 1
            except Exception as e:
                failed.append(f"{mat.name} (base: {used_base}): {_fmt_exc(e)}")

        print("=== Texture Replace: Summary ===")
        print(f"Object: {obj.name}")
        print(f"Materials checked: {materials_checked}")
        print(
            f"Matched: {matched_total} (both: {matched_both}, "
            f"paa-only: {matched_paa_only}, rvmat-only: {matched_rvmat_only})"
        )
        print(f"Updated: {changed}")
        print(f"Missing: {len(missing)}")
        print(f"Failed: {len(failed)}")

        if failed:
            self.report({"ERROR"}, f"Updated: {changed}, failed: {len(failed)} (see System Console)")
            print("=== Texture Replace: A3OB set failed ===")
            for f in failed:
                print(f)
            if missing:
                print("=== Texture Replace: Missing entries ===")
                for m in missing:
                    print(m)
            return {"CANCELLED"}

        if missing:
            self.report({"WARNING"}, f"Updated: {changed}, missing: {len(missing)} (see System Console)")
            print("=== Texture Replace: Missing entries ===")
            for m in missing:
                print(m)
        else:
            self.report({"INFO"}, f"Updated: {changed} materials (A3OB updated)")

        if dup_names:
            print("=== Texture Replace: DB duplicates (picked first path) ===")
            for d in sorted(dup_names):
                print(d)

        return {"FINISHED"}

# ------------------------------------------------------------------------
#  Batch Import (A3OB)
# ------------------------------------------------------------------------

def _iter_layer_collections(layer_collection):
    stack = [layer_collection]
    while stack:
        lc = stack.pop()
        yield lc
        for ch in reversed(list(lc.children)):
            stack.append(ch)

def _disable_all_collections_in_view_layer(context, mode: str):
    vl = context.view_layer
    root_lc = vl.layer_collection
    for lc in _iter_layer_collections(root_lc):
        if lc is root_lc:
            continue
        if mode == "EXCLUDE":
            lc.exclude = True
        else:
            try:
                lc.collection.hide_viewport = True
                lc.collection.hide_render = True
            except Exception:
                pass

_IE_SOURCE_PATH_KEY = "cray_source_p3d"
_INVALID_FILENAME_CHARS_RE = re.compile(r'[<>:"/\\|?*]')

def _iter_collection_tree(collection):
    stack = [collection]
    while stack:
        col = stack.pop()
        yield col
        for ch in reversed(list(col.children)):
            stack.append(ch)

def _collect_collection_objects_recursive(collection):
    objects = []
    seen = set()
    for col in _iter_collection_tree(collection):
        for obj in col.objects:
            ptr = obj.as_pointer()
            if ptr in seen:
                continue
            seen.add(ptr)
            objects.append(obj)
    return objects

def _collection_has_any_mesh(collection):
    for obj in _collect_collection_objects_recursive(collection):
        if obj.type == "MESH":
            return True
    return False

def _collection_has_any_object_ptr(collection, object_ptrs):
    if not object_ptrs:
        return False
    for obj in _collect_collection_objects_recursive(collection):
        if obj.as_pointer() in object_ptrs:
            return True
    return False

def _find_collection_path(root_collection, target_ptr):
    if root_collection.as_pointer() == target_ptr:
        return [root_collection]

    for child in root_collection.children:
        path = _find_collection_path(child, target_ptr)
        if path:
            return [root_collection] + path
    return None

def _ensure_collection_visible_in_view_layer(context, target_collection):
    root = context.scene.collection
    path = _find_collection_path(root, target_collection.as_pointer())
    if not path:
        return

    layer_map = {lc.collection.as_pointer(): lc for lc in _iter_layer_collections(context.view_layer.layer_collection)}
    to_show = []
    to_show.extend(path)
    to_show.extend(list(_iter_collection_tree(target_collection)))

    seen = set()
    for col in to_show:
        ptr = col.as_pointer()
        if ptr in seen:
            continue
        seen.add(ptr)

        lc = layer_map.get(ptr)
        if lc is not None:
            try:
                lc.exclude = False
            except Exception:
                pass

        try:
            col.hide_viewport = False
        except Exception:
            pass
        try:
            col.hide_render = False
        except Exception:
            pass

def _strip_blender_numeric_suffix(name: str) -> str:
    n = (name or "").strip()
    m = re.match(r"^(.*)\.(\d{3})$", n)
    if m:
        return m.group(1)
    return n

def _looks_like_p3d_collection_name(name: str) -> bool:
    n = (name or "").strip().lower()
    return ".p3d" in n

def _looks_like_split_part_collection_name(name: str) -> bool:
    n = (name or "").strip()
    if not n:
        return False
    return re.search(r"_(?:p)?\d+\.p3d$", n, flags=re.IGNORECASE) is not None

def _build_ie_import_basename_map(settings):
    mapping = {}
    for item in settings.import_files:
        fp = bpy.path.abspath(item.path)
        if not fp:
            continue
        base = os.path.basename(fp).lower()
        if not base:
            continue
        if base not in mapping:
            mapping[base] = _norm_path(fp)
    return mapping


def _planner_add_import_file(settings, filepath: str) -> bool:
    if settings is None:
        return False

    fp = _norm_path(bpy.path.abspath(filepath)) if filepath else ""
    if not fp:
        return False

    for idx, item in enumerate(settings.import_files):
        existing = _norm_path(bpy.path.abspath(item.path)) if item.path else ""
        if existing == fp:
            settings.import_active_index = idx
            return False

    item = settings.import_files.add()
    item.path = fp
    settings.import_active_index = len(settings.import_files) - 1
    return True


def _normalize_p3d_lookup_key(value: str) -> str:
    raw = (value or "").replace("/", "\\").strip()
    if not raw:
        return ""
    raw = raw.split("\\")[-1]
    raw = _strip_blender_numeric_suffix(raw)
    if raw.lower().endswith(".p3d"):
        raw = raw[:-4]
    return raw.strip().lower()


def _display_p3d_name(value: str) -> str:
    key = _normalize_p3d_lookup_key(value)
    if not key:
        return ""
    return key + ".p3d"


def _find_existing_scene_p3d_root(scene, model_name_or_path: str):
    wanted = _normalize_p3d_lookup_key(model_name_or_path)
    if not wanted:
        return None

    for col in _iter_p3d_root_collections(scene):
        if _normalize_p3d_lookup_key(getattr(col, "name", "") or "") == wanted:
            return col
    return None


def _find_p3d_paths_by_name(search_root: str, model_name: str):
    root_abs = bpy.path.abspath(search_root) if search_root else ""
    root_abs = os.path.abspath(root_abs) if root_abs else ""
    wanted = _normalize_p3d_lookup_key(model_name)
    if not root_abs or not os.path.isdir(root_abs) or not wanted:
        return []

    matches = []
    for root, _, files in os.walk(root_abs):
        for fn in files:
            if not fn.lower().endswith(".p3d"):
                continue
            if _normalize_p3d_lookup_key(fn) != wanted:
                continue
            matches.append(_norm_path(os.path.join(root, fn)))

    matches.sort(key=lambda item: (len(item), item.lower()))
    return matches

def _resolve_collection_source_path(collection, import_basename_map=None):
    src = collection.get(_IE_SOURCE_PATH_KEY)
    if isinstance(src, str) and src.strip():
        return _norm_path(bpy.path.abspath(src))

    for obj in _collect_collection_objects_recursive(collection):
        src = obj.get(_IE_SOURCE_PATH_KEY)
        if isinstance(src, str) and src.strip():
            return _norm_path(bpy.path.abspath(src))

    if import_basename_map:
        names = []
        raw = (collection.name or "").strip()
        if raw:
            names.append(raw)
            names.append(_strip_blender_numeric_suffix(raw))
        for name in names:
            n = name.strip()
            if not n:
                continue
            if ".p3d" not in n.lower():
                n = n + ".p3d"
            key = n.lower()
            if key in import_basename_map:
                return import_basename_map[key]

    return ""

def _export_filename_for_collection(collection, source_path: str):
    if source_path:
        base = os.path.basename(source_path)
        if base:
            return base

    base = _strip_blender_numeric_suffix(collection.name)
    if not base:
        base = "export"
    if ".p3d" not in base.lower():
        base = base + ".p3d"
    return _INVALID_FILENAME_CHARS_RE.sub("_", base)

def _clear_ie_source_path_tag(id_data):
    if id_data is None:
        return
    try:
        if _IE_SOURCE_PATH_KEY in id_data:
            del id_data[_IE_SOURCE_PATH_KEY]
    except Exception:
        pass

def _set_ie_source_path_tag(id_data, source_path: str):
    if id_data is None:
        return
    src = _norm_path(bpy.path.abspath(source_path)) if source_path else ""
    if not src:
        _clear_ie_source_path_tag(id_data)
        return
    try:
        id_data[_IE_SOURCE_PATH_KEY] = src
    except Exception:
        pass

def _derive_split_export_source_path(source_root, split_root_name: str) -> str:
    source_path = _resolve_collection_source_path(source_root)
    if not source_path:
        return ""

    source_dir = os.path.dirname(source_path)
    if not source_dir:
        return ""

    base = _strip_blender_numeric_suffix((split_root_name or "").strip())
    if not base:
        base = "export"
    if ".p3d" not in base.lower():
        base = base + ".p3d"
    base = _INVALID_FILENAME_CHARS_RE.sub("_", base)
    return _norm_path(os.path.join(source_dir, base))

def _find_p3d_root_collection_for_object(context, obj):
    if obj is None:
        return None

    scene_root = getattr(getattr(context, "scene", None), "collection", None)
    if scene_root is None:
        return None

    best = None
    best_depth = -1
    for col in getattr(obj, "users_collection", []):
        path = _find_collection_path(scene_root, col.as_pointer())
        if not path:
            continue
        for depth, item in enumerate(path):
            if _looks_like_p3d_collection_name(item.name) and depth >= best_depth:
                best = item
                best_depth = depth

    return best

def _plain_axis_helper_name(root_collection) -> str:
    root_name = _strip_blender_numeric_suffix((getattr(root_collection, "name", "") or "").strip())
    if not root_name:
        root_name = "Model"
    root_name = re.sub(r"\s+", " ", root_name).strip()
    return f"Plain Axis {root_name}"

def _is_plain_axis_helper(obj) -> bool:
    if obj is None or obj.type != "EMPTY":
        return False
    try:
        if bool(obj.get(_PLAIN_AXIS_HELPER_PROP, False)):
            return True
    except Exception:
        pass
    return False

def _pick_plain_axis_root_collection(context, source_obj):
    root = _find_p3d_root_collection_for_object(context, source_obj)
    if root is not None:
        return root, True
    if source_obj is not None and source_obj.users_collection:
        return source_obj.users_collection[0], False
    return getattr(getattr(context, "scene", None), "collection", None), False

def _collect_plain_axis_target_objects(root_collection, helper_obj=None):
    objects = _collect_collection_objects_recursive(root_collection) if root_collection is not None else []
    if not objects:
        return []

    object_ptrs = {obj.as_pointer() for obj in objects}
    targets = []
    for obj in objects:
        if helper_obj is not None and obj == helper_obj:
            continue
        if _is_plain_axis_helper(obj):
            continue
        if obj.parent is not None and obj.parent.as_pointer() in object_ptrs:
            continue
        targets.append(obj)
    return targets

def _iter_plain_axis_constraints(obj, helper_ptrs=None):
    if obj is None:
        return
    for con in getattr(obj, "constraints", []):
        if getattr(con, "type", "") != "CHILD_OF":
            continue
        target = getattr(con, "target", None)
        target_ptr = target.as_pointer() if target is not None else None
        if helper_ptrs and target_ptr in helper_ptrs:
            yield con
            continue
        if getattr(con, "name", "") == _PLAIN_AXIS_CONSTRAINT_NAME and target is not None and _is_plain_axis_helper(target):
            yield con

def _remove_plain_axis_constraints_from_objects(objects, helper_ptrs=None):
    removed = 0
    for obj in objects:
        constraints = list(_iter_plain_axis_constraints(obj, helper_ptrs=helper_ptrs))
        for con in constraints:
            try:
                obj.constraints.remove(con)
                removed += 1
            except Exception:
                pass
    return removed

def _apply_child_of_inverse_with_fallback(context, obj, constraint):
    if obj is None or constraint is None:
        return

    try:
        with context.temp_override(
            object=obj,
            active_object=obj,
            selected_objects=[obj],
            selected_editable_objects=[obj],
        ):
            bpy.ops.constraint.childof_set_inverse(constraint=constraint.name, owner="OBJECT")
        return
    except Exception:
        pass

    target = getattr(constraint, "target", None)
    if target is None:
        return
    try:
        constraint.inverse_matrix = target.matrix_world.inverted_safe()
    except Exception:
        pass

def _create_plain_axis_helper(context, root_collection, source_obj, world_location):
    helper_name = _plain_axis_helper_name(root_collection)
    helper_obj = bpy.data.objects.new(helper_name, None)
    helper_obj.empty_display_type = "PLAIN_AXES"
    try:
        max_dim = max(abs(float(v)) for v in getattr(source_obj, "dimensions", (0.0, 0.0, 0.0)))
    except Exception:
        max_dim = 0.0
    helper_obj.empty_display_size = max(0.05, max_dim * 0.08)
    helper_obj.matrix_world = Matrix.Translation(world_location)
    helper_obj[_PLAIN_AXIS_HELPER_PROP] = True
    helper_obj[_PLAIN_AXIS_ROOT_PROP] = getattr(root_collection, "name", "")
    helper_obj[_PLAIN_AXIS_SOURCE_OBJECT_PROP] = getattr(source_obj, "name", "")
    _link_object_to_collection(helper_obj, root_collection)
    _ensure_collection_visible_in_view_layer(context, root_collection)
    return helper_obj

def _clear_plain_axis_helpers(context, helper_objects):
    live_helpers = []
    seen = set()
    for obj in helper_objects:
        if obj is None:
            continue
        try:
            ptr = obj.as_pointer()
        except Exception:
            continue
        if ptr in seen:
            continue
        seen.add(ptr)
        if bpy.data.objects.get(obj.name) is None:
            continue
        live_helpers.append(obj)

    if not live_helpers:
        return 0, 0

    helper_ptrs = {obj.as_pointer() for obj in live_helpers}
    removed_constraints = _remove_plain_axis_constraints_from_objects(bpy.data.objects, helper_ptrs=helper_ptrs)

    removed_helpers = 0
    for obj in live_helpers:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
            removed_helpers += 1
        except Exception:
            pass

    return removed_helpers, removed_constraints

def _clear_plain_axis_helpers_in_collection(context, root_collection):
    if root_collection is None:
        return 0, 0
    helpers = [obj for obj in _collect_collection_objects_recursive(root_collection) if _is_plain_axis_helper(obj)]
    return _clear_plain_axis_helpers(context, helpers)

def _best_object_collection_path_under_root(root_collection, obj):
    if root_collection is None or obj is None:
        return None

    best = None
    for col in getattr(obj, "users_collection", []):
        path = _find_collection_path(root_collection, col.as_pointer())
        if not path:
            continue
        if best is None or len(path) > len(best):
            best = path

    return best

def _format_split_part_collection_name(source_root_name: str, part_number: int) -> str:
    base_name = _strip_blender_numeric_suffix((source_root_name or "").strip())
    if not base_name:
        base_name = "part"

    suffix = f"_p{int(part_number):02d}"
    stem, ext = os.path.splitext(base_name)
    if ext.lower() == ".p3d":
        return f"{stem}{suffix}{ext}"
    return f"{base_name}{suffix}.p3d"

def _split_part_collection_number(source_root_name: str, collection_name: str):
    base_name = _strip_blender_numeric_suffix((source_root_name or "").strip())
    if not base_name:
        return None

    stem, ext = os.path.splitext(base_name)
    base_stem = stem if ext.lower() == ".p3d" else base_name
    if not base_stem:
        return None

    pattern = r"^" + re.escape(base_stem) + r"_p(\d+)\.p3d$"
    match = re.match(pattern, _strip_blender_numeric_suffix(collection_name or ""), flags=re.IGNORECASE)
    if not match:
        return None
    try:
        return int(match.group(1))
    except Exception:
        return None

def _next_split_part_collection_number(source_root) -> int:
    highest = 0
    if source_root is not None:
        for child in getattr(source_root, "children", []):
            number = _split_part_collection_number(getattr(source_root, "name", ""), getattr(child, "name", ""))
            if number is not None:
                highest = max(highest, number)
    return highest + 1

def _ensure_split_part_root_collection(context, source_root, part_number: int):
    parent = source_root
    if parent is None:
        return None

    part_name = _format_split_part_collection_name(getattr(source_root, "name", ""), part_number)
    target = parent.children.get(part_name)
    if target is None:
        target = bpy.data.collections.new(part_name)
        parent.children.link(target)

    try:
        source_color = getattr(source_root, "color_tag", None)
        if source_color:
            target.color_tag = source_color
    except Exception:
        pass

    split_source_path = _derive_split_export_source_path(source_root, part_name)
    _set_ie_source_path_tag(target, split_source_path)
    return target

def _format_named_split_model_collection_name(model_name: str) -> str:
    base_name = _strip_blender_numeric_suffix((model_name or "").strip())
    base_name = _INVALID_FILENAME_CHARS_RE.sub("_", base_name)
    base_name = re.sub(r"\s+", " ", base_name).strip(" .")
    if not base_name:
        base_name = "new_model"

    stem, ext = os.path.splitext(base_name)
    if ext.lower() == ".p3d":
        safe_stem = stem.strip(" .") or "new_model"
        return f"{safe_stem}.p3d"
    return f"{base_name}.p3d"

def _derive_named_split_export_source_path(source_root, model_root_name: str, export_mode: str, export_directory: str = "") -> str:
    filename = _format_named_split_model_collection_name(model_root_name)
    if export_mode == "CUSTOM_DIR":
        export_dir = bpy.path.abspath(export_directory) if export_directory else ""
        export_dir = os.path.abspath(export_dir) if export_dir else ""
        if not export_dir:
            return ""
        return _norm_path(os.path.join(export_dir, filename))
    return _derive_split_export_source_path(source_root, filename)

def _ensure_named_split_model_root_collection(context, source_root, model_name: str, export_mode: str, export_directory: str = ""):
    scene_root = getattr(getattr(context, "scene", None), "collection", None)
    parent = _find_parent_collection(scene_root, source_root) if scene_root is not None else None
    if parent is None:
        parent = scene_root if scene_root is not None else source_root
    if parent is None:
        return None

    target_name = _format_named_split_model_collection_name(model_name)
    target = parent.children.get(target_name)
    if target is None:
        existing = bpy.data.collections.get(target_name)
        if existing is not None:
            target = existing
            try:
                if all(ch != target for ch in parent.children):
                    parent.children.link(target)
            except Exception:
                pass
        else:
            target = bpy.data.collections.new(target_name)
            parent.children.link(target)

    try:
        source_color = getattr(source_root, "color_tag", None)
        if source_color:
            target.color_tag = source_color
    except Exception:
        pass

    split_source_path = _derive_named_split_export_source_path(
        source_root,
        target_name,
        export_mode,
        export_directory,
    )
    _set_ie_source_path_tag(target, split_source_path)
    return target

def _model_split_context_objects(context):
    selected = [obj for obj in getattr(context, "selected_objects", []) if obj is not None]
    if selected:
        return selected
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active_obj = getattr(active, "active", None) if active is not None else None
    return [active_obj] if active_obj is not None else []

def _model_split_single_source_root_from_context(context):
    objects = _model_split_context_objects(context)
    roots = {}
    missing = []
    for obj in objects:
        root = _find_p3d_root_collection_for_object(context, obj)
        if root is None:
            missing.append(getattr(obj, "name", "<unnamed>"))
            continue
        roots[root.as_pointer()] = root

    if missing:
        preview = ", ".join(missing[:5])
        if len(missing) > 5:
            preview += ", ..."
        return None, f"Selected/active objects are not inside a .p3d root collection: {preview}"
    if not roots:
        return None, "Select or activate an object inside the source .p3d root collection first"
    if len(roots) != 1:
        root_names = ", ".join(sorted({root.name for root in roots.values()}, key=lambda x: x.lower()))
        return None, f"Use objects from exactly one source .p3d root collection (found: {root_names})"
    return next(iter(roots.values())), ""

def _find_p3d_root_collection_for_collection(context, collection, *, require_p3d: bool = False):
    if collection is None:
        return None

    scene_root = getattr(getattr(context, "scene", None), "collection", None)
    if scene_root is None:
        if require_p3d and not _looks_like_p3d_collection_name(getattr(collection, "name", "") or ""):
            return None
        return collection

    try:
        path = _find_collection_path(scene_root, collection.as_pointer())
    except Exception:
        path = None

    if not path:
        if require_p3d and not _looks_like_p3d_collection_name(getattr(collection, "name", "") or ""):
            return None
        return collection

    best = None
    for col in path:
        if _looks_like_p3d_collection_name(getattr(col, "name", "") or ""):
            best = col
    if best is not None:
        return best
    return None if require_p3d else collection

def _object_is_directly_or_indirectly_in_collection(root_collection, obj) -> bool:
    if root_collection is None or obj is None:
        return False
    for col in getattr(obj, "users_collection", []):
        try:
            if _find_collection_path(root_collection, col.as_pointer()):
                return True
        except Exception:
            pass
    return False

def _model_split_target_category_spec(category_token: str):
    token = (category_token or "RESOLUTION").strip().upper()
    return _MODEL_SPLIT_TARGET_CATEGORY_SPECS.get(token) or _MODEL_SPLIT_TARGET_CATEGORY_SPECS["RESOLUTION"]

def _model_split_target_category_label(category_token: str) -> str:
    token = (category_token or "RESOLUTION").strip().upper()
    for item in _MODEL_SPLIT_TARGET_CATEGORY_ITEMS:
        if item[0] == token:
            return item[1]
    return "Resolution"

def _model_split_category_for_lod_token(lod_token: str) -> str:
    token = str(lod_token or "").strip()
    if token in _MODEL_SPLIT_GEOMETRY_LODS:
        return "GEOMETRIES"
    if token in _MODEL_SPLIT_POINT_CLOUD_LODS:
        return "POINT_CLOUDS"
    if token in _MODEL_SPLIT_ROADWAY_LODS:
        return "ROADWAY"
    return "RESOLUTION"

def _model_split_category_for_object(obj) -> str:
    if obj is not None and hasattr(obj, "a3ob_properties_object"):
        try:
            props = obj.a3ob_properties_object
            if bool(getattr(props, "is_a3_lod", False)):
                return _model_split_category_for_lod_token(getattr(props, "lod", ""))
        except Exception:
            pass

    name = _logical_collection_name(getattr(obj, "name", "") if obj is not None else "")
    if "roadway" in name:
        return "ROADWAY"
    if "memory" in name or "point" in name:
        return "POINT_CLOUDS"
    if "geometry" in name:
        return "GEOMETRIES"
    return "RESOLUTION"

def _ensure_model_split_target_category_collection(target_root, category_token: str):
    if target_root is None:
        return None

    spec = _model_split_target_category_spec(category_token)
    collection = _ensure_named_child_collection(
        target_root,
        spec["collection"],
        color_tag=spec.get("color"),
        aliases=spec.get("aliases", ()),
    )
    _clear_ie_source_path_tag(collection)
    return collection

def _set_model_split_target_lod_a3ob_props(obj, category_token: str):
    if obj is None or obj.type != "MESH" or not hasattr(obj, "a3ob_properties_object"):
        return

    spec = _model_split_target_category_spec(category_token)
    lod_token = str(spec.get("lod", "0"))
    try:
        props = obj.a3ob_properties_object
        current_is_lod = bool(getattr(props, "is_a3_lod", False))
        current_lod = str(getattr(props, "lod", "") or "")
        current_resolution = getattr(props, "resolution", 1)
        lod_token = current_lod if current_is_lod and current_lod else str(spec.get("lod", "0"))
        props.lod = lod_token
        if current_is_lod:
            pass
        elif lod_token == "0" and current_lod == "0":
            try:
                props.resolution = max(0, int(current_resolution))
            except Exception:
                props.resolution = 1
        else:
            props.resolution = 1
        if not current_is_lod:
            props.resolution_float = float(getattr(props, "resolution", 1) or 1)
        props.is_a3_lod = True
        _remove_a3ob_named_property(props, "autocenter")
        lod_name = props.get_name() if hasattr(props, "get_name") else _collider_lod_name(lod_token)
        if lod_name:
            obj.name = lod_name
            if obj.data is not None:
                obj.data.name = lod_name
    except Exception:
        pass

    if lod_token == "6":
        _apply_collider_visual_style(obj)
    elif lod_token == _ROADWAY_LOD_TOKEN:
        _apply_object_visual_style(obj, _ROADWAY_OBJECT_COLOR)

def _collect_model_split_selected_mesh_objects(context):
    selected = [
        obj for obj in getattr(context, "selected_objects", [])
        if obj is not None and getattr(obj, "type", None) == "MESH"
    ]
    if selected:
        return selected

    active_objects = getattr(getattr(context, "view_layer", None), "objects", None)
    active_obj = getattr(active_objects, "active", None) if active_objects is not None else None
    if active_obj is not None and getattr(active_obj, "type", None) == "MESH":
        return [active_obj]

    return []

def _model_split_single_source_root_for_objects(context, objects):
    roots = {}
    missing = []
    for obj in objects or []:
        root = _find_p3d_root_collection_for_object(context, obj)
        if root is None:
            missing.append(getattr(obj, "name", "<unnamed>"))
            continue
        roots[root.as_pointer()] = root

    if missing:
        preview = ", ".join(missing[:5])
        if len(missing) > 5:
            preview += ", ..."
        raise RuntimeError(f"Selected objects are not inside a .p3d root collection: {preview}")
    if not roots:
        raise RuntimeError("Select mesh objects inside one .p3d root collection")
    if len(roots) != 1:
        root_names = ", ".join(sorted({root.name for root in roots.values()}, key=lambda x: x.lower()))
        raise RuntimeError(f"Select mesh objects from exactly one .p3d root collection (found: {root_names})")
    return next(iter(roots.values()))

def _resolve_model_split_source_root(context, settings, objects):
    picked = getattr(settings, "named_source_collection", None)
    source_root = _find_p3d_root_collection_for_collection(context, picked, require_p3d=True) if picked is not None else None
    if picked is not None and source_root is None:
        raise RuntimeError("Source Model must be a .p3d root collection or one of its child collections")
    if source_root is None:
        source_root = _model_split_single_source_root_for_objects(context, objects)

    outside = [
        getattr(obj, "name", "<unnamed>")
        for obj in objects or []
        if not _object_is_directly_or_indirectly_in_collection(source_root, obj)
    ]
    if outside:
        preview = ", ".join(outside[:5])
        if len(outside) > 5:
            preview += ", ..."
        raise RuntimeError(f"Selected objects are not inside source collection {source_root.name}: {preview}")

    try:
        settings.named_source_collection = source_root
    except Exception:
        pass
    return source_root

def _separate_edit_selection_for_model_split(context, settings, copy_selection: bool = False):
    edit_obj = getattr(context, "edit_object", None)
    if edit_obj is None or getattr(edit_obj, "type", None) != "MESH":
        raise RuntimeError("Enter Edit Mode on a mesh and select the part to separate")

    source_root = _resolve_model_split_source_root(context, settings, [edit_obj])

    try:
        before_ptrs = {obj.as_pointer() for obj in bpy.data.objects}
    except Exception:
        before_ptrs = set()

    if copy_selection:
        try:
            bpy.ops.mesh.duplicate()
        except Exception as e:
            raise RuntimeError(f"Duplicate selected mesh part failed: {_fmt_exc(e)}")

    try:
        bpy.ops.mesh.separate(type="SELECTED")
    except Exception as e:
        raise RuntimeError(f"Separate selected mesh part failed: {_fmt_exc(e)}")

    try:
        bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass

    created = []
    for obj in bpy.data.objects:
        if getattr(obj, "type", None) != "MESH":
            continue
        try:
            if obj.as_pointer() in before_ptrs:
                continue
        except Exception:
            continue
        created.append(obj)

    if not created:
        created = [
            obj for obj in getattr(context, "selected_objects", [])
            if obj is not None and getattr(obj, "type", None) == "MESH" and obj != edit_obj
        ]

    if not created:
        raise RuntimeError("Select faces/edges/vertices before separating")

    return source_root, created, True

def _model_split_source_and_objects_for_transfer(context, settings, copy_selection: bool = False):
    mode = str(getattr(context, "mode", "") or "").upper()
    if mode in {"EDIT_MESH", "EDIT"}:
        return _separate_edit_selection_for_model_split(context, settings, copy_selection=copy_selection)

    selected = _collect_model_split_selected_mesh_objects(context)
    if not selected:
        raise RuntimeError("Select a mesh object or selected geometry in Edit Mode")

    source_root = _resolve_model_split_source_root(context, settings, selected)
    return source_root, selected, False

def _resolve_model_split_target_part_root(context, settings, source_root, *, force_new: bool = False):
    target_root = None
    target_container = None
    picked = getattr(settings, "named_target_collection", None)
    if picked is not None:
        target_container = _find_p3d_root_collection_for_collection(context, picked, require_p3d=True)
        if target_container is None:
            raise RuntimeError("Target Model must be a .p3d root collection or one of its child collections")
    if target_container is None:
        target_container = source_root

    if force_new and target_container is not None and _looks_like_split_part_collection_name(getattr(target_container, "name", "") or ""):
        scene_root = getattr(getattr(context, "scene", None), "collection", None)
        parent = _find_parent_collection(scene_root, target_container) if scene_root is not None else None
        if parent is not None and _looks_like_p3d_collection_name(getattr(parent, "name", "") or ""):
            target_container = parent

    use_existing_part = bool(
        target_container is not None and
        _looks_like_split_part_collection_name(getattr(target_container, "name", "") or "")
    )

    if force_new or not use_existing_part:
        part_number = _next_split_part_collection_number(target_container)
        target_root = _ensure_split_part_root_collection(context, target_container, part_number)
        if target_root is None:
            raise RuntimeError("Could not create destination part collection")
    else:
        target_root = target_container

    try:
        settings.named_target_collection = target_container
    except Exception:
        pass
    try:
        settings.part_number = _next_split_part_collection_number(target_container)
    except Exception:
        pass

    return target_root

def _add_model_split_part_to_planner(context, target_root):
    planner_path = _resolve_collection_source_path(target_root)
    if not planner_path and _looks_like_split_part_collection_name(getattr(target_root, "name", "") or ""):
        scene_root = getattr(getattr(context, "scene", None), "collection", None)
        parent = _find_parent_collection(scene_root, target_root) if scene_root is not None else None
        if parent is not None:
            planner_path = _derive_split_export_source_path(parent, getattr(target_root, "name", "") or "")
            if planner_path:
                _set_ie_source_path_tag(target_root, planner_path)
    if not planner_path:
        return False, ""
    try:
        added = _planner_add_import_file(context.scene.cray_ie_settings, planner_path)
    except Exception:
        added = False
    return added, planner_path

def _flatten_named_split_legacy_visuals_collection(dest_root):
    if dest_root is None:
        return

    visuals = None
    for child in list(getattr(dest_root, "children", [])):
        if _logical_collection_name(getattr(child, "name", "")) == _logical_collection_name("visuals"):
            visuals = child
            break
    if visuals is None:
        return

    legacy_resolution = None
    for child in list(getattr(visuals, "children", [])):
        if _logical_collection_name(getattr(child, "name", "")) == _logical_collection_name("resolution 0"):
            legacy_resolution = child
            break

    if legacy_resolution is None:
        return

    for obj in list(getattr(legacy_resolution, "objects", [])):
        try:
            _move_object_to_collection(obj, visuals)
        except Exception:
            pass
    if len(legacy_resolution.objects) == 0 and len(legacy_resolution.children) == 0:
        try:
            bpy.data.collections.remove(legacy_resolution)
        except Exception:
            pass

def _focus_created_split_objects(context, dest_root, created):
    _ensure_collection_visible_in_view_layer(context, dest_root)
    if not created:
        return

    _deselect_all_in_view_layer(context)
    for obj in created:
        try:
            obj.hide_set(False)
        except Exception:
            pass
        try:
            obj.hide_viewport = False
        except Exception:
            pass
        try:
            obj.select_set(True)
        except Exception:
            pass
    try:
        context.view_layer.objects.active = created[0]
    except Exception:
        pass

def _prepare_moved_objects_for_named_split(objects):
    moved_set = {obj for obj in objects if obj is not None}
    if not moved_set:
        return

    for obj in list(moved_set):
        if obj is None:
            continue

        world_matrix = None
        try:
            world_matrix = obj.matrix_world.copy()
        except Exception:
            pass

        try:
            parent_obj = obj.parent
        except Exception:
            parent_obj = None

        if parent_obj not in moved_set:
            try:
                obj.parent = None
            except Exception:
                pass
            if world_matrix is not None:
                try:
                    obj.matrix_world = world_matrix
                except Exception:
                    pass

        _clear_ie_source_path_tag(obj)

def _ensure_split_collection_path(dest_root, source_path):
    current = dest_root
    for source_col in list(source_path or [])[1:]:
        color_tag = None
        try:
            color_tag = getattr(source_col, "color_tag", None)
        except Exception:
            color_tag = None
        current = _ensure_named_child_collection(current, source_col.name, color_tag=color_tag)
        _clear_ie_source_path_tag(current)
    return current

def _duplicate_object_for_split(obj):
    if obj is None:
        return None

    new_obj = obj.copy()
    data = getattr(obj, "data", None)
    if data is not None:
        try:
            new_obj.data = data.copy()
        except Exception:
            pass

    try:
        new_obj.parent = None
    except Exception:
        pass

    try:
        new_obj.matrix_world = obj.matrix_world.copy()
    except Exception:
        pass

    _clear_ie_source_path_tag(new_obj)
    return new_obj

def _rewire_split_copy_object_refs(copies_by_source):
    source_to_copy = {src: dup for src, dup in copies_by_source.items() if src is not None and dup is not None}
    if not source_to_copy:
        return

    for source_obj, dup_obj in list(source_to_copy.items()):
        if dup_obj is None:
            continue

        try:
            parent_src = source_obj.parent
        except Exception:
            parent_src = None

        world_matrix = None
        try:
            world_matrix = source_obj.matrix_world.copy()
        except Exception:
            world_matrix = None

        if parent_src in source_to_copy:
            dup_parent = source_to_copy[parent_src]
            try:
                dup_obj.parent = dup_parent
                dup_obj.matrix_parent_inverse = dup_parent.matrix_world.inverted()
            except Exception:
                pass
            if world_matrix is not None:
                try:
                    dup_obj.matrix_world = world_matrix
                except Exception:
                    pass
        else:
            try:
                dup_obj.parent = None
            except Exception:
                pass
            if world_matrix is not None:
                try:
                    dup_obj.matrix_world = world_matrix
                except Exception:
                    pass

        for modifier in getattr(dup_obj, "modifiers", []):
            try:
                target_obj = getattr(modifier, "object", None)
            except Exception:
                target_obj = None
            if target_obj in source_to_copy:
                try:
                    modifier.object = source_to_copy[target_obj]
                except Exception:
                    pass

        for constraint in getattr(dup_obj, "constraints", []):
            try:
                target_obj = getattr(constraint, "target", None)
            except Exception:
                target_obj = None
            if target_obj in source_to_copy:
                try:
                    constraint.target = source_to_copy[target_obj]
                except Exception:
                    pass


def _resolve_object_source_p3d(obj):
    if obj is None:
        return ""

    candidates = [obj]
    if getattr(obj, "instance_collection", None) is not None:
        candidates.append(obj.instance_collection)

    parent = obj.parent
    while parent is not None:
        candidates.append(parent)
        if getattr(parent, "instance_collection", None) is not None:
            candidates.append(parent.instance_collection)
        parent = parent.parent

    for item in candidates:
        try:
            src = item.get(_IE_SOURCE_PATH_KEY)
        except Exception:
            src = None
        if isinstance(src, str) and src.strip():
            return _norm_path(bpy.path.abspath(src))

    for col in getattr(obj, "users_collection", []):
        src = _resolve_collection_source_path(col)
        if src:
            return src

    return ""


def _next_proxy_index_for_parent(parent_obj) -> int:
    max_index = 0
    for obj in bpy.data.objects:
        if obj.parent != parent_obj:
            continue
        if not hasattr(obj, "a3ob_properties_object_proxy"):
            continue
        try:
            pg = obj.a3ob_properties_object_proxy
        except Exception:
            continue
        for attr in ("index",):
            if hasattr(pg, attr):
                try:
                    max_index = max(max_index, int(getattr(pg, attr) or 0))
                except Exception:
                    pass
        try:
            for prop in pg.bl_rna.properties:
                if prop.identifier == "rna_type":
                    continue
                if prop.name == "Index":
                    try:
                        max_index = max(max_index, int(getattr(pg, prop.identifier) or 0))
                    except Exception:
                        pass
                    break
        except Exception:
            pass
    return max_index + 1


def _build_proxy_from_object_instance(proxy_obj, source_obj, parent_obj, proxy_index: int):
    proxy_obj.matrix_world = source_obj.matrix_world.copy()
    proxy_obj.parent = parent_obj
    try:
        proxy_obj.matrix_parent_inverse = parent_obj.matrix_world.inverted()
    except Exception:
        pass
    proxy_obj.name = f"proxy_{source_obj.name}_{proxy_index}"


def _pick_proxy_target_object(context, explicit_obj=None):
    if explicit_obj is not None and explicit_obj.type == "MESH":
        return explicit_obj
    active = context.view_layer.objects.active
    if active is not None and active.type == "MESH":
        return active
    for obj in context.selected_objects:
        if obj.type == "MESH":
            return obj
    return None


def _tag_import_source_on_imported_data(context, filepath, imported_objs, pre_collection_ptrs):
    src = _norm_path(bpy.path.abspath(filepath))
    if not src:
        return

    imported_ptrs = set()
    for obj in imported_objs:
        if obj is None:
            continue
        imported_ptrs.add(obj.as_pointer())
        try:
            obj[_IE_SOURCE_PATH_KEY] = src
        except Exception:
            pass

    if not imported_ptrs:
        return

    scene_root = context.scene.collection
    root_children = list(scene_root.children)
    new_collections = [c for c in bpy.data.collections if c.as_pointer() not in pre_collection_ptrs]

    for col in new_collections:
        if not _collection_has_any_object_ptr(col, imported_ptrs):
            continue
        try:
            col[_IE_SOURCE_PATH_KEY] = src
        except Exception:
            pass

    for col in new_collections:
        if not any(ch == col for ch in root_children):
            continue
        if not _collection_has_any_object_ptr(col, imported_ptrs):
            continue
        for nested in _iter_collection_tree(col):
            try:
                nested[_IE_SOURCE_PATH_KEY] = src
            except Exception:
                pass


def _patch_a3ob_import_read_file():
    if _A3OB_IMPORT_READ_FILE_PATCHES:
        return

    module_names = (
        "bl_ext.user_default.Arma3ObjectBuilder.io.import_p3d",
        "Arma3ObjectBuilder.io.import_p3d",
    )

    for module_name in module_names:
        mod = _import_first_available_module((module_name,))
        if mod is None:
            continue

        original_read_file = getattr(mod, "read_file", None)
        if not callable(original_read_file):
            continue
        if any(patched_mod is mod for patched_mod, _ in _A3OB_IMPORT_READ_FILE_PATCHES):
            continue

        def _wrapped_read_file(operator, context, file, _original_read_file=original_read_file, _module_name=module_name):
            filepath = _norm_path(bpy.path.abspath(getattr(operator, "filepath", "")))
            pre_col_ptrs = {col.as_pointer() for col in bpy.data.collections}

            lod_objects = _original_read_file(operator, context, file)

            if _A3OB_IMPORT_TRACKING_SUPPRESS_DEPTH > 0:
                return lod_objects

            if not filepath or not os.path.isfile(filepath):
                return lod_objects

            try:
                _tag_import_source_on_imported_data(
                    context=context,
                    filepath=filepath,
                    imported_objs=lod_objects or [],
                    pre_collection_ptrs=pre_col_ptrs,
                )
            except Exception as e:
                print("=== Import/Export planner: failed to tag A3OB import ===")
                print(f"{_module_name} -> {_fmt_exc(e)}")

            try:
                scene = getattr(context, "scene", None)
                settings = getattr(scene, "cray_ie_settings", None) if scene is not None else None
                _planner_add_import_file(settings, filepath)
            except Exception as e:
                print("=== Import/Export planner: failed to add A3OB import to planner ===")
                print(f"{_module_name} -> {_fmt_exc(e)}")

            try:
                show_materials, keep_converted = _get_import_preview_settings(context, operator)
                operator_loads_textures = False
                if hasattr(operator, "load_textures"):
                    try:
                        operator_loads_textures = bool(getattr(operator, "load_textures"))
                    except Exception:
                        operator_loads_textures = False
                if operator_loads_textures and not keep_converted:
                    return lod_objects
                stats = _postprocess_imported_material_previews(
                    context,
                    lod_objects or [],
                    show_materials=show_materials,
                    keep_converted_textures=keep_converted,
                )
                _log_import_preview_summary(filepath, stats)
            except Exception as e:
                print("=== Import/Export planner: failed to build material previews ===")
                print(f"{_module_name} -> {_fmt_exc(e)}")

            return lod_objects

        mod.read_file = _wrapped_read_file
        _A3OB_IMPORT_READ_FILE_PATCHES.append((mod, original_read_file))


def _unpatch_a3ob_import_read_file():
    while _A3OB_IMPORT_READ_FILE_PATCHES:
        mod, original_read_file = _A3OB_IMPORT_READ_FILE_PATCHES.pop()
        try:
            mod.read_file = original_read_file
        except Exception:
            pass


def _ensure_a3ob_import_patch_timer():
    if _A3OB_IMPORT_READ_FILE_PATCHES:
        return None

    _patch_a3ob_import_read_file()
    if _A3OB_IMPORT_READ_FILE_PATCHES:
        return None

    return 2.0

class CRAY_PG_IEFileItem(PropertyGroup):
    path: StringProperty(name="File", default="", subtype="FILE_PATH")

class CRAY_PG_IEPlannerSettings(PropertyGroup):
    import_files: CollectionProperty(type=CRAY_PG_IEFileItem)
    import_active_index: IntProperty(default=0)
    quick_add_p3d_name: StringProperty(
        name="P3D Name",
        default="",
        description="Type a model name like darkvalley_brick_farm_a and add the matching .p3d from NH_Objects",
    )
    quick_add_search_root: StringProperty(
        name="NH_Objects Root",
        default=r"P:\NH_Objects",
        subtype="DIR_PATH",
        description="Root folder where the addon searches for .p3d files by name",
    )
    import_show_materials: BoolProperty(
        name="Show material textures after import",
        default=True,
        description="Create Image Texture preview nodes for imported A3OB materials so textures are visible in Blender immediately",
    )
    import_keep_converted_textures: BoolProperty(
        name="Keep converted .png next to source .paa",
        default=False,
        description="Save Blender-friendly .png copies near imported .paa files and reuse them on later imports instead of converting again",
    )
    disable_collections_after_import: BoolProperty(
        name="Disable all collections after import",
        default=False,
        description="After batch import finishes, disable all collections in current View Layer",
    )
    disable_mode: EnumProperty(
        name="Disable mode",
        items=(
            ("HIDE", "Hide viewport", "Set Collection.hide_viewport and hide_render"),
            ("EXCLUDE", "Exclude from View Layer", "Set LayerCollection.exclude"),
        ),
        default="HIDE",
    )
    export_mode: EnumProperty(
        name="Export Target",
        items=(
            ("SOURCE", "Back to source", "Export each collection back to its imported .p3d path"),
            ("CUSTOM_DIR", "Custom folder", "Export each collection to a selected folder"),
        ),
        default="SOURCE",
    )
    export_directory: StringProperty(
        name="Export Folder",
        default="",
        subtype="DIR_PATH",
    )
    export_create_bak: BoolProperty(
        name="Create .bak before export",
        default=True,
    )
    export_only_p3d_named: BoolProperty(
        name="Only .p3d-like root collections",
        default=True,
        description="Skip root collections that do not look like imported .p3d collections",
    )
    export_only_split_parts: BoolProperty(
        name="Only split part collections (_01, _02, ...)",
        default=False,
        description="Export only root collections whose names end with a numeric split suffix like _01.p3d",
    )
    export_force_all_lods: BoolProperty(
        name="Force export all LODs (skip validation)",
        default=False,
        description=(
            "Workaround for A3OB exporter: temporarily bypass LOD validation "
            "during batch export to prevent Resolution LODs from being skipped"
        ),
    )

class CRAY_OT_IEFilePathTooltip(Operator):
    bl_idname = "cray.ie_file_path_tooltip"
    bl_label = "Import File"
    bl_options = {"INTERNAL"}

    filepath: StringProperty(options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        del context
        return _norm_path(getattr(properties, "filepath", "") or "")

    def execute(self, context):
        del context
        return {"FINISHED"}


class CRAY_UL_IEFiles(UIList):
    bl_idname = "CRAY_UL_ie_files"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        del context, data, icon, active_data, active_propname, index
        filepath = _norm_path(item.path)
        label = os.path.basename(filepath) or "<empty>"
        layout.label(text=label, icon="FILE")

class CRAY_OT_IE_AddFiles(Operator):
    bl_idname = "cray.ie_add_files"
    bl_label = "Add Files"
    bl_options = {"REGISTER", "UNDO"}

    files: CollectionProperty(type=OperatorFileListElement)
    directory: StringProperty(subtype="DIR_PATH")
    filter_glob: StringProperty(default="*.p3d", options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        st = context.scene.cray_ie_settings
        added = 0
        skipped = 0
        dir_abs = bpy.path.abspath(self.directory) if self.directory else ""

        for f in self.files:
            fp = os.path.join(dir_abs, f.name) if dir_abs else f.name
            fp = bpy.path.abspath(fp)
            if not fp:
                continue
            if _planner_add_import_file(st, fp):
                added += 1
            else:
                skipped += 1

        if added == 0:
            if skipped > 0:
                self.report({"WARNING"}, "All selected files are already in the planner")
            else:
                self.report({"WARNING"}, "No files added")
        else:
            msg = f"Added {added} file(s)"
            if skipped > 0:
                msg += f", skipped {skipped} duplicate(s)"
            self.report({"INFO"}, msg)
        return {"FINISHED"}


class CRAY_OT_IE_AddByName(Operator):
    bl_idname = "cray.ie_add_by_name"
    bl_label = "Add By Name"
    bl_description = "Find a .p3d in NH_Objects by model name and add it to the import list"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_ie_settings

        model_name = (getattr(st, "quick_add_p3d_name", "") or "").strip()
        model_key = _normalize_p3d_lookup_key(model_name)
        if not model_key:
            self.report({"ERROR"}, "Type a .p3d name like darkvalley_brick_farm_a")
            return {"CANCELLED"}

        search_root = bpy.path.abspath(getattr(st, "quick_add_search_root", "") or "")
        search_root = os.path.abspath(search_root) if search_root else ""
        if not search_root or not os.path.isdir(search_root):
            self.report({"ERROR"}, "NH_Objects root folder was not found")
            return {"CANCELLED"}

        existing_root = _find_existing_scene_p3d_root(context.scene, model_key)
        if existing_root is not None:
            self.report({"WARNING"}, f"{existing_root.name} is already imported in the scene")
            return {"CANCELLED"}

        matches = _find_p3d_paths_by_name(search_root, model_key)
        if not matches:
            self.report({"ERROR"}, f"{_display_p3d_name(model_key)} was not found in {search_root}")
            return {"CANCELLED"}

        chosen = matches[0]
        added = _planner_add_import_file(st, chosen)
        st.quick_add_p3d_name = model_key

        if not added:
            self.report({"WARNING"}, f"{os.path.basename(chosen)} is already in the import list")
            return {"CANCELLED"}

        if len(matches) > 1:
            print("=== Batch Import: multiple .p3d matches found ===")
            print(f"Requested: {model_key}")
            for path in matches:
                print(path)
            self.report(
                {"WARNING"},
                (
                    f"Added {os.path.basename(chosen)}; found {len(matches)} matches, "
                    f"used the first one (see System Console)"
                ),
            )
            return {"FINISHED"}

        self.report({"INFO"}, f"Added {os.path.basename(chosen)} to the import list")
        return {"FINISHED"}

class CRAY_OT_IE_RemoveFile(Operator):
    bl_idname = "cray.ie_remove_file"
    bl_label = "Remove"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_ie_settings
        i = st.import_active_index
        if i < 0 or i >= len(st.import_files):
            self.report({"WARNING"}, "Nothing to remove")
            return {"CANCELLED"}
        st.import_files.remove(i)
        st.import_active_index = max(0, min(i, len(st.import_files) - 1))
        return {"FINISHED"}

class CRAY_OT_IE_ClearFiles(Operator):
    bl_idname = "cray.ie_clear_files"
    bl_label = "Clear"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_ie_settings
        n = len(st.import_files)
        st.import_files.clear()
        st.import_active_index = 0
        self.report({"INFO"}, f"Cleared {n} file(s)")
        return {"FINISHED"}

class CRAY_OT_IE_ImportBatch(Operator):
    bl_idname = "cray.ie_import_batch"
    bl_label = "Batch Import (A3OB)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_ie_settings
        if len(st.import_files) == 0:
            self.report({"ERROR"}, "Import list is empty")
            return {"CANCELLED"}
        if not _has_any_a3ob_import_ops():
            self.report({"ERROR"}, "Arma 3 Object Builder import operators not found")
            return {"CANCELLED"}

        imported = 0
        skipped_existing = []
        failed = []
        used_op = None

        for it in st.import_files:
            fp = bpy.path.abspath(it.path)
            existing_root = _find_existing_scene_p3d_root(context.scene, fp)
            if existing_root is not None:
                skipped_existing.append(f"{os.path.basename(fp)} -> already imported as {existing_root.name}")
                continue
            if not fp or not os.path.isfile(fp):
                failed.append(f"{it.path} -> file not found")
                continue

            pre_obj_ptrs = {o.as_pointer() for o in bpy.data.objects}
            pre_col_ptrs = {c.as_pointer() for c in bpy.data.collections}
            with _suppress_a3ob_import_tracking():
                res, op_id, err = _call_first_available(
                    _A3OB_IMPORT_CANDIDATES,
                    filepath=fp,
                    load_textures=False,
                )
            if op_id:
                used_op = op_id
            if res is None:
                failed.append(f"{fp} -> {_fmt_exc(err) if err else 'unknown error'}")
            else:
                imported += 1
                imported_objs = [o for o in bpy.data.objects if o.as_pointer() not in pre_obj_ptrs]
                _tag_import_source_on_imported_data(
                    context=context,
                    filepath=fp,
                    imported_objs=imported_objs,
                    pre_collection_ptrs=pre_col_ptrs,
                )
                stats = _postprocess_imported_material_previews(
                    context,
                    imported_objs,
                    show_materials=st.import_show_materials,
                    keep_converted_textures=st.import_keep_converted_textures,
                )
                _log_import_preview_summary(fp, stats)

        if st.disable_collections_after_import:
            _disable_all_collections_in_view_layer(context, st.disable_mode)

        if skipped_existing:
            print("=== Batch Import: Skipped already imported ===")
            for item in skipped_existing:
                print(item)

        if failed:
            print("=== Batch Import: Failures ===")
            for f in failed:
                print(f)
            msg = f"Imported {imported}, skipped existing {len(skipped_existing)}, failed {len(failed)}"
            self.report({"WARNING"}, msg + " (see System Console)")
        else:
            msg = f"Imported {imported} file(s), skipped existing {len(skipped_existing)}"
            self.report({"INFO"}, msg + (f" via {used_op}" if used_op else ""))
        return {"FINISHED"}

class CRAY_OT_ModelSplitTransferSelectedToTargetCategory(Operator):
    bl_idname = "cray.model_split_transfer_to_target_category"
    bl_label = "Move/Copy Selected To Target Category"
    bl_options = {"REGISTER", "UNDO"}

    transfer_mode: EnumProperty(
        name="Action",
        items=(
            ("MOVE", "Move", "Move selected mesh objects into the target part model"),
            ("COPY", "Copy", "Copy selected mesh objects into the target part model"),
        ),
        default="MOVE",
    )

    def execute(self, context):
        st = context.scene.cray_model_split_settings
        requested_mode = str(getattr(self, "transfer_mode", "MOVE") or "MOVE").upper()
        if requested_mode != "COPY":
            requested_mode = "MOVE"

        try:
            source_root, selected, separated_from_edit = _model_split_source_and_objects_for_transfer(
                context,
                st,
                copy_selection=(requested_mode == "COPY"),
            )
            target_root = _resolve_model_split_target_part_root(context, st, source_root, force_new=False)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        effective_mode = requested_mode
        if separated_from_edit:
            effective_mode = "MOVE"

        if effective_mode == "MOVE":
            _prepare_moved_objects_for_named_split(selected)

        created = []
        failed = []
        copies_by_source = {}
        used_categories = set()

        for src_obj in selected:
            dup_obj = None
            try:
                category_token = _model_split_category_for_object(src_obj)
                dest_leaf = _ensure_model_split_target_category_collection(target_root, category_token)
                if dest_leaf is None:
                    failed.append(f"{src_obj.name} -> failed to create A3OB category collection")
                    continue

                if effective_mode == "COPY":
                    dup_obj = _duplicate_object_for_split(src_obj)
                    if dup_obj is None:
                        failed.append(f"{src_obj.name} -> failed to duplicate object")
                        continue
                    _set_model_split_target_lod_a3ob_props(dup_obj, category_token)
                    dest_leaf.objects.link(dup_obj)
                    copies_by_source[src_obj] = dup_obj
                    used_categories.add(_model_split_target_category_label(category_token))
                    created.append(dup_obj)
                else:
                    _move_object_to_collection(src_obj, dest_leaf, unlink_roots=source_root)
                    _set_model_split_target_lod_a3ob_props(src_obj, category_token)
                    used_categories.add(_model_split_target_category_label(category_token))
                    created.append(src_obj)
                    if not _same_id_data(source_root, target_root):
                        lingering = _direct_object_collection_names_under_root(source_root, src_obj)
                        if lingering:
                            preview = ", ".join(lingering[:5])
                            if len(lingering) > 5:
                                preview += ", ..."
                            failed.append(f"{src_obj.name} -> moved but still linked in source collection(s): {preview}")
            except Exception as e:
                failed.append(f"{src_obj.name} -> {_fmt_exc(e)}")
                if effective_mode == "COPY":
                    try:
                        if dup_obj is not None and bpy.data.objects.get(dup_obj.name) is not None and dup_obj.users == 0:
                            bpy.data.objects.remove(dup_obj)
                    except Exception:
                        pass

        if effective_mode == "COPY":
            _rewire_split_copy_object_refs(copies_by_source)

        _focus_created_split_objects(context, target_root, created)
        planner_added, planner_path = _add_model_split_part_to_planner(context, target_root)

        if failed:
            print("=== Model Split Target Category: Failures ===")
            for item in failed:
                print(item)

        if not created:
            self.report({"ERROR"}, "No mesh objects were moved or copied")
            return {"CANCELLED"}

        action_word = "Copied" if requested_mode == "COPY" else "Moved"
        if separated_from_edit and requested_mode == "MOVE":
            action_word = "Separated and moved"
        elif separated_from_edit and requested_mode == "COPY":
            action_word = "Copied selected geometry"
        category_label = ", ".join(sorted(used_categories, key=str.lower)) if used_categories else "A3OB category"
        msg = f"{action_word} {len(created)} object(s) to {target_root.name} > {category_label}"
        if planner_path:
            msg += ", added to Import/Export list" if planner_added else ", already in Import/Export list"
        if failed:
            self.report({"WARNING"}, msg + f", failed {len(failed)} (see System Console)")
        else:
            self.report({"INFO"}, msg)
        return {"FINISHED"}

class CRAY_PG_AssetProxySettings(PropertyGroup):
    target_object: PointerProperty(name="Target Object", type=bpy.types.Object)
    delete_originals: BoolProperty(
        name="Delete originals after convert",
        default=True,
        description="Remove selected placed objects after proxy creation",
    )


_NH_TEMP_ASSET_LIBRARY_NAME = "NH Temp Asset Library"
_NH_TEMP_ASSET_SCENE_NAME = "NH Asset Library Scene"

def _iter_p3d_files_in_folder(folder_abs: str):
    out = []
    for root, _, files in os.walk(folder_abs):
        for fn in files:
            if fn.lower().endswith('.p3d'):
                out.append(os.path.join(root, fn))
    out.sort(key=lambda x: x.lower())
    return out

def _ensure_temp_asset_scene():
    scenes = getattr(bpy.data, "scenes", None)
    if scenes is None:
        raise RuntimeError("Blender scenes are not available right now")
    scene = scenes.get(_NH_TEMP_ASSET_SCENE_NAME)
    if scene is None:
        scene = scenes.new(_NH_TEMP_ASSET_SCENE_NAME)
    return scene


def _ensure_temp_asset_library_root(context):
    col = bpy.data.collections.get(_NH_TEMP_ASSET_LIBRARY_NAME)
    if col is None:
        col = bpy.data.collections.new(_NH_TEMP_ASSET_LIBRARY_NAME)

    asset_scene = _ensure_temp_asset_scene()

    for scene in _iter_safe_scenes():
        try:
            if scene != asset_scene and any(ch == col for ch in scene.collection.children):
                scene.collection.children.unlink(col)
        except Exception:
            pass

    try:
        if all(ch != col for ch in asset_scene.collection.children):
            asset_scene.collection.children.link(col)
    except Exception:
        pass

    try:
        col.hide_viewport = True
        col.hide_render = True
    except Exception:
        pass
    return col

def _safe_unlink_collection_from_parents(col):
    scene = bpy.context.scene
    if scene is not None:
        for parent in [scene.collection] + list(bpy.data.collections):
            try:
                if any(ch == col for ch in parent.children):
                    parent.children.unlink(col)
            except Exception:
                pass

def _remove_collection_tree(col):
    for child in list(col.children):
        _remove_collection_tree(child)
    for obj in list(col.objects):
        try:
            col.objects.unlink(obj)
        except Exception:
            pass
        if bpy.data.objects.get(obj.name) is not None and obj.users == 0:
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:
                pass
    _safe_unlink_collection_from_parents(col)
    if bpy.data.collections.get(col.name) is not None:
        try:
            bpy.data.collections.remove(col)
        except Exception:
            pass

def _clear_temp_asset_library(context):
    col = bpy.data.collections.get(_NH_TEMP_ASSET_LIBRARY_NAME)
    if col is None:
        return 0
    child_count = len(list(_iter_collection_tree(col)))
    _remove_collection_tree(col)
    scenes = getattr(bpy.data, "scenes", None)
    asset_scene = scenes.get(_NH_TEMP_ASSET_SCENE_NAME) if scenes is not None else None
    if asset_scene is not None:
        try:
            if len(asset_scene.collection.children) == 0:
                scenes.remove(asset_scene)
        except Exception:
            pass
    return child_count

def _generate_asset_preview_safe(id_data):
    if id_data is None:
        return
    try:
        gen = getattr(id_data, "asset_generate_preview", None)
        if callable(gen):
            gen()
            return
    except Exception:
        pass
    try:
        with bpy.context.temp_override(id=id_data):
            bpy.ops.ed.lib_id_generate_preview()
    except Exception:
        try:
            override = bpy.context.copy()
            override["id"] = id_data
            bpy.ops.ed.lib_id_generate_preview(override)
        except Exception:
            pass


def _mark_object_as_asset_safe(obj):
    if obj is None:
        return
    try:
        obj.asset_mark()
    except Exception:
        pass
    _generate_asset_preview_safe(obj)


def _mark_collection_as_asset_safe(collection, catalog_id=None):
    if collection is None:
        return
    try:
        collection.asset_mark()
    except Exception:
        pass
    if catalog_id:
        try:
            asset_data = getattr(collection, "asset_data", None)
            if asset_data is not None:
                asset_data.catalog_id = str(catalog_id)
            else:
                collection["catalog_id"] = str(catalog_id)
        except Exception:
            pass
    _generate_asset_preview_safe(collection)


def _mark_objects_in_collection_as_assets_safe(collection):
    if collection is None:
        return
    seen = set()
    for obj in _collect_collection_objects_recursive(collection):
        if obj is None:
            continue
        ptr = obj.as_pointer()
        if ptr in seen:
            continue
        seen.add(ptr)
        if obj.type not in {"MESH", "EMPTY", "CURVE", "ARMATURE"}:
            continue
        _mark_object_as_asset_safe(obj)

def _move_import_result_into_asset_library(context, filepath, pre_obj_ptrs, pre_col_ptrs, asset_root, catalog_id=None):
    imported_objs = [o for o in bpy.data.objects if o.as_pointer() not in pre_obj_ptrs]
    _tag_import_source_on_imported_data(
        context=context,
        filepath=filepath,
        imported_objs=imported_objs,
        pre_collection_ptrs=pre_col_ptrs,
    )

    new_cols = [c for c in bpy.data.collections if c.as_pointer() not in pre_col_ptrs]
    candidate_cols = []
    for col in new_cols:
        if col == asset_root:
            continue
        if not _collection_has_any_object_ptr(col, {o.as_pointer() for o in imported_objs}):
            continue
        candidate_cols.append(col)

    moved = 0
    if candidate_cols:
        root_candidates = []
        candidate_ptrs = {c.as_pointer() for c in candidate_cols}
        for col in candidate_cols:
            is_child = False
            for other in candidate_cols:
                if other == col:
                    continue
                if _find_collection_path(other, col.as_pointer()):
                    is_child = True
                    break
            if not is_child:
                root_candidates.append(col)
        for col in root_candidates:
            try:
                _safe_unlink_collection_from_parents(col)
            except Exception:
                pass
            try:
                if all(ch != col for ch in asset_root.children):
                    asset_root.children.link(col)
            except Exception:
                pass
            try:
                col[_IE_SOURCE_PATH_KEY] = _norm_path(bpy.path.abspath(filepath))
            except Exception:
                pass
            _mark_collection_as_asset_safe(col, catalog_id=catalog_id)
            moved += 1
    else:
        name = os.path.splitext(os.path.basename(filepath))[0]
        col = bpy.data.collections.new(name)
        asset_root.children.link(col)
        for obj in imported_objs:
            for parent in list(obj.users_collection):
                try:
                    parent.objects.unlink(obj)
                except Exception:
                    pass
            try:
                col.objects.link(obj)
            except Exception:
                pass
        try:
            col[_IE_SOURCE_PATH_KEY] = _norm_path(bpy.path.abspath(filepath))
        except Exception:
            pass
        _mark_collection_as_asset_safe(col, catalog_id=catalog_id)
        moved = 1

    return moved, len(imported_objs)


class CRAY_PG_AssetLibrarySettings(PropertyGroup):
    folder: StringProperty(name="P3D Folder", default="", subtype="DIR_PATH")
    import_first_lod_only: BoolProperty(
        name="Import first LOD only",
        default=True,
    )
    clear_previous_temp_library: BoolProperty(
        name="Clear previous temp library",
        default=True,
    )

class CRAY_OT_AssetLibraryBuildFromFolder(Operator):
    bl_idname = "cray.asset_library_build_folder"
    bl_label = "Build From Folder"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_asset_library_settings
        if not _has_any_a3ob_import_ops():
            self.report({"ERROR"}, "Arma 3 Object Builder import operators not found")
            return {"CANCELLED"}
        folder_abs = bpy.path.abspath(st.folder)
        if not folder_abs or not os.path.isdir(folder_abs):
            self.report({"ERROR"}, "P3D folder not found")
            return {"CANCELLED"}

        files = _iter_p3d_files_in_folder(folder_abs)
        if not files:
            self.report({"ERROR"}, "No .p3d files found in folder")
            return {"CANCELLED"}

        return _build_temp_asset_library_from_paths(self, context, files)

class CRAY_OT_AssetLibraryBuildFromFiles(Operator):
    bl_idname = "cray.asset_library_build_files"
    bl_label = "Build From Files"
    bl_options = {"REGISTER", "UNDO"}

    files: CollectionProperty(type=OperatorFileListElement)
    directory: StringProperty(subtype="DIR_PATH")
    filter_glob: StringProperty(default="*.p3d", options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        if not _has_any_a3ob_import_ops():
            self.report({"ERROR"}, "Arma 3 Object Builder import operators not found")
            return {"CANCELLED"}
        dir_abs = bpy.path.abspath(self.directory) if self.directory else ""
        files = []
        seen = set()
        for item in self.files:
            fp = os.path.join(dir_abs, item.name) if dir_abs else item.name
            fp = os.path.abspath(bpy.path.abspath(fp))
            fp_key = os.path.normcase(fp)
            if fp and os.path.isfile(fp) and fp.lower().endswith('.p3d') and fp_key not in seen:
                seen.add(fp_key)
                files.append(fp)
        if not files:
            self.report({"ERROR"}, "No .p3d files selected")
            return {"CANCELLED"}
        return _build_temp_asset_library_from_paths(self, context, files)

class CRAY_OT_AssetLibraryClear(Operator):
    bl_idname = "cray.asset_library_clear"
    bl_label = "Clear Temp Asset Library"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed = _clear_temp_asset_library(context)
        self.report({"INFO"}, f"Cleared temp asset library ({removed} collection(s))")
        return {"FINISHED"}



def _get_asset_browser_space_from_area(area):
    if area is None:
        return None
    try:
        for space in area.spaces:
            if getattr(space, "type", None) == "FILE_BROWSER":
                return space
    except Exception:
        pass
    return None


def _ensure_asset_catalog_and_activate(context, area, catalog_name=_ASSET_CATALOG_NAME, preferred_catalog_id=None):
    if area is None:
        return None
    space = _get_asset_browser_space_from_area(area)
    if space is None:
        return None

    params = getattr(space, "params", None)
    if params is not None:
        try:
            params.asset_library_reference = "LOCAL"
        except Exception:
            pass

    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window else None
    region = next((r for r in getattr(area, "regions", []) if getattr(r, "type", None) == "WINDOW"), None)

    try:
        override = context.copy()
        override["window"] = window
        override["screen"] = screen
        override["area"] = area
        if region is not None:
            override["region"] = region
        with context.temp_override(**{k: v for k, v in override.items() if v is not None}):
            for kwargs in ({}, {"parent_path": catalog_name}):
                try:
                    bpy.ops.asset.catalog_new(**kwargs)
                    break
                except Exception:
                    pass
            try:
                bpy.ops.asset.catalogs_save()
            except Exception:
                pass
    except Exception:
        pass

    catalog_id = str(preferred_catalog_id or "")
    if not catalog_id and params is not None:
        try:
            current_catalog_id = str(getattr(params, "catalog_id", "") or "")
            if current_catalog_id:
                catalog_id = current_catalog_id
        except Exception:
            pass

    if not catalog_id:
        catalog_id = _ASSET_CATALOG_FALLBACK_ID

    if params is not None:
        for attr_name, attr_value in (
            ("catalog_id", str(catalog_id)),
            ("catalog_path", str(catalog_name)),
            ("display_type", "THUMBNAIL"),
            ("asset_library_reference", "LOCAL"),
            ("import_method", "APPEND_REUSE"),
        ):
            try:
                setattr(params, attr_name, attr_value)
            except Exception:
                pass

    try:
        area.tag_redraw()
    except Exception:
        pass
    return str(catalog_id)


def _switch_bottom_area_to_asset_browser(context):
    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window else None
    if screen is None:
        return False

    ignore_types = {"TOPBAR", "STATUSBAR", "PREFERENCES"}
    areas = [a for a in screen.areas if getattr(a, "type", None) not in ignore_types]
    if not areas:
        return False

    def _priority(area):
        tp = getattr(area, "type", "")
        if tp == "TIMELINE":
            return 0
        if tp in {"DOPESHEET_EDITOR", "NLA_EDITOR", "GRAPH_EDITOR"}:
            return 1
        if tp == "FILE_BROWSER":
            return 2
        return 3

    # Pick the lowest area. For equal y, prefer timeline/animation editors.
    area = sorted(areas, key=lambda a: (a.y, _priority(a), -a.width, -a.height))[0]

    try:
        area.type = "FILE_BROWSER"
    except Exception:
        # Sometimes direct area-type switching does not work on the first try.
        try:
            override = context.copy()
            override["window"] = window
            override["screen"] = screen
            override["area"] = area
            override["region"] = next((r for r in area.regions if r.type == "WINDOW"), None)
            with context.temp_override(**{k: v for k, v in override.items() if v is not None}):
                bpy.ops.screen.space_type_set_or_cycle(space_type="FILE_BROWSER")
        except Exception:
            return False

    ok = False
    try:
        area.ui_type = "ASSETS"
        ok = True
    except Exception:
        pass

    for space in area.spaces:
        try:
            if getattr(space, "type", None) != "FILE_BROWSER":
                continue
            try:
                space.browse_mode = "ASSETS"
            except Exception:
                pass
            params = getattr(space, "params", None)
            if params is not None:
                try:
                    params.display_type = "THUMBNAIL"
                except Exception:
                    pass
                for attr_name, attr_value in (
                    ("asset_library_reference", "LOCAL"),
                    ("catalog_id", ""),
                    ("import_method", "APPEND_REUSE"),
                ):
                    try:
                        setattr(params, attr_name, attr_value)
                    except Exception:
                        pass
            ok = True
        except Exception:
            pass

    try:
        for region in area.regions:
            region.tag_redraw()
        area.tag_redraw()
    except Exception:
        pass
    return area if ok else None

def _build_temp_asset_library_from_paths(op, context, filepaths):
    st = context.scene.cray_asset_library_settings

    unique_filepaths = []
    seen_paths = set()
    for fp in filepaths:
        fp_abs = os.path.abspath(bpy.path.abspath(fp))
        fp_key = os.path.normcase(fp_abs)
        if fp_key in seen_paths:
            continue
        seen_paths.add(fp_key)
        unique_filepaths.append(fp_abs)
    filepaths = unique_filepaths

    if st.clear_previous_temp_library:
        _clear_temp_asset_library(context)

    asset_root = _ensure_temp_asset_library_root(context)
    asset_browser_area = _switch_bottom_area_to_asset_browser(context)
    asset_catalog_id = _ensure_asset_catalog_and_activate(context, asset_browser_area, _ASSET_CATALOG_NAME)
    imported = 0
    moved_collections = 0
    failed = []

    for fp in filepaths:
        pre_obj_ptrs = {o.as_pointer() for o in bpy.data.objects}
        pre_col_ptrs = {c.as_pointer() for c in bpy.data.collections}
        with _suppress_a3ob_import_tracking():
            res, op_id, err = _call_first_available(
                _A3OB_IMPORT_CANDIDATES,
                filepath=fp,
                first_lod_only=st.import_first_lod_only,
                absolute_paths=True,
                enclose=True,
                groupby="TYPE",
                additional_data_allowed=True,
                additional_data={"PROPS", "SELECTIONS"},
                validate_meshes=False,
                proxy_action="SEPARATE",
                translate_selections=False,
                cleanup_empty_selections=False,
                load_textures=False,
            )
        if res is None:
            failed.append(f"{os.path.basename(fp)}: {_fmt_exc(err) if err else 'import failed'}")
            continue
        imported += 1
        moved, _ = _move_import_result_into_asset_library(context, fp, pre_obj_ptrs, pre_col_ptrs, asset_root, catalog_id=asset_catalog_id)
        moved_collections += moved

    if failed:
        print('=== P3D Asset Library: Failures ===')
        for item in failed:
            print(item)

    if imported == 0:
        op.report({"ERROR"}, "No assets imported (see System Console)")
        return {"CANCELLED"}

    switched_to_assets = asset_browser_area is not None
    if asset_browser_area is not None:
        _ensure_asset_catalog_and_activate(context, asset_browser_area, _ASSET_CATALOG_NAME, preferred_catalog_id=asset_catalog_id)

    msg = f"Imported {imported} file(s), asset entries: {moved_collections}"
    if switched_to_assets:
        msg += ", Asset Browser opened below"

    if failed:
        op.report({"WARNING"}, msg + f", failed: {len(failed)}")
    else:
        op.report({"INFO"}, msg)
    return {"FINISHED"}

class CRAY_OT_ConvertSelectedToProxies(Operator):
    bl_idname = "cray.convert_selected_to_proxies"
    bl_label = "Convert Selected Assets To Proxies"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_asset_proxy_settings
        target_obj = _pick_proxy_target_object(context, st.target_object)
        if target_obj is None or target_obj.type != "MESH":
            self.report({"ERROR"}, "Target object must be a mesh")
            return {"CANCELLED"}

        selected = [o for o in context.selected_objects if o != target_obj]
        if not selected:
            self.report({"ERROR"}, "Select placed asset objects together with target object")
            return {"CANCELLED"}

        if context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception as e:
                self.report({"ERROR"}, f"Failed to switch to Object Mode: {_fmt_exc(e)}")
                return {"CANCELLED"}

        target_collection = None
        if target_obj.users_collection:
            target_collection = target_obj.users_collection[0]
        else:
            target_collection = context.scene.collection

        created = 0
        removed = 0
        skipped = []
        next_index = _next_proxy_index_for_parent(target_obj)
        to_remove = []

        for obj in selected:
            src = _resolve_object_source_p3d(obj)
            if not src:
                skipped.append(f"{obj.name}: no source .p3d path")
                continue

            proxy_mesh = get_proxy_mesh()
            proxy_obj = bpy.data.objects.new(f"proxy_{obj.name}", proxy_mesh)
            target_collection.objects.link(proxy_obj)
            _build_proxy_from_object_instance(proxy_obj, obj, target_obj, next_index)
            try:
                set_a3ob_proxy_properties(proxy_obj, src, next_index)
            except Exception as e:
                try:
                    bpy.data.objects.remove(proxy_obj, do_unlink=True)
                except Exception:
                    pass
                skipped.append(f"{obj.name}: {_fmt_exc(e)}")
                continue

            created += 1
            next_index += 1
            if st.delete_originals:
                to_remove.append(obj)

        for obj in sorted(to_remove, key=_obj_depth, reverse=True):
            if bpy.data.objects.get(obj.name) is None:
                continue
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
                removed += 1
            except Exception as e:
                skipped.append(f"{obj.name}: delete failed: {_fmt_exc(e)}")

        if skipped:
            print("=== Convert Selected To Proxies: Skipped ===")
            for item in skipped:
                print(item)

        if created == 0:
            self.report({"ERROR"}, "No proxies created (see System Console)")
            return {"CANCELLED"}

        msg = f"Created {created} proxy(s) for '{target_obj.name}'"
        if st.delete_originals:
            msg += f", removed {removed} original(s)"
        if skipped:
            msg += f", skipped {len(skipped)} (see System Console)"
            self.report({"WARNING"}, msg)
        else:
            self.report({"INFO"}, msg)
        return {"FINISHED"}


def _repair_invalid_a3ob_selection_links(obj):
    if obj is None or obj.type != "MESH" or obj.data is None:
        raise RuntimeError("Target object must be a mesh")

    group_specs = sorted(
        [(int(vg.index), vg.name) for vg in obj.vertex_groups],
        key=lambda item: item[0],
    )
    if not group_specs:
        return {
            "invalid_refs_removed": 0,
            "zero_refs_removed": 0,
            "verts_touched": 0,
            "groups_rebuilt": 0,
            "reindexed_groups": False,
        }

    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        layer = bm.verts.layers.deform.verify()

        old_to_new = {old_idx: new_idx for new_idx, (old_idx, _name) in enumerate(group_specs)}
        valid_old_indices = set(old_to_new.keys())
        reindexed_groups = any(old_idx != new_idx for old_idx, new_idx in old_to_new.items())

        invalid_refs_removed = 0
        zero_refs_removed = 0
        verts_touched = 0
        dense_weights_by_vert = {}

        for vert in bm.verts:
            deform = vert[layer]
            items = list(deform.items())
            if not items:
                continue

            filtered = {}
            changed = False
            for idx, weight in items:
                idx = int(idx)
                weight = float(weight)
                if idx not in valid_old_indices:
                    invalid_refs_removed += 1
                    changed = True
                    continue
                if weight <= 0.0:
                    zero_refs_removed += 1
                    changed = True
                    continue
                new_idx = old_to_new[idx]
                prev = filtered.get(new_idx)
                if prev is None or weight > prev:
                    filtered[new_idx] = weight
                if new_idx != idx:
                    changed = True

            if filtered:
                dense_weights_by_vert[vert.index] = sorted(filtered.items())

            if not changed and not reindexed_groups:
                continue

            verts_touched += 1

        if invalid_refs_removed == 0 and zero_refs_removed == 0 and not reindexed_groups:
            return {
                "invalid_refs_removed": 0,
                "zero_refs_removed": 0,
                "verts_touched": 0,
                "groups_rebuilt": 0,
                "reindexed_groups": False,
            }

        existing_groups = list(obj.vertex_groups)
        for vg in existing_groups:
            obj.vertex_groups.remove(vg)

        rebuilt_groups = []
        for _old_idx, group_name in group_specs:
            rebuilt_groups.append(obj.vertex_groups.new(name=group_name))

        for vert_idx, weights in dense_weights_by_vert.items():
            for dense_idx, weight in weights:
                rebuilt_groups[dense_idx].add([vert_idx], weight, "REPLACE")

        return {
            "invalid_refs_removed": invalid_refs_removed,
            "zero_refs_removed": zero_refs_removed,
            "verts_touched": verts_touched,
            "groups_rebuilt": len(rebuilt_groups),
            "reindexed_groups": reindexed_groups,
        }
    finally:
        bm.free()


_FIX_LIST_LOD_KEY_ALIASES = {
    "geometry": "geometry",
    "viewgeometry": "geometryview",
    "geometryview": "geometryview",
    "firegeometry": "geometryfire",
    "geometryfire": "geometryfire",
}
_FIX_LIST_OBJECT_LOD_MAP = {
    "6": "geometry",
    "14": "geometryview",
    "15": "geometryfire",
}


def _normalize_fix_list_model_name(name: str) -> str:
    raw = (name or "").strip()
    if not raw:
        return ""
    raw = os.path.basename(raw.replace("\\", "/"))
    raw = _strip_blender_numeric_suffix(raw)
    return raw.lower()


def _normalize_fix_list_lod_key(name: str) -> str:
    key = re.sub(r"[^a-z]+", "", (name or "").strip().lower())
    return _FIX_LIST_LOD_KEY_ALIASES.get(key, "")


def _parse_fix_list_file(filepath: str):
    entries = {}
    current_model_key = ""

    with open(filepath, "r", encoding="utf-8-sig") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue

            if re.search(r"\.p3d\s*$", line, flags=re.IGNORECASE):
                display_name = os.path.basename(line.replace("\\", "/")).strip()
                model_key = _normalize_fix_list_model_name(display_name or line)
                if not model_key:
                    current_model_key = ""
                    continue
                current_model_key = model_key
                rec = entries.setdefault(
                    current_model_key,
                    {
                        "display_name": display_name or model_key,
                        "lod_groups": {},
                    },
                )
                if display_name:
                    rec["display_name"] = display_name
                continue

            if not current_model_key or ":" not in line:
                continue

            lod_raw, groups_raw = line.split(":", 1)
            lod_key = _normalize_fix_list_lod_key(lod_raw)
            if not lod_key:
                continue

            group_names = []
            for item in groups_raw.split(","):
                token = item.strip().rstrip(";").strip()
                if token:
                    group_names.append(token)

            if not group_names:
                continue

            lod_groups = entries[current_model_key]["lod_groups"].setdefault(lod_key, set())
            lod_groups.update(group_names)

    return entries


def _detect_fix_list_lod_key(obj) -> str:
    if obj is None or obj.type != "MESH":
        return ""

    if hasattr(obj, "a3ob_properties_object"):
        try:
            lod_token = str(getattr(obj.a3ob_properties_object, "lod", "") or "").strip()
        except Exception:
            lod_token = ""
        if lod_token in _FIX_LIST_OBJECT_LOD_MAP:
            return _FIX_LIST_OBJECT_LOD_MAP[lod_token]

    return _normalize_fix_list_lod_key(_strip_blender_numeric_suffix(getattr(obj, "name", "") or ""))


def _select_fix_list_groups_on_active_lod(context, obj, group_names):
    if obj is None or obj.type != "MESH" or obj.data is None:
        raise RuntimeError("Active object must be a mesh")

    group_lookup = {
        (vg.name or "").strip().lower(): vg
        for vg in obj.vertex_groups
        if (vg.name or "").strip()
    }

    matched_groups = []
    missing_groups = []
    target_group_indices = set()
    for group_name in group_names:
        key = (group_name or "").strip().lower()
        vg = group_lookup.get(key)
        if vg is None:
            missing_groups.append(group_name)
            continue
        matched_groups.append(vg.name)
        target_group_indices.add(int(vg.index))

    if not target_group_indices:
        return {
            "matched_groups": [],
            "missing_groups": missing_groups,
            "selected_vert_count": 0,
        }

    _activate_object_vertex_edit(context, obj)
    context.tool_settings.mesh_select_mode = (True, False, False)

    try:
        bpy.ops.mesh.reveal(select=False)
    except Exception:
        pass
    try:
        bpy.ops.mesh.select_all(action="DESELECT")
    except Exception:
        pass

    used_vertex_group_ops = False
    lower_lookup = {
        (vg.name or "").strip().lower(): vg
        for vg in obj.vertex_groups
        if (vg.name or "").strip()
    }
    for group_name in matched_groups:
        vg = lower_lookup.get((group_name or "").strip().lower())
        if vg is None:
            continue
        try:
            obj.vertex_groups.active_index = int(vg.index)
            bpy.ops.object.vertex_group_select()
            used_vertex_group_ops = True
        except Exception:
            used_vertex_group_ops = False
            break

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    layer = bm.verts.layers.deform.verify()

    selected_vert_count = sum(1 for vert in bm.verts if vert.select)
    if not used_vertex_group_ops or selected_vert_count == 0:
        selected_vert_count = 0
        for vert in bm.verts:
            deform = vert[layer]
            is_selected = any(float(deform.get(group_index, 0.0)) > 0.0 for group_index in target_group_indices)
            vert.select = is_selected
            if is_selected:
                selected_vert_count += 1

        for edge in bm.edges:
            edge.select = False
        for face in bm.faces:
            face.select = False

        bm.select_flush_mode()

    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    try:
        obj.update_from_editmode()
    except Exception:
        pass
    try:
        obj.data.update()
    except Exception:
        pass
    _tag_redraw_all_areas(context)

    return {
        "matched_groups": sorted(set(matched_groups), key=str.lower),
        "missing_groups": missing_groups,
        "selected_vert_count": selected_vert_count,
    }


def _delete_selected_components_keep_vertices(context, mesh):
    if mesh is None:
        raise RuntimeError("Mesh data is not available")

    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    explicit_faces = {face for face in bm.faces if face.is_valid and face.select}
    explicit_edges = {edge for edge in bm.edges if edge.is_valid and edge.select}
    selected_verts = {vert for vert in bm.verts if vert.is_valid and vert.select}

    for edge in explicit_edges:
        selected_verts.update(vert for vert in edge.verts if vert.is_valid)
    for face in explicit_faces:
        selected_verts.update(vert for vert in face.verts if vert.is_valid)

    if not selected_verts and not explicit_edges and not explicit_faces:
        raise RuntimeError("Select at least one vertex, edge or face in Edit Mode")

    faces_to_delete = {face for face in explicit_faces if face.is_valid}
    faces_to_delete.update(
        face
        for face in bm.faces
        if face.is_valid and all(vert in selected_verts for vert in face.verts)
    )

    edges_to_delete = {edge for edge in explicit_edges if edge.is_valid}
    edges_to_delete.update(
        edge
        for edge in bm.edges
        if edge.is_valid and all(vert in selected_verts for vert in edge.verts)
    )

    deleted_face_count = len(faces_to_delete)
    if faces_to_delete:
        bmesh.ops.delete(bm, geom=list(faces_to_delete), context="FACES")

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    valid_edges_to_delete = [edge for edge in edges_to_delete if edge.is_valid]
    deleted_edge_count = len(valid_edges_to_delete)
    if valid_edges_to_delete:
        bmesh.ops.delete(bm, geom=valid_edges_to_delete, context="EDGES")

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    kept_verts = [vert for vert in selected_verts if vert.is_valid]
    context.tool_settings.mesh_select_mode = (True, False, False)
    for face in bm.faces:
        face.select = False
    for edge in bm.edges:
        edge.select = False
    for vert in bm.verts:
        vert.select = False
    for vert in kept_verts:
        vert.select = True

    bm.select_flush_mode()
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=True)

    return {
        "deleted_faces": deleted_face_count,
        "deleted_edges": deleted_edge_count,
        "kept_verts": len(kept_verts),
    }


class CRAY_OT_OpenFixListFile(Operator):
    bl_idname = "cray.open_fix_list_file"
    bl_label = "Choose Fix List"
    bl_description = "Pick a structured .txt file with bad component names"
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(
        name="Fix List File",
        description="Choose a .txt file with bad component names per .p3d and LOD",
        subtype="FILE_PATH",
    )
    filter_glob: StringProperty(default="*.txt", options={"HIDDEN"})

    def invoke(self, context, event):
        del event

        ts = context.scene.cray_texreplace_settings
        current_path = bpy.path.abspath(getattr(ts, "fix_list_path", "") or "")
        if current_path and os.path.isfile(current_path):
            self.filepath = current_path
        else:
            blend_dir = bpy.path.abspath("//")
            if blend_dir and os.path.isdir(blend_dir):
                self.filepath = os.path.join(blend_dir, "")
            else:
                self.filepath = os.path.join(os.getcwd(), "")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings

        try:
            filepath = os.path.abspath(bpy.path.abspath(self.filepath or ""))
        except Exception as e:
            self.report({"ERROR"}, f"Could not resolve fix-list path: {_fmt_exc(e)}")
            return {"CANCELLED"}

        if not filepath or not os.path.isfile(filepath):
            self.report({"ERROR"}, "Choose an existing .txt file")
            return {"CANCELLED"}

        if os.path.splitext(filepath)[1].lower() != ".txt":
            self.report({"ERROR"}, "Choose a .txt file")
            return {"CANCELLED"}

        ts.fix_list_path = filepath
        self.report({"INFO"}, f"Fix list set: {os.path.basename(filepath)}")
        return {"FINISHED"}


class CRAY_OT_SelectFixListComponentsOnActiveLOD(Operator):
    bl_idname = "cray.select_fix_list_components_on_active_lod"
    bl_label = "Select Bad Components From List"
    bl_description = (
        "Read the structured fix-list .txt, match the active object's .p3d root collection name, "
        "and select bad component vertices for the active Geometry/View Geometry/Fire Geometry LOD"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings
        active_obj = context.view_layer.objects.active
        if active_obj is None or active_obj.type != "MESH" or active_obj.data is None:
            self.report({"ERROR"}, "Active object must be a mesh")
            return {"CANCELLED"}

        filepath = bpy.path.abspath(getattr(ts, "fix_list_path", "") or "")
        if not filepath:
            self.report({"ERROR"}, "Choose a fix-list .txt file first")
            return {"CANCELLED"}
        filepath = os.path.abspath(filepath)
        if not os.path.isfile(filepath):
            self.report({"ERROR"}, "Fix-list file does not exist")
            return {"CANCELLED"}

        root_collection = _find_p3d_root_collection_for_object(context, active_obj)
        if root_collection is None:
            self.report({"ERROR"}, "Active object is not inside a .p3d root collection")
            return {"CANCELLED"}

        lod_key = _detect_fix_list_lod_key(active_obj)
        if lod_key not in {"geometry", "geometryview", "geometryfire"}:
            self.report({"ERROR"}, "Active object must be Geometry, View Geometry or Fire Geometry")
            return {"CANCELLED"}

        model_key = _normalize_fix_list_model_name(getattr(root_collection, "name", "") or "")
        if not model_key:
            self.report({"ERROR"}, "Could not normalize the .p3d root collection name")
            return {"CANCELLED"}

        try:
            entries = _parse_fix_list_file(filepath)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to parse fix-list: {_fmt_exc(e)}")
            return {"CANCELLED"}

        entry = entries.get(model_key)
        if entry is None:
            self.report({"WARNING"}, f"No fix-list entry found for {root_collection.name}")
            return {"CANCELLED"}

        target_groups = sorted(entry.get("lod_groups", {}).get(lod_key, set()), key=str.lower)
        if not target_groups:
            lod_label = {
                "geometry": "Geometry",
                "geometryview": "View Geometry",
                "geometryfire": "Fire Geometry",
            }.get(lod_key, lod_key)
            self.report({"INFO"}, f"No bad components listed for {entry['display_name']} / {lod_label}")
            return {"FINISHED"}

        try:
            stats = _select_fix_list_groups_on_active_lod(context, active_obj, target_groups)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        matched_count = len(stats["matched_groups"])
        missing_count = len(stats["missing_groups"])
        selected_vert_count = int(stats["selected_vert_count"])

        if matched_count == 0:
            self.report({"WARNING"}, f"Listed groups were not found on {active_obj.name}")
            return {"CANCELLED"}

        msg = (
            f"{entry['display_name']} / {active_obj.name}: "
            f"matched {matched_count} group(s), selected {selected_vert_count} vertex/vertices"
        )
        if missing_count > 0:
            print("=== Fix List: Missing vertex groups ===")
            print(f"Model: {entry['display_name']}")
            print(f"LOD: {active_obj.name}")
            for group_name in stats["missing_groups"]:
                print(group_name)
            msg += f", missing {missing_count} group(s) (see System Console)"

        self.report({"INFO"}, msg)
        return {"FINISHED"}


class CRAY_OT_DeleteSelectedComponentsKeepVertices(Operator):
    bl_idname = "cray.delete_selected_components_keep_vertices"
    bl_label = "Delete Faces/Edges Keep Verts"
    bl_description = (
        "On the active mesh in Edit Mode, delete faces and edges belonging to the current selection "
        "while keeping the vertices"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return context.mode == "EDIT_MESH" and obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH" or obj.data is None:
            self.report({"ERROR"}, "Active object must be a mesh in Edit Mode")
            return {"CANCELLED"}

        try:
            stats = _delete_selected_components_keep_vertices(context, obj.data)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            (
                f"{obj.name}: deleted {stats['deleted_faces']} face(s) and "
                f"{stats['deleted_edges']} edge(s), kept {stats['kept_verts']} vertex/vertices"
            ),
        )
        return {"FINISHED"}


def _is_proxy_object_name(name: str) -> bool:
    return (name or "").strip().lower().startswith("proxy:")


def _is_a3ob_proxy_object(obj) -> bool:
    if obj is None or getattr(obj, "type", None) != "MESH":
        return False
    if _is_proxy_object_name(getattr(obj, "name", "")):
        return True
    try:
        return bool(getattr(obj.a3ob_properties_object_proxy, "is_a3_proxy", False))
    except Exception:
        return False


def _fix_proxy_triangle_mesh(obj):
    if obj is None or getattr(obj, "type", None) != "MESH" or obj.data is None:
        return None, "not a mesh"

    old_mesh = obj.data
    verts_count = len(old_mesh.vertices)
    faces_count = len(old_mesh.polygons)
    if verts_count != 3:
        return None, "not 3 verts"
    if faces_count == 1 and len(old_mesh.polygons[0].vertices) == 3:
        return None, "already ok"

    local_coords = [old_mesh.vertices[i].co.copy() for i in range(3)]
    old_materials = [mat for mat in old_mesh.materials]
    material_index = 0
    use_smooth = False
    if faces_count > 0:
        try:
            material_index = int(old_mesh.polygons[0].material_index)
            use_smooth = bool(old_mesh.polygons[0].use_smooth)
        except Exception:
            material_index = 0

    new_mesh = bpy.data.meshes.new(old_mesh.name)
    new_mesh.from_pydata(local_coords, [], [(0, 1, 2)])
    new_mesh.update()
    for mat in old_materials:
        new_mesh.materials.append(mat)
    if new_mesh.polygons:
        new_mesh.polygons[0].material_index = max(0, min(material_index, max(0, len(old_materials) - 1)))
        new_mesh.polygons[0].use_smooth = use_smooth
    obj.data = new_mesh
    return {
        "name": obj.name,
        "old_verts": verts_count,
        "old_faces": faces_count,
    }, ""


class CRAY_OT_FixProxyTriangleMeshes(Operator):
    bl_idname = "cray.fix_proxy_triangle_meshes"
    bl_label = "Fix Proxy Triangles"
    bl_description = (
        "Fix A3OB proxy mesh objects that have exactly 3 vertices but not exactly one triangular face"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        del context
        fixed = []
        skipped = []

        for obj in bpy.data.objects:
            if not _is_a3ob_proxy_object(obj):
                continue
            result, reason = _fix_proxy_triangle_mesh(obj)
            if result is not None:
                fixed.append(result)
            else:
                mesh = getattr(obj, "data", None)
                verts_count = len(getattr(mesh, "vertices", []) or []) if mesh is not None else 0
                faces_count = len(getattr(mesh, "polygons", []) or []) if mesh is not None else 0
                skipped.append(
                    {
                        "name": obj.name,
                        "verts": verts_count,
                        "faces": faces_count,
                        "reason": reason,
                    }
                )

        print("")
        print("=== Proxy triangle fixer ===")
        print(f"Fixed: {len(fixed)}")
        for rec in fixed:
            print(
                f"FIXED: {rec['name']} | old verts={rec['old_verts']}, "
                f"old faces={rec['old_faces']} -> new verts=3, new faces=1"
            )

        print("")
        print(f"Skipped: {len(skipped)}")
        for rec in skipped:
            print(
                f"SKIP: {rec['name']} | verts={rec['verts']}, "
                f"faces={rec['faces']} | {rec['reason']}"
            )

        if fixed:
            self.report({"INFO"}, f"Fixed {len(fixed)} proxy triangle mesh(es) (see System Console)")
        else:
            self.report({"INFO"}, "No proxy triangle meshes needed fixing")
        return {"FINISHED"}


class CRAY_OT_RepairA3OBSelections(Operator):
    bl_idname = "cray.repair_a3ob_selections"
    bl_label = "Repair Invalid A3OB Selections"
    bl_description = (
        "Join the selected/broken A3OB meshes into one Resolution 0 LOD, rebuild broken vertex-group links, "
        "and place the result under Collection > model.p3d"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.cray_texreplace_settings
        target_obj, src = _resolve_fix_target_object(context, ts.picked_object)
        if target_obj is None:
            self.report({"ERROR"}, "Select at least one mesh object")
            return {"CANCELLED"}
        ts.picked_object = target_obj

        if context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception as e:
                self.report({"ERROR"}, f"Failed to switch to Object Mode: {_fmt_exc(e)}")
                return {"CANCELLED"}

        scope_objs, scope_src = _collect_repair_a3ob_scope(context, target_obj)
        if not scope_objs:
            scope_objs = [target_obj]

        try:
            target_root, source_path = _ensure_repair_p3d_root_collection(context, target_obj, scope_objs)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to prepare .p3d collection: {_fmt_exc(e)}")
            return {"CANCELLED"}

        scope_names = []
        for obj in scope_objs:
            try:
                name = obj.name
            except ReferenceError:
                continue
            if name and name not in scope_names:
                scope_names.append(name)

        all_mesh_candidates = [
            obj for obj in (bpy.data.objects.get(name) for name in scope_names)
            if obj is not None and obj.type == "MESH" and obj.data is not None and len(obj.data.vertices) > 0
        ]
        mesh_candidates = [obj for obj in all_mesh_candidates if not _is_helper_object_name(obj.name)]
        if not mesh_candidates:
            mesh_candidates = all_mesh_candidates
        if not mesh_candidates:
            self.report({"ERROR"}, "No mesh object in selected repair scope")
            return {"CANCELLED"}

        def _mesh_repair_size(obj):
            if obj is None or obj.data is None:
                return 0
            return len(obj.data.polygons) * 1000 + len(obj.data.vertices)

        if target_obj in mesh_candidates and not _is_helper_object_name(target_obj.name):
            anchor_mesh = target_obj
            anchor_src = "target"
        else:
            anchor_mesh = max(mesh_candidates, key=_mesh_repair_size)
            anchor_src = "largest-mesh"
        active_mesh_name = anchor_mesh.name

        try:
            merged_obj, joined_count, join_passes = _join_meshes_in_batches(
                context=context,
                anchor_obj=anchor_mesh,
                mesh_names=[obj.name for obj in mesh_candidates],
                batch_size=ts.fix_mesh_join_batch,
            )
        except Exception as e:
            self.report({"ERROR"}, f"Join failed: {_fmt_exc(e)}")
            return {"CANCELLED"}

        live_scope_names = []
        for name in scope_names:
            live = bpy.data.objects.get(name)
            if live is None or live == merged_obj:
                continue
            live_scope_names.append((_obj_depth(live), name))
        live_scope_names.sort(key=lambda item: item[0], reverse=True)

        deleted_scope = 0
        for idx, (_, name) in enumerate(live_scope_names, start=1):
            live = bpy.data.objects.get(name)
            if live is None or live == merged_obj:
                continue
            try:
                bpy.data.objects.remove(live, do_unlink=True)
                deleted_scope += 1
            except Exception:
                pass
            if idx % 50 == 0:
                _ui_yield()

        try:
            lod_name = _set_resolution0_a3ob_lod_props(merged_obj)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        try:
            mesh_world = merged_obj.matrix_world.copy()
            merged_obj.parent = None
            merged_obj.matrix_world = mesh_world
        except Exception:
            pass

        _move_object_to_collection(merged_obj, target_root, unlink_roots=context.scene.collection)
        removed_empty_cols = _remove_empty_subcollections(target_root)

        deleted_helpers, deleted_helper_cols, remaining_helpers = _remove_helper_named_objects(
            scene=context.scene,
            keep_obj=merged_obj,
        )

        try:
            stats = _repair_invalid_a3ob_selection_links(merged_obj)
        except Exception as e:
            self.report({"ERROR"}, f"A3OB selection repair failed: {_fmt_exc(e)}")
            return {"CANCELLED"}

        _ensure_collection_visible_in_view_layer(context, target_root)
        _deselect_all_in_view_layer(context)
        try:
            merged_obj.select_set(True)
            context.view_layer.objects.active = merged_obj
        except Exception:
            pass

        msg = (
            f"Repaired '{target_root.name}/{lod_name}': joined {joined_count}, "
            f"removed objects {deleted_scope + deleted_helpers}, "
            f"removed empty collections {removed_empty_cols + deleted_helper_cols}, "
            f"invalid refs {stats['invalid_refs_removed']}, zero refs {stats['zero_refs_removed']}, "
            f"rebuilt groups {stats['groups_rebuilt']}"
        )
        extras = [
            f"src: {src}",
            f"scope: {scope_src}",
            f"anchor: {active_mesh_name}",
            f"anchor_src: {anchor_src}",
            f"join_passes: {join_passes}",
        ]
        if source_path:
            extras.append(f"source_path: {source_path}")
        if remaining_helpers:
            extras.append(f"remaining_helpers: {len(remaining_helpers)}")
        self.report({"INFO"}, msg + f", {', '.join(extras)}")
        return {"FINISHED"}


class CRAY_OT_CreatePlainAxisPivot(Operator):
    bl_idname = "cray.create_plain_axis_pivot"
    bl_label = "Create Plain Axis Pivot"
    bl_description = (
        "In Edit Mode, use the selected vertex as a pivot, create a Plain Axes helper, "
        "and add Child Of constraints so moving the helper moves the whole imported model"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        source_obj = context.view_layer.objects.active
        if source_obj is None or source_obj.type != "MESH" or context.mode != "EDIT_MESH" or source_obj.mode != "EDIT":
            self.report({"ERROR"}, "Active object must be a mesh in Edit Mode")
            return {"CANCELLED"}

        try:
            world_location = _collect_single_selected_vertex_world_point(source_obj)
        except Exception as e:
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        root_collection, used_p3d_root = _pick_plain_axis_root_collection(context, source_obj)
        if root_collection is None:
            self.report({"ERROR"}, "Could not determine a target collection for Plain Axis")
            return {"CANCELLED"}

        helper_obj = None
        constrained = 0
        failed = []
        replaced_helpers = 0
        restored_edit_mode = False

        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as e:
            self.report({"ERROR"}, f"Failed to switch to Object Mode: {_fmt_exc(e)}")
            return {"CANCELLED"}

        try:
            replaced_helpers, _removed_constraints = _clear_plain_axis_helpers_in_collection(context, root_collection)
            helper_obj = _create_plain_axis_helper(context, root_collection, source_obj, world_location)
            target_objects = _collect_plain_axis_target_objects(root_collection, helper_obj=helper_obj)
            if not target_objects:
                raise RuntimeError(f"No movable root objects found in collection {root_collection.name}")

            context.view_layer.update()

            enabled_axes = (
                "use_location_x",
                "use_location_y",
                "use_location_z",
                "use_rotation_x",
                "use_rotation_y",
                "use_rotation_z",
                "use_scale_x",
                "use_scale_y",
                "use_scale_z",
            )

            for obj in target_objects:
                try:
                    con = obj.constraints.new(type="CHILD_OF")
                    con.name = _PLAIN_AXIS_CONSTRAINT_NAME
                    con.target = helper_obj
                    for attr in enabled_axes:
                        try:
                            setattr(con, attr, True)
                        except Exception:
                            pass
                    context.view_layer.update()
                    _apply_child_of_inverse_with_fallback(context, obj, con)
                    constrained += 1
                except Exception as e:
                    failed.append(f"{obj.name}: {_fmt_exc(e)}")

            if constrained == 0:
                raise RuntimeError("Failed to add Child Of constraints to target objects")
        except Exception as e:
            if helper_obj is not None:
                _clear_plain_axis_helpers(context, [helper_obj])
            try:
                _try_restore_edit_mode(context, source_obj)
                restored_edit_mode = True
            except Exception:
                pass
            self.report({"ERROR"}, _fmt_exc(e))
            return {"CANCELLED"}

        if not restored_edit_mode:
            _try_restore_edit_mode(context, source_obj)

        if failed:
            print("=== Plain Axis Pivot: Failed Objects ===")
            for item in failed:
                print(item)

        scope_label = ".p3d root collection" if used_p3d_root else "active object collection"
        msg = (
            f"Created Plain Axis in {root_collection.name}: constrained {constrained} root object(s) "
            f"using {scope_label}"
        )
        if replaced_helpers > 0:
            msg += f", replaced {replaced_helpers} existing helper(s)"
        if failed:
            self.report({"WARNING"}, msg + f", failed {len(failed)} object(s) (see System Console)")
        else:
            self.report({"INFO"}, msg)
        return {"FINISHED"}


class CRAY_OT_ClearPlainAxisPivots(Operator):
    bl_idname = "cray.clear_plain_axis_pivots"
    bl_label = "Delete All Plain Axes"
    bl_description = "Delete all Plain Axes helpers created by this tool and remove their Child Of constraints"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        active_before = context.view_layer.objects.active
        restore_edit_mode = (
            context.mode == "EDIT_MESH"
            and active_before is not None
            and active_before.type == "MESH"
        )

        if context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception as e:
                self.report({"ERROR"}, f"Failed to switch to Object Mode: {_fmt_exc(e)}")
                return {"CANCELLED"}

        helpers = [obj for obj in bpy.data.objects if _is_plain_axis_helper(obj)]
        if not helpers:
            if restore_edit_mode:
                _try_restore_edit_mode(context, active_before)
            self.report({"INFO"}, "No Plain Axis helpers found in the scene")
            return {"FINISHED"}

        removed_helpers, removed_constraints = _clear_plain_axis_helpers(context, helpers)

        if restore_edit_mode:
            _try_restore_edit_mode(context, active_before)

        self.report(
            {"INFO"},
            f"Deleted {removed_helpers} Plain Axis helper(s) and removed {removed_constraints} Child Of constraint(s)",
        )
        return {"FINISHED"}


class CRAY_OT_IE_ExportCollectionsBatch(Operator):
    bl_idname = "cray.ie_export_collections_batch"
    bl_label = "Batch Export Collections (A3OB)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        st = context.scene.cray_ie_settings
        tex_settings = context.scene.cray_texreplace_settings
        warn_loose_vertices = bool(getattr(tex_settings, "export_warn_loose_vertices", True))
        has_export = any(_op_handle(op) is not None for op, _ in _A3OB_EXPORT_CANDIDATES)
        if not has_export:
            self.report({"ERROR"}, "Arma 3 Object Builder export operators not found")
            return {"CANCELLED"}

        export_dir = ""
        if st.export_mode == "CUSTOM_DIR":
            export_dir = bpy.path.abspath(st.export_directory)
            if not export_dir:
                self.report({"ERROR"}, "Export folder is empty")
                return {"CANCELLED"}
            try:
                os.makedirs(export_dir, exist_ok=True)
            except Exception as e:
                self.report({"ERROR"}, f"Failed to create export folder: {_fmt_exc(e)}")
                return {"CANCELLED"}

        import_basename_map = _build_ie_import_basename_map(st)

        candidate_roots = []
        seen_candidate_ptrs = set()
        for col in list(context.scene.collection.children) + list(_iter_p3d_root_collections(context.scene)):
            if col is None:
                continue
            try:
                ptr = col.as_pointer()
            except Exception:
                ptr = None
            if ptr in seen_candidate_ptrs:
                continue
            if ptr is not None:
                seen_candidate_ptrs.add(ptr)
            candidate_roots.append(col)

        candidates = []
        for col in candidate_roots:
            if not _collection_has_any_mesh(col):
                continue
            source_hint = _resolve_collection_source_path(col, import_basename_map)
            if st.export_only_p3d_named and not source_hint and not _looks_like_p3d_collection_name(col.name):
                continue
            if st.export_only_split_parts and not _looks_like_split_part_collection_name(col.name):
                continue
            candidates.append((col, source_hint))

        if not candidates:
            self.report({"ERROR"}, "No exportable root collections found")
            return {"CANCELLED"}

        if context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception as e:
                self.report({"ERROR"}, f"Failed to switch to Object Mode: {_fmt_exc(e)}")
                return {"CANCELLED"}

        prev_selected_names = [o.name for o in context.selected_objects]
        prev_active_name = context.view_layer.objects.active.name if context.view_layer.objects.active else None

        exported = 0
        backups = 0
        failed = []
        partial_lod_exports = []
        loose_vertex_warnings = []
        backup_skipped = []
        backup_preserved = []
        used_op = None
        used_targets = set()

        for col, source_hint in candidates:
            objects = _collect_collection_objects_recursive(col)
            if not objects:
                failed.append(f"{col.name} -> no objects")
                continue

            source_path = _resolve_collection_source_path(col, import_basename_map) or source_hint
            if st.export_mode == "SOURCE":
                if not source_path:
                    failed.append(f"{col.name} -> missing source path (import with this addon first)")
                    continue
                filepath = bpy.path.abspath(source_path)
                source_dir = os.path.dirname(filepath)
                if source_dir and not os.path.isdir(source_dir):
                    failed.append(f"{col.name} -> source folder not found: {source_dir}")
                    continue
            else:
                filename = _export_filename_for_collection(col, source_path)
                filepath = bpy.path.abspath(os.path.join(export_dir, filename))

            resolution_conflicts = _collect_resolution_lod_index_conflicts(col, objects)
            if resolution_conflicts:
                _report_resolution_lod_index_conflicts_in_console(col.name, filepath, resolution_conflicts)
                if not bool(st.export_force_all_lods):
                    failed.append(
                        f"{col.name} -> duplicate Resolution LOD index in one logical collection path "
                        f"(see System Console)"
                    )
                    continue
                print(
                    "WARNING: Force export all LODs is ON, continuing despite duplicate "
                    "Resolution LOD index conflict(s)."
                )

            ngon_issues = _collect_export_ngon_issues(col, objects)
            if ngon_issues:
                _report_export_ngon_issues_in_console(col.name, filepath, ngon_issues)
                if not bool(st.export_force_all_lods):
                    failed.append(f"{col.name} -> n-gon detected in exportable LOD mesh (see System Console)")
                    continue
                print("WARNING: Force export all LODs is ON, continuing despite n-gon issue(s).")

            target_key = os.path.normcase(os.path.normpath(filepath))
            if st.export_mode == "SOURCE":
                if target_key in used_targets:
                    failed.append(f"{col.name} -> duplicate source path in batch: {filepath}")
                    continue
            else:
                if target_key in used_targets:
                    base, ext = os.path.splitext(filepath)
                    idx = 1
                    while target_key in used_targets:
                        filepath = f"{base}_{idx:03d}{ext}"
                        target_key = os.path.normcase(os.path.normpath(filepath))
                        idx += 1
            used_targets.add(target_key)

            _ensure_collection_visible_in_view_layer(context, col)
            _deselect_all_in_view_layer(context)

            selectable = []
            for obj in objects:
                try:
                    obj.hide_set(False)
                except Exception:
                    pass
                try:
                    obj.hide_viewport = False
                except Exception:
                    pass
                try:
                    obj.select_set(True)
                    selectable.append(obj)
                except Exception:
                    continue

            if not selectable:
                failed.append(f"{col.name} -> no selectable objects in current View Layer")
                continue

            active_obj = None
            for obj in selectable:
                if obj.type == "MESH":
                    active_obj = obj
                    break
            if active_obj is None:
                active_obj = selectable[0]

            try:
                context.view_layer.objects.active = active_obj
            except Exception:
                pass

            prepared_mass = _prepare_geometry_lod_mass_for_export(selectable)
            if prepared_mass:
                print("=== Batch Export Collections: Geometry LOD mass prepared ===")
                for lod_name, vert_count, total_mass in prepared_mass:
                    print(f"{col.name} / {lod_name}: {vert_count} vertex masses, total {total_mass:.3f}")

            if warn_loose_vertices:
                loose_warnings = _collect_export_loose_vertex_warnings(col, selectable)
                if loose_warnings:
                    _report_export_loose_vertex_warnings_in_console(col.name, filepath, loose_warnings)
                    loose_vertex_warnings.append((col.name, filepath, len(loose_warnings)))

            expected_lod_entries = _collect_expected_lod_entries(selectable)

            pending_backup_path = ""
            if st.export_create_bak and os.path.isfile(filepath):
                pending_backup_path, backup_stage_err = _stage_export_backup(filepath)
                if backup_stage_err:
                    failed.append(f"{col.name} -> backup stage failed: {backup_stage_err}")
                    continue

            _, op_id, err = _call_export_with_optional_relaxed_validation(
                force_all_lods=bool(st.export_force_all_lods),
                filepath=filepath,
                use_selection=True,
                visible_only=False,
                relative_paths=True,
                preserve_normals=True,
                validate_meshes=False,
                apply_transforms=True,
                apply_modifiers=True,
                sort_sections=True,
                lod_collisions="IGNORE" if bool(st.export_force_all_lods) else "SKIP",
                validate_lods=False,
                validate_lods_warning_errors=False,
                generate_components=True,
                force_lowercase=True,
            )
            export_missing_keys = []
            lod_post_check_failed = False
            if op_id:
                used_op = op_id
                exported += 1
                if expected_lod_entries:
                    try:
                        exported_lod_entries = _read_exported_lod_entries(filepath)
                        missing_keys = _report_missing_lods_in_console(
                            collection_name=col.name,
                            filepath=filepath,
                            expected_entries=expected_lod_entries,
                            exported_entries=exported_lod_entries,
                        )
                        if missing_keys:
                            export_missing_keys = list(missing_keys)
                            _report_missing_lod_diagnostics_in_console(
                                context=context,
                                collection_name=col.name,
                                filepath=filepath,
                                missing_keys=missing_keys,
                                expected_entries=expected_lod_entries,
                                export_objects=selectable,
                                force_all_lods=bool(st.export_force_all_lods),
                            )
                            partial_lod_exports.append((col.name, filepath, len(missing_keys), len(expected_lod_entries)))
                    except Exception as e:
                        lod_post_check_failed = True
                        print("=== Batch Export Collections: LOD post-check failed ===")
                        print(f"{col.name} -> {_fmt_exc(e)}")
            else:
                failed.append(f"{col.name} -> {_fmt_exc(err) if err else 'export failed'}")

            if pending_backup_path:
                export_complete = bool(op_id) and not export_missing_keys and not lod_post_check_failed
                try:
                    backup_status, backup_reason, backup_missing_keys = _finalize_export_backup(
                        filepath,
                        pending_backup_path,
                        expected_lod_entries,
                        export_complete,
                    )
                except Exception as e:
                    backup_status = "skipped"
                    backup_reason = f"backup finalize failed: {_fmt_exc(e)}"
                    backup_missing_keys = []
                    _discard_pending_export_backup(pending_backup_path)

                if backup_status == "updated":
                    backups += 1
                    _report_export_backup_updated_in_console(
                        col.name,
                        filepath,
                        backup_reason,
                        backup_missing_keys,
                        expected_lod_entries,
                    )
                elif backup_status == "preserved":
                    backup_preserved.append((col.name, filepath, backup_reason))
                    _report_export_backup_preserved_in_console(
                        col.name,
                        filepath,
                        backup_reason,
                        backup_missing_keys,
                        expected_lod_entries,
                    )
                elif backup_status == "skipped":
                    backup_skipped.append((col.name, filepath, backup_reason))
                    _report_export_backup_skipped_in_console(
                        col.name,
                        filepath,
                        backup_reason,
                        backup_missing_keys,
                        expected_lod_entries,
                    )

        _deselect_all_in_view_layer(context)
        for name in prev_selected_names:
            obj = bpy.data.objects.get(name)
            if obj is None:
                continue
            try:
                obj.select_set(True)
            except Exception:
                pass

        if prev_active_name:
            prev_active = bpy.data.objects.get(prev_active_name)
            if prev_active is not None:
                try:
                    context.view_layer.objects.active = prev_active
                except Exception:
                    pass

        if failed:
            print("=== Batch Export Collections: Failures ===")
            for f in failed:
                print(f)

        if partial_lod_exports:
            print("=== Batch Export Collections: Partial LOD exports ===")
            for col_name, fp, miss_count, expected_count in partial_lod_exports:
                print(
                    f"{col_name} -> missing {miss_count}/{expected_count} expected unique LOD signatures "
                    f"({fp})"
                )

        msg = (
            f"Exported {exported}/{len(candidates)} collections, "
            f"backups {backups}, failed {len(failed)}"
        )
        if partial_lod_exports:
            msg += f", partial LOD exports {len(partial_lod_exports)}"
        if loose_vertex_warnings:
            msg += f", loose vertex warnings {len(loose_vertex_warnings)}"
        if backup_skipped:
            msg += f", backups skipped {len(backup_skipped)}"
        if backup_preserved:
            msg += f", backups preserved {len(backup_preserved)}"

        if failed or partial_lod_exports or loose_vertex_warnings or backup_skipped:
            self.report({"WARNING"}, msg + " (see System Console)")
        else:
            suffix = f" via {used_op}" if used_op else ""
            self.report({"INFO"}, msg + suffix)
        return {"FINISHED"}


# ------------------------------------------------------------------------
#  Panels (separate blocks)
# ------------------------------------------------------------------------

class CRAY_PT_ClutterProxiesPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_panel"
    bl_label = "Clutter Proxies (DayZ)"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        s = context.scene.cray_settings
        edit_obj = getattr(context, "edit_object", None)
        edit_name = edit_obj.name if edit_obj is not None and edit_obj.type == "MESH" else "<enter Edit Mode on mesh>"

        col = layout.column(align=True)
        col.label(text="Selection")
        col.label(text=edit_name, icon="MESH_DATA")
        col.label(text="Selected polygons in Edit Mode are used", icon="INFO")

        layout.separator()

        col = layout.column(align=True)
        col.label(text="Config .cpp")
        col.prop(s, "config_path")
        col.operator("cray.load_config", icon="FILE_FOLDER")
        col.prop(s, "selected_surface")

        layout.separator()

        col = layout.column(align=True)
        col.label(text="Density (DayZ-style)")
        col.prop(s, "grid_size")
        col.prop(s, "density_scale")
        col.prop(s, "slope_falloff")
        col.prop(s, "spawn_probability")
        col.prop(s, "max_proxies")
        col.prop(s, "seed")

        layout.separator()
        layout.operator("object.cray_scatter_proxies", icon="PARTICLES")

class CRAY_PT_SnapPointsPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_snap_points"
    bl_label = "Snap Points (Memory LOD)"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        ss = context.scene.cray_snap_settings
        preview_pattern = _SnapPointNamePattern.from_preview_settings(ss)
        target_a = _get_snap_target_object(ss, "a", allow_memory_fallback=False)
        target_v = _get_snap_target_object(ss, "v", allow_memory_fallback=False)
        targets_are_meshes = bool(
            target_a is not None and
            target_v is not None and
            target_a.type == "MESH" and
            target_v.type == "MESH" and
            target_a.data is not None and
            target_v.data is not None
        )
        target_scope_a = _snap_target_memory_scope_key(context, target_a)
        target_scope_v = _snap_target_memory_scope_key(context, target_v)
        same_target_scope = bool(target_scope_a is not None and target_scope_a == target_scope_v)
        can_create = bool(
            targets_are_meshes and
            not same_target_scope
        )

        col = layout.column(align=True)
        col.label(text="Target")
        col.prop(ss, "source_object", text="A Target")
        col.separator()
        col.prop(ss, "paired_object", text="V Target")
        col.operator("cray.ensure_memory_lod", text="Create/Find Point clouds > Memory", icon="OUTLINER_OB_MESH")

        layout.separator()

        col = layout.column(align=True)
        col.label(text="Name Pattern")
        col.prop(ss, "snap_p3d_name")
        col.prop(ss, "snap_pair_code")
        col.label(text="Snap Axis")
        axis_row = col.row(align=True)
        axis_row.prop(ss, "edge_axis", expand=True)
        col.label(text=f".sp_{preview_pattern.preview_base}_a_0 / .sp_{preview_pattern.preview_base}_v_1", icon="INFO")
        col.prop(ss, "replace_existing")

        layout.separator()
        info = layout.box()
        info.label(text="Select exactly 2 vertices in Edit Mode on any LOD", icon="INFO")
        create_row = info.row()
        create_row.enabled = can_create
        create_row.operator("cray.create_snap_pair_from_model_edge", text="Create Snap Points", icon="MESH_DATA")
        if target_a is None or target_v is None:
            info.label(text="Pick both target objects; Memory will be created automatically", icon="INFO")
        elif not targets_are_meshes:
            info.label(text="Both targets must be mesh objects", icon="ERROR")
        elif same_target_scope:
            info.label(text="Choose targets from two different model roots", icon="ERROR")
        else:
            info.label(text="Points will be created in each target's Point clouds > Memory", icon="INFO")

        layout.separator()
        pbox = layout.box()
        pbox.label(text="Plain Axes pivot", icon="EMPTY_AXIS")
        create_label = "Create Plain Axis Pivot  [Ctrl+Shift+P]" if _PLAIN_AXIS_HOTKEY_REGISTERED else "Create Plain Axis Pivot"
        pbox.operator("cray.create_plain_axis_pivot", text=create_label, icon="EMPTY_AXIS")
        pbox.operator("cray.clear_plain_axis_pivots", text="Delete All Plain Axes", icon="TRASH")

class CRAY_PT_ColliderPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_collider"
    bl_label = "Geometry Collider"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        cs = context.scene.cray_collider_settings
        active_obj = context.view_layer.objects.active
        active_source_name = active_obj.name if active_obj is not None and active_obj.type == "MESH" else "<active mesh>"

        col = layout.column(align=True)
        col.label(text="Target")
        col.label(text=f"Source: {active_source_name}", icon="MESH_DATA")
        col.prop(cs, "target_lod")
        row = col.row(align=True)
        row.prop(cs, "geometry_object")
        op = row.operator("cray.set_collider_target_from_active", text="", icon="EYEDROPPER")
        op.target_attr = "GEOMETRY"
        col.operator("cray.ensure_collider_lod", icon="OUTLINER_OB_MESH")
        col.prop(cs, "merge_distance")
        col.prop(cs, "recalc_normals")

        layout.separator()

        hotkeys = layout.box()
        row = hotkeys.row(align=True)
        row.label(text="Hotkeys", icon="EVENT_K")
        row.operator("cray.collider_hotkeys_info", text="", icon="INFO")
        row.prop(
            cs,
            "show_hotkey_button_fallbacks",
            text="Buttons",
            emboss=False,
            icon="TRIA_DOWN" if cs.show_hotkey_button_fallbacks else "TRIA_RIGHT",
        )

        if cs.show_hotkey_button_fallbacks:
            box = hotkeys.box()
            box.operator(
                "cray.copy_selected_verts_to_geometry",
                text="Copy Selected Verts To Geometry  [Ctrl+Shift+C]",
                icon="VERTEXSEL",
            )
            box.operator(
                "cray.select_isolated_vertices",
                text="Select Isolated Verts  [Mouse5]",
                icon="VERTEXSEL",
            )
            op = box.operator(
                "cray.build_collider",
                text="Selection -> Hull  [Mouse4]",
                icon="MESH_ICOSPHERE",
            )
            op.build_mode = "SELECTION_HULL"
            box.operator(
                "cray.hull_loose_geometry_verts",
                text="Selected Loose Geometry Verts -> Hull",
                icon="MESH_ICOSPHERE",
            )

        layout.separator()

        adv = layout.box()
        row = adv.row(align=True)
        row.label(text="Extra Build", icon="MOD_REMESH")
        row.prop(
            cs,
            "show_advanced_build_buttons",
            text="Open",
            emboss=False,
            icon="TRIA_DOWN" if cs.show_advanced_build_buttons else "TRIA_RIGHT",
        )

        if cs.show_advanced_build_buttons:
            adv.prop(cs, "box_thickness")
            adv.prop(cs, "bounds_padding")

            row = adv.row(align=True)
            op = row.operator("cray.build_collider", text="Selection -> Box", icon="MESH_CUBE")
            op.build_mode = "SELECTION_BOX"
            op = row.operator("cray.build_collider", text="Object -> Bounds", icon="CUBE")
            op.build_mode = "OBJECT_BOUNDS"

        layout.separator()

        fire = layout.box()
        row = fire.row(align=True)
        row.label(text="Geometries / Fire Geometry", icon="MESH_ICOSPHERE")
        row.prop(
            cs,
            "show_fire_geometry_tools",
            text="",
            emboss=False,
            icon="TRIA_DOWN" if cs.show_fire_geometry_tools else "TRIA_RIGHT",
        )
        if cs.show_fire_geometry_tools:
            row = fire.row(align=True)
            row.prop(cs, "fire_geometry_object", text="Fire Geometry")
            op = row.operator("cray.set_collider_target_from_active", text="", icon="EYEDROPPER")
            op.target_attr = "FIRE"
            row = fire.row(align=True)
            row.prop(cs, "fire_geometry_material", text="Material")
            row.operator("cray.open_fire_geometry_rvmat_folder", text="", icon="FILE_FOLDER")

        layout.separator()

        roadway = layout.box()
        row = roadway.row(align=True)
        row.label(text="Misc / Roadway", icon="MESH_PLANE")
        row.prop(
            cs,
            "show_roadway_tools",
            text="",
            emboss=False,
            icon="TRIA_DOWN" if cs.show_roadway_tools else "TRIA_RIGHT",
        )
        if cs.show_roadway_tools:
            row = roadway.row(align=True)
            row.prop(cs, "roadway_object")
            op = row.operator("cray.set_collider_target_from_active", text="", icon="EYEDROPPER")
            op.target_attr = "ROADWAY"
            row = roadway.row(align=True)
            row.operator("cray.ensure_roadway_lod", icon="OUTLINER_OB_MESH")
            row.operator("cray.copy_selected_faces_to_roadway", icon="FACESEL")
            row = roadway.row(align=True)
            row.prop(cs, "roadway_material", text="Material")
            row.operator("cray.open_roadway_material_folder", text="", icon="FILE_FOLDER")
            roadway.prop(cs, "roadway_weld_distance")
            roadway.operator("cray.weld_roadway_vertices", icon="AUTOMERGE_ON")

class CRAY_PT_AssetProxyPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_asset_proxy"
    bl_label = "P3D Asset Library"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        lib = context.scene.cray_asset_library_settings
        st = context.scene.cray_asset_proxy_settings

        box = layout.box()
        box.label(text="Temporary Asset Library", icon="ASSET_MANAGER")
        box.prop(lib, "folder")
        box.prop(lib, "import_first_lod_only")
        box.prop(lib, "clear_previous_temp_library")
        row = box.row(align=True)
        row.operator("cray.asset_library_build_folder", icon="FILE_FOLDER")
        row.operator("cray.asset_library_build_files", icon="FILEBROWSER")
        box.operator("cray.asset_library_clear", icon="TRASH")

        box = layout.box()
        box.label(text="Placed Assets -> A3OB Proxies", icon="CONSTRAINT")
        box.prop(st, "target_object", text="Target House / Main Object")
        box.prop(st, "delete_originals")
        box.operator("cray.convert_selected_to_proxies", icon="CONSTRAINT")


class CRAY_PT_FixesPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_fixes"
    bl_label = "Fixes"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        ts = context.scene.cray_texreplace_settings

        check_box = layout.box()
        check_box.label(text="Export checks", icon="ERROR")
        check_box.prop(ts, "export_warn_loose_vertices", text="Loose vertices outside Memory")
        check_box.operator("cray.select_loose_vertices_outside_memory", icon="VERTEXSEL")

        box = layout.box()
        box.label(text="Shading/Geometry fixes", icon="MOD_SMOOTH")
        box.operator("cray.repair_a3ob_selections", text="Repair Invalid A3OB Selections", icon="GROUP_VERTEX")
        box.separator()
        box.label(text="Hierarchy fix", icon="MOD_REMESH")
        box.prop(ts, "fix_mesh_join_batch")
        box.prop(ts, "fix_mesh_center_to_origin")
        box.operator("cray.fix_mesh_hierarchy", text="Fix Mesh/Hierarchy", icon="MOD_REMESH")
        box.separator()
        box.label(text="Component fixes from .txt", icon="FILE_TEXT")
        file_row = box.row(align=True)
        file_row.prop(ts, "fix_list_path", text="")
        file_row.operator("cray.open_fix_list_file", text="", icon="FILE_FOLDER")
        box.operator("cray.select_fix_list_components_on_active_lod", icon="GROUP_VERTEX")
        cleanup_col = box.column(align=True)
        cleanup_col.enabled = (
            context.mode == "EDIT_MESH"
            and context.active_object is not None
            and context.active_object.type == "MESH"
        )
        cleanup_col.operator("cray.delete_selected_components_keep_vertices", icon="MESH_DATA")
        box.operator("cray.fix_proxy_triangle_meshes", icon="CONSTRAINT")
        box.separator()
        box.label(text="Edit Mode planar search", icon="FACESEL")
        edit_col = box.column(align=True)
        edit_col.enabled = (
            context.mode == "EDIT_MESH"
            and context.active_object is not None
            and context.active_object.type == "MESH"
        )
        row = edit_col.row(align=True)
        row.operator("cray.select_split_planar_ngons", text="Find Trash", icon="TRASH")
        row.operator("cray.select_coplanar_plate_islands", text="Find Flat Plates", icon="MESH_GRID")
        tol_row = edit_col.row(align=True)
        tol_row.prop(ts, "split_planar_ngon_angle_tolerance", text="Angle")
        tol_row.prop(ts, "split_planar_ngon_plane_tolerance", text="Plane")

class CRAY_PT_ImportExportPlannerPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_ie_planner"
    bl_label = "Import/Export planner"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        st = context.scene.cray_ie_settings

        ibox = layout.box()
        ibox.label(text="Batch Import (Arma 3 Object Builder)", icon="IMPORT")
        ibox.label(text="Quick Add From NH_Objects", icon="VIEWZOOM")
        ibox.prop(st, "quick_add_search_root")
        quick_row = ibox.row(align=True)
        quick_row.prop(st, "quick_add_p3d_name", text="")
        quick_row.operator("cray.ie_add_by_name", text="", icon="ADD")
        row = ibox.row(align=True)
        row.operator("cray.ie_add_files", text="Add", icon="ADD")
        row.operator("cray.ie_remove_file", icon="REMOVE")
        row.operator("cray.ie_clear_files", icon="TRASH")
        ibox.template_list("CRAY_UL_ie_files", "", st, "import_files", st, "import_active_index", rows=6)
        ibox.operator("cray.ie_import_batch", icon="FILE_REFRESH")
        ibox.separator()
        ibox.prop(st, "import_show_materials")
        row_preview = ibox.row()
        row_preview.enabled = bool(st.import_show_materials)
        row_preview.prop(st, "import_keep_converted_textures")
        ibox.separator()
        ibox.prop(st, "disable_collections_after_import")
        row2 = ibox.row()
        row2.enabled = bool(st.disable_collections_after_import)
        row2.prop(st, "disable_mode", text="")

        ebox = layout.box()
        ebox.label(text="Batch Export Collections (Arma 3 Object Builder)", icon="EXPORT")
        ebox.prop(st, "export_mode")
        row3 = ebox.row()
        row3.enabled = (st.export_mode == "CUSTOM_DIR")
        row3.prop(st, "export_directory")
        ebox.prop(st, "export_create_bak")
        ebox.prop(st, "export_only_p3d_named")
        ebox.prop(st, "export_only_split_parts")
        ebox.prop(st, "export_force_all_lods")
        ebox.operator("cray.ie_export_collections_batch", icon="FILE_TICK")

class CRAY_PT_ModelSplitPanel(Panel):
    bl_idname = "VIEW3D_PT_cray_model_split"
    bl_label = "Model Split"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        st = context.scene.cray_model_split_settings

        box = layout.box()
        box.label(text="Part Transfer", icon="OUTLINER_COLLECTION")
        box.prop(st, "named_source_collection", text="Source Model")
        box.prop(st, "named_target_collection", text="Target Model")
        row = box.row(align=True)
        copy_op = row.operator("cray.model_split_transfer_to_target_category", text="Copy", icon="DUPLICATE")
        copy_op.transfer_mode = "COPY"
        move_op = row.operator("cray.model_split_transfer_to_target_category", text="Move", icon="EXPORT")
        move_op.transfer_mode = "MOVE"

class CRAY_PT_TextureReplacePanel(Panel):
    bl_idname = "VIEW3D_PT_cray_texreplace"
    bl_label = "Texture Replace"
    bl_category = "NH Plugin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        ts = context.scene.cray_texreplace_settings

        box = layout.box()
        box.label(text="Build Database (.paa/.rvmat only)")
        box.prop(ts, "folder")
        box.operator("cray.tex_db_build_folder", icon="FILE_FOLDER")

        layout.separator()

        obox = layout.box()
        obox.label(text="Object Preview (Image Texture materials)")
        row = obox.row(align=True)
        row.prop(ts, "picked_object", text="Select Object")
        row.operator("cray.update_object_preview", text="", icon="FILE_REFRESH")
        row.operator("cray.fix_mesh_hierarchy", text="", icon="MOD_REMESH")
        obox.operator("cray.replace_textures_from_db", icon="FILE_TICK")
        obox.label(text="Preview/Replace auto-detects mesh if picker is empty", icon="INFO")

        obj = ts.picked_object
        if obj is None:
            obox.label(text="No object selected", icon="INFO")
        else:
            obox.label(text=f"Object: {obj.name}", icon="OBJECT_DATA")
            obox.template_list("CRAY_UL_obj_preview", "", ts, "obj_preview_items", ts, "obj_preview_active_index", rows=5)

        layout.separator()
        layout.label(text="DB Preview (problematic duplicates = red)")
        layout.template_list("CRAY_UL_tex_db", "", ts, "db_items", ts, "db_active_index", rows=10)


# ------------------------------------------------------------------------
#  Registration
# ------------------------------------------------------------------------

classes = (
    CRAY_PG_Settings,
    CRAY_PG_SnapSettings,
    CRAY_PG_ColliderSettings,
    CRAY_OT_LoadConfig,
    CRAY_OT_ScatterProxies,
    CRAY_OT_EnsureMemoryLOD,
    CRAY_OT_CreateSnapPairFromModelEdge,
    CRAY_OT_SnapBatchProcess,
    CRAY_OT_CopySelectedVertsToGeometry,
    CRAY_OT_HullLooseGeometryVerts,
    CRAY_OT_ColliderHotkeysInfo,
    CRAY_OT_SetColliderTargetFromActive,
    CRAY_OT_EnsureRoadwayLOD,
    CRAY_OT_CopySelectedFacesToRoadway,
    CRAY_OT_WeldRoadwayVertices,
    CRAY_OT_OpenRoadwayMaterialFolder,
    CRAY_OT_OpenFireGeometryRvmatFolder,
    CRAY_OT_OpenFixListFile,
    CRAY_OT_SelectFixListComponentsOnActiveLOD,
    CRAY_OT_DeleteSelectedComponentsKeepVertices,
    CRAY_OT_FixProxyTriangleMeshes,
    CRAY_OT_SelectIsolatedVertices,
    CRAY_OT_SelectLooseVerticesOutsideMemory,
    CRAY_OT_SelectSplitPlanarNgons,
    CRAY_OT_SelectCoplanarPlateIslands,
    CRAY_OT_EnsureColliderLOD,
    CRAY_OT_BuildCollider,

    CRAY_PG_TexDBItem,
    CRAY_PG_ObjMatImagesItem,
    CRAY_PG_TexReplaceSettings,
    CRAY_UL_TexDB,
    CRAY_UL_ObjPreview,
    CRAY_OT_TexDBBuildFromFolder,
    CRAY_OT_UpdateObjectPreview,
    CRAY_OT_FixMeshHierarchy,
    CRAY_OT_ReplaceTexturesFromDB,

    CRAY_PG_IEFileItem,
    CRAY_PG_IEPlannerSettings,
    CRAY_PG_ModelSplitSettings,
    CRAY_PG_AssetLibrarySettings,
    CRAY_PG_AssetProxySettings,
    CRAY_OT_IEFilePathTooltip,
    CRAY_UL_IEFiles,
    CRAY_OT_AssetLibraryBuildFromFolder,
    CRAY_OT_AssetLibraryBuildFromFiles,
    CRAY_OT_AssetLibraryClear,
    CRAY_OT_IE_AddFiles,
    CRAY_OT_IE_AddByName,
    CRAY_OT_IE_RemoveFile,
    CRAY_OT_IE_ClearFiles,
    CRAY_OT_IE_ImportBatch,
    CRAY_OT_ModelSplitTransferSelectedToTargetCategory,
    CRAY_OT_ConvertSelectedToProxies,
    CRAY_OT_RepairA3OBSelections,
    CRAY_OT_CreatePlainAxisPivot,
    CRAY_OT_ClearPlainAxisPivots,
    CRAY_OT_IE_ExportCollectionsBatch,

    CRAY_PT_ColliderPanel,
    CRAY_PT_ClutterProxiesPanel,
    CRAY_PT_SnapPointsPanel,
    CRAY_PT_AssetProxyPanel,
    CRAY_PT_FixesPanel,
    CRAY_PT_ImportExportPlannerPanel,
    CRAY_PT_ModelSplitPanel,
    CRAY_PT_TextureReplacePanel,
)

def register():
    global _PERSISTED_UI_STATE_CACHE

    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cray_settings = PointerProperty(type=CRAY_PG_Settings)
    bpy.types.Scene.cray_snap_settings = PointerProperty(type=CRAY_PG_SnapSettings)
    bpy.types.Scene.cray_collider_settings = PointerProperty(type=CRAY_PG_ColliderSettings)
    bpy.types.Scene.cray_texreplace_settings = PointerProperty(type=CRAY_PG_TexReplaceSettings)
    bpy.types.Scene.cray_ie_settings = PointerProperty(type=CRAY_PG_IEPlannerSettings)
    bpy.types.Scene.cray_model_split_settings = PointerProperty(type=CRAY_PG_ModelSplitSettings)
    bpy.types.Scene.cray_asset_library_settings = PointerProperty(type=CRAY_PG_AssetLibrarySettings)
    bpy.types.Scene.cray_asset_proxy_settings = PointerProperty(type=CRAY_PG_AssetProxySettings)
    _PERSISTED_UI_STATE_CACHE = _read_persisted_ui_state()
    _apply_persisted_ui_state_to_all_scenes(only_if_default=True)
    _PERSISTED_UI_STATE_CACHE = _collect_persisted_ui_state(getattr(bpy.context, "scene", None))
    if _restore_persisted_ui_state_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_restore_persisted_ui_state_on_load)
    if not bpy.app.timers.is_registered(_persisted_ui_state_timer):
        bpy.app.timers.register(_persisted_ui_state_timer, first_interval=_PERSISTED_UI_STATE_TIMER_INTERVAL, persistent=True)
    _patch_a3ob_import_read_file()
    if not bpy.app.timers.is_registered(_ensure_a3ob_import_patch_timer):
        bpy.app.timers.register(_ensure_a3ob_import_patch_timer, first_interval=1.0, persistent=True)
    _register_collider_keymaps()

def unregister():
    _unregister_collider_keymaps()
    _save_current_persisted_ui_state(getattr(bpy.context, "scene", None))
    if bpy.app.timers.is_registered(_persisted_ui_state_timer):
        bpy.app.timers.unregister(_persisted_ui_state_timer)
    if _restore_persisted_ui_state_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_restore_persisted_ui_state_on_load)
    if bpy.app.timers.is_registered(_ensure_a3ob_import_patch_timer):
        bpy.app.timers.unregister(_ensure_a3ob_import_patch_timer)
    _unpatch_a3ob_import_read_file()
    del bpy.types.Scene.cray_asset_proxy_settings
    del bpy.types.Scene.cray_asset_library_settings
    del bpy.types.Scene.cray_model_split_settings
    del bpy.types.Scene.cray_ie_settings
    del bpy.types.Scene.cray_texreplace_settings
    del bpy.types.Scene.cray_collider_settings
    del bpy.types.Scene.cray_snap_settings
    del bpy.types.Scene.cray_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
